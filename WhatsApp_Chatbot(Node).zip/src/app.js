// Load environment variables first, before any other imports
require("dotenv").config();
require("./config/environment"); // Import environment configuration

// Now import other modules
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const logger = require("./utils/logger");
const { errorHandler } = require("./middleware/errorHandler");
const mongoDbService = require("./services/mongoDbService");

// Import routes
const webhookRoutes = require("./routes/webhookRoutes");
const apiRoutes = require("./routes/apiRoutes");

// Initialize Express app
const app = express();

// Security and utility middleware
app.use(helmet()); // Security headers
app.use(cors()); // Enable CORS
app.use(morgan("dev")); // HTTP request logging

// Body parsers - Important for webhook handling
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use("/api/webhook", webhookRoutes);
app.use("/api", apiRoutes);

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
});

// Error handler middleware (should be last)
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3000;

// Connect to MongoDB before starting the server
mongoDbService.connect()
  .then(() => {
app.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
    });
  })
  .catch((error) => {
    logger.error('Failed to connect to MongoDB:', error);
    process.exit(1);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (err) => {
  logger.error("Unhandled Promise Rejection:", err);
  // Don't crash the server, but log the error
});

// Handle application shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received. Closing MongoDB connection...');
  await mongoDbService.disconnect();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received. Closing MongoDB connection...');
  await mongoDbService.disconnect();
  process.exit(0);
});

module.exports = app;

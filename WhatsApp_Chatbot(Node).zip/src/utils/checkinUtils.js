// Utility to calculate next check-in time based on business rules
function getNextCheckInTime(now = new Date()) {
  const hour = now.getHours();
  let next;

  if (hour >= 21 || hour < 7) {
    // Night mode: every hour
    next = new Date(now.getTime() + 1 * 60 * 60 * 1000);
    // If next check-in is after 7am, set to 7am
    if (next.getHours() === 7 && next.getMinutes() === 0) {
      next.setMinutes(0, 0, 0);
    }
  } else {
    // Day mode: every 3 hours
    next = new Date(now.getTime() + 1 * 60 * 60 * 1000);
  }
  return next;
}

// Utility to get the next 6am time from now
function getNextSevenAM(now = new Date()) {
  const nextMorning = new Date(now);
  if (now.getHours() >= 7) {
    nextMorning.setDate(now.getDate() + 1);
  }
  nextMorning.setHours(7, 0, 0, 0);
  return nextMorning;
}

module.exports = {
  getNextCheckInTime,
  getNextSevenAM
}; 
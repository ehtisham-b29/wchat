/**
 * Custom API Error class for handling HTTP errors
 */
class ApiError extends Error {
  /**
   * Create a new API error
   * @param {string} message - Error message
   * @param {number} statusCode - HTTP status code
   * @param {Object} [metadata] - Additional error metadata
   */
  constructor(message, statusCode = 500, metadata = {}) {
    super(message);
    this.name = "ApiError";
    this.statusCode = statusCode;
    this.metadata = metadata;
    this.timestamp = new Date().toISOString();

    // Capture stack trace
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Create a 400 Bad Request error
 * @param {string} message - Error message
 * @param {Object} [metadata] - Additional error metadata
 * @returns {ApiError} - Bad request error
 */
const badRequest = (message = "Bad Request", metadata = {}) => {
  return new ApiError(message, 400, metadata);
};

/**
 * Create a 401 Unauthorized error
 * @param {string} message - Error message
 * @param {Object} [metadata] - Additional error metadata
 * @returns {ApiError} - Unauthorized error
 */
const unauthorized = (message = "Unauthorized", metadata = {}) => {
  return new ApiError(message, 401, metadata);
};

/**
 * Create a 403 Forbidden error
 * @param {string} message - Error message
 * @param {Object} [metadata] - Additional error metadata
 * @returns {ApiError} - Forbidden error
 */
const forbidden = (message = "Forbidden", metadata = {}) => {
  return new ApiError(message, 403, metadata);
};

/**
 * Create a 404 Not Found error
 * @param {string} message - Error message
 * @param {Object} [metadata] - Additional error metadata
 * @returns {ApiError} - Not found error
 */
const notFound = (message = "Not Found", metadata = {}) => {
  return new ApiError(message, 404, metadata);
};

/**
 * Create a 500 Internal Server Error
 * @param {string} message - Error message
 * @param {Object} [metadata] - Additional error metadata
 * @returns {ApiError} - Internal server error
 */
const serverError = (message = "Internal Server Error", metadata = {}) => {
  return new ApiError(message, 500, metadata);
};

module.exports = {
  ApiError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  serverError,
};

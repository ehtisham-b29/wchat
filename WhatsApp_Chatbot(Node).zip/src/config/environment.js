/**
 * Environment configuration module
 * Sets default values for required environment variables
 */

// Set default values for required environment variables if they're not already set
if (!process.env.MONGODB_URI) {
  process.env.MONGODB_URI = 'mongodb://localhost:27017/whatsapp-chatbot';
  console.log(
    `Set default MONGODB_URI: ${process.env.MONGODB_URI}`
  );
}

// Add other environment variables as needed
// if (!process.env.SOME_OTHER_VAR) {
//   process.env.SOME_OTHER_VAR = 'default_value';
// }

module.exports = {
  MONGODB_URI: process.env.MONGODB_URI,
  // Add other environment variables here
};

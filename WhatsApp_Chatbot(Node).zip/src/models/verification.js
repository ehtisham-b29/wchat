const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const User = require('./user');
const twilioService = require('../services/twilio/twilioService');
const { getNextCheckInTime, getNextSevensAM } = require('../utils/checkinUtils');

const verificationSchema = new mongoose.Schema({
  verificationId: {
    type: String,
    required: true,
    unique: true,
    default: () => uuidv4()
  },
  userId: {
    type: String,
    required: true,
    index: true
  },
  phoneNumber: {
    type: String,
    required: true,
    index: true
  },
  code: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['SMS', 'VOICE'],
    default: 'SMS'
  },
  purpose: {
    type: String,
    enum: ['LOGIN', 'PASSCODE_RESET'],
    default: 'LOGIN'
  },
  attempts: {
    type: Number,
    default: 0
  },
  maxAttempts: {
    type: Number,
    default: 3
  },
  status: {
    type: String,
    enum: ['PENDING', 'VERIFIED', 'INVALIDATED'],
    default: 'PENDING'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    required: true
  }
}, {
  timestamps: true
});

// Create indexes for common queries
verificationSchema.index({ userId: 1, expiresAt: 1 });
verificationSchema.index({ phoneNumber: 1, expiresAt: 1 });
verificationSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // TTL index

const Verification = mongoose.model('Verification', verificationSchema);

/**
 * Create a new verification code
 * @param {Object} verificationData - Verification data
 * @returns {Promise<Object>} - Created verification object
 */
Verification.createVerification = async function (verificationData) {
  try {
    const now = new Date();
    const expiryMinutes = Number(process.env.VERIFICATION_CODE_EXPIRY_MINUTES) || 10;

    // Generate a random 6-digit code
    const code = verificationData.code || Math.floor(100000 + Math.random() * 900000).toString();

    const verification = new this({
      userId: verificationData.userId,
      phoneNumber: verificationData.phoneNumber,
      code,
      type: verificationData.type || 'SMS',
      purpose: verificationData.purpose || 'LOGIN',
      maxAttempts: verificationData.maxAttempts || Number(process.env.MAX_FAILED_ATTEMPTS) || 3,
      expiresAt: new Date(now.getTime() + expiryMinutes * 60000)
    });

    return await verification.save();
  } catch (error) {
    logger.error(`Error creating verification: ${error.message}`);
    throw error;
  }
};

/**
 * Get a verification by ID
 * @param {string} verificationId - Verification ID
 * @returns {Promise<Object>} - Verification object
 */
Verification.getById = async function (verificationId) {
  try {
    return await this.findOne({ verificationId });
  } catch (error) {
    logger.error(`Error getting verification by ID: ${error.message}`);
    throw error;
  }
};

/**
 * Get active verifications for a user
 * @param {string} userId - User ID
 * @param {string} purpose - Verification purpose
 * @returns {Promise<Array>} - Array of verification objects
 */
Verification.getActiveByUserId = async function (userId, purpose = null) {
  try {
    const query = {
      userId,
      expiresAt: { $gt: new Date() },
      status: 'PENDING'
    };

    if (purpose) {
      query.purpose = purpose;
    }

    return await this.find(query);
  } catch (error) {
    logger.error(`Error getting active verifications for user: ${error.message}`);
    throw error;
  }
};

/**
 * Get active verifications for a phone number
 * @param {string} phoneNumber - Phone number
 * @param {string} purpose - Verification purpose
 * @returns {Promise<Array>} - Array of verification objects
 */
Verification.getActiveByPhoneNumber = async function (phoneNumber, purpose = null) {
  try {
    const query = {
      phoneNumber,
      expiresAt: { $gt: new Date() },
      status: 'PENDING'
    };

    if (purpose) {
      query.purpose = purpose;
    }

    return await this.find(query);
  } catch (error) {
    logger.error(`Error getting active verifications for phone number: ${error.message}`);
    throw error;
  }
};

/**
 * Verify a code
 * @param {string} verificationId - Verification ID
 * @param {string} code - Verification code to verify
 * @returns {Promise<boolean>} - Verification success status
 */
Verification.verifyCode = async function (verificationId, code) {
  try {
    const verification = await this.findOne({ verificationId });

    if (!verification) {
      logger.warn(`Verification not found: ${verificationId}`);
      return false;
    }

    // Check if the verification is still valid
    const now = new Date();
    if (now > verification.expiresAt) {
      logger.warn(`Verification expired: ${verificationId}`);
      return false;
    }

    // Check if max attempts exceeded
    if (verification.attempts >= verification.maxAttempts) {
      logger.warn(`Max attempts exceeded for verification: ${verificationId}`);
      return false;
    }

    // Increment attempts
    verification.attempts += 1;

    // Check if the code matches
    if (verification.code === code) {
      verification.status = 'VERIFIED';
      await verification.save();
      return true;
    } else {
      // Update attempts count
      await verification.save();
      logger.warn(`Invalid verification code. Attempts: ${verification.attempts}/${verification.maxAttempts}`);
      return false;
    }
  } catch (error) {
    logger.error(`Error verifying code: ${error.message}`);
    throw error;
  }
};

/**
 * Invalidate a verification
 * @param {string} verificationId - Verification ID
 * @returns {Promise<boolean>} - Success status
 */
Verification.invalidate = async function (verificationId) {
  try {
    const verification = await this.findOne({ verificationId });

    if (!verification) {
      logger.warn(`Verification not found: ${verificationId}`);
      return false;
    }

    verification.status = 'INVALIDATED';
    verification.expiresAt = new Date(); // Expire immediately

    await verification.save();
    return true;
  } catch (error) {
    logger.error(`Error invalidating verification: ${error.message}`);
    throw error;
  }
};

/**
 * Invalidate all active verifications for a user
 * @param {string} userId - User ID
 * @param {string} purpose - Verification purpose to invalidate
 * @returns {Promise<number>} - Number of invalidated verifications
 */
Verification.invalidateAllForUser = async function (userId, purpose = null) {
  try {
    const query = {
      userId,
      status: 'PENDING',
      expiresAt: { $gt: new Date() }
    };

    if (purpose) {
      query.purpose = purpose;
    }

    const result = await this.updateMany(query, {
      $set: {
        status: 'INVALIDATED',
        expiresAt: new Date()
      }
    });

    return result.modifiedCount;
  } catch (error) {
    logger.error(`Error invalidating all verifications for user: ${error.message}`);
    throw error;
  }
};

module.exports = Verification; 
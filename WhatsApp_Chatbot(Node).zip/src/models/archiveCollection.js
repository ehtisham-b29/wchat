const mongoose = require('mongoose');

const archiveSchema = new mongoose.Schema({
    escalationId: {
        type: String,
        required: true,
        unique: true
    },
    userId: {
        type: String,
        required: true,
        index: true
    },
    agentId: {
        type: String,
        index: true
    },
    status: {
        type: String,
        enum: ['RESOLVED', 'CANCELLED', 'FAILED'],
        required: true
    },
    workQueueStatus: {
        type: String,
        enum: ['RESOLVED', 'CANCELLED', 'FAILED'],
        required: true
    },
    location: {
        lastKnown: {
            type: Object
        },
        foundAt: {
            type: Object
        }
    },
    timeline: [{
        action: {
            type: String,
            required: true
        },
        details: String,
        timestamp: {
            type: Date,
            default: Date.now
        }
    }],
    verification: {
        userCode: String,
        agentCode: String,
        verifiedAt: Date,
        status: String
    },
    resolvedAt: {
        type: Date,
        default: Date.now
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Indexes for common queries
archiveSchema.index({ createdAt: -1 });
archiveSchema.index({ status: 1, createdAt: -1 });
archiveSchema.index({ userId: 1, createdAt: -1 });

// Static methods
archiveSchema.statics = {
    /**
     * Create a new archive record
     * @param {Object} archiveData - The archive data
     * @returns {Promise<Object>} The created archive record
     */
    async create(archiveData) {
        const archive = new this(archiveData);
        return await archive.save();
    },

    /**
     * Find archives by user ID
     * @param {string} userId - The user's ID
     * @param {Object} options - Query options
     * @returns {Promise<Array>} Array of archive records
     */
    async findByUserId(userId, options = {}) {
        const query = this.find({ userId })
            .sort({ createdAt: -1 });

        if (options.limit) {
            query.limit(options.limit);
        }

        if (options.skip) {
            query.skip(options.skip);
        }

        return await query.exec();
    },

    /**
     * Find archives by status
     * @param {string} status - The status to search for
     * @param {Object} options - Query options
     * @returns {Promise<Array>} Array of archive records
     */
    async findByStatus(status, options = {}) {
        const query = this.find({ status })
            .sort({ createdAt: -1 });

        if (options.limit) {
            query.limit(options.limit);
        }

        if (options.skip) {
            query.skip(options.skip);
        }

        return await query.exec();
    },

    /**
     * Find archives within a date range
     * @param {Date} startDate - Start date
     * @param {Date} endDate - End date
     * @param {Object} options - Query options
     * @returns {Promise<Array>} Array of archive records
     */
    async findByDateRange(startDate, endDate, options = {}) {
        const query = this.find({
            createdAt: {
                $gte: startDate,
                $lte: endDate
            }
        }).sort({ createdAt: -1 });

        if (options.limit) {
            query.limit(options.limit);
        }

        if (options.skip) {
            query.skip(options.skip);
        }

        return await query.exec();
    }
};

// Instance methods
archiveSchema.methods = {
    /**
     * Update archive record
     * @param {Object} updateData - The data to update
     * @returns {Promise<Object>} The updated archive record
     */
    async update(updateData) {
        Object.assign(this, updateData);
        return await this.save();
    },

    /**
     * Add a timeline event
     * @param {string} action - The action taken
     * @param {string} details - Details about the action
     * @returns {Promise<Object>} The updated archive record
     */
    async addTimelineEvent(action, details) {
        this.timeline.push({
            action,
            details,
            timestamp: new Date()
        });
        return await this.save();
    }
};

const ArchiveCollection = mongoose.model('ArchiveCollection', archiveSchema);

module.exports = ArchiveCollection; 
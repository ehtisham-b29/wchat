const mongoose = require('mongoose');

const workQueueSchema = new mongoose.Schema({
  queueId: {
    type: String,
    required: true,
    unique: true
  },
  userId: {
    type: String,
    required: true,
    index: true
  },
  type: {
    type: String,
    enum: ['MESSAGE', 'CALL', 'AGENT'],
    required: true
  },
  priority: {
    type: String,
    enum: ['low', 'normal', 'high'],
    default: 'normal'
  },
  status: {
    type: String,
    enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'ESCALATED'],
    default: 'PENDING'
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  attempts: {
    type: Number,
    default: 0
  },
  lastAttempt: {
    type: Date
  },
  nextAttempt: {
    type: Date
  },
  error: {
    message: String,
    stack: String,
    timestamp: Date
  },
  escalationPath: [{
    from: String,
    to: String,
    reason: String,
    timestamp: Date
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes
workQueueSchema.index({ status: 1, priority: 1, nextAttempt: 1 });
workQueueSchema.index({ type: 1, status: 1 });
workQueueSchema.index({ createdAt: 1 });

// Methods
workQueueSchema.methods.incrementAttempts = async function() {
  this.attempts += 1;
  this.lastAttempt = new Date();
  this.nextAttempt = this.calculateNextAttempt();
  await this.save();
};

workQueueSchema.methods.calculateNextAttempt = function() {
  // Exponential backoff: 1min, 2min, 4min, 8min, etc.
  const delay = Math.min(Math.pow(2, this.attempts) * 60 * 1000, 30 * 60 * 1000);
  return new Date(Date.now() + delay);
};

workQueueSchema.methods.escalate = async function(toType, reason) {
  this.escalationPath.push({
    from: this.type,
    to: toType,
    reason,
    timestamp: new Date()
  });
  
  this.status = 'ESCALATED';
  await this.save();
};

workQueueSchema.methods.complete = async function() {
  this.status = 'COMPLETED';
  await this.save();
};

workQueueSchema.methods.fail = async function(error) {
  this.status = 'FAILED';
  this.error = {
    message: error.message,
    stack: error.stack,
    timestamp: new Date()
  };
  await this.save();
};

// Static methods
workQueueSchema.statics.findNextJob = async function(type, priority) {
  return this.findOne({
    type,
    status: 'PENDING',
    priority,
    nextAttempt: { $lte: new Date() }
  }).sort({ priority: 1, createdAt: 1 });
};

workQueueSchema.statics.findUserJobs = async function(userId) {
  return this.find({
    userId,
    status: { $in: ['PENDING', 'PROCESSING'] }
  }).sort({ priority: 1, createdAt: 1 });
};

workQueueSchema.statics.clearUserJobs = async function(userId) {
  return this.updateMany(
    {
      userId,
      status: { $in: ['PENDING', 'PROCESSING'] }
    },
    {
      $set: {
        status: 'COMPLETED',
        updatedAt: new Date()
      }
    }
  );
};

const WorkQueue = mongoose.model('WorkQueue', workQueueSchema);

module.exports = WorkQueue; 
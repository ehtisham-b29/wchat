const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const journeyCompletionSchema = new mongoose.Schema({
  journeyCompletionId: {
    type: String,
    default: () => uuidv4(),
    required: true,
    unique: true
  },
  userId: {
    type: String,
    required: true,
    ref: 'User'
  },
  flightTime: {
    type: Date,
    required: true
  },
  departureMessages: [{
    type: {
      type: String,
      enum: ['24H', '12H', '4H'],
      required: true
    },
    sentAt: {
      type: Date,
      required: true
    },
    status: {
      type: String,
      enum: ['PENDING', 'SENT', 'FAILED'],
      default: 'PENDING'
    }
  }],
  finalVerification: {
    userCode: {
      type: String,
      required: false
    },
    agentPin: {
      type: String,
      required: false
    },
    verifiedAt: {
      type: Date,
      required: false
    },
    status: {
      type: String,
      enum: ['PENDING', 'VERIFIED', 'FAILED'],
      default: 'PENDING'
    }
  },
  journeyStatus: {
    type: String,
    enum: ['ACTIVE', 'COMPLETED', 'CANCELLED'],
    default: 'ACTIVE'
  },
  completedAt: {
    type: Date,
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt timestamp before saving
journeyCompletionSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

const JourneyCompletion = mongoose.model('JourneyCompletion', journeyCompletionSchema);

module.exports = JourneyCompletion; 
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

// Define the Session schema
const sessionSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
    unique: true,
    default: () => uuidv4()
  },
  userId: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  whatsappId: {
    type: String,
    required: true,
  },
  state: {
    type: String,
    enum: [
      'INITIAL',
      'ONBOARDING_START',
      'AWAITING_BOOKING_NUMBER',
      'AWAITING_DOB',
      'AWAITING_PASSCODE_SETUP',
      'AWAITING_VERIFICATION_CODE',
      'AWAITING_TRAVELER_SELECTION',
      'AWAITING_LOCATION_VERIFICATION',
      'AWAITING_CHECKIN_PASSCODE',
      'AWAITING_EMERGENCY_VERIFICATION',
      'AWAITING_TAPOUT_VERIFICATION',
      'AWAITING_CANCELLATION_CONFIRMATION',
      'AWAITING_AGENT_PIN',
      'GENERAL_CONVERSATION',
      'COMPLETED',
      'CANCELLED'
    ],
    default: 'INITIAL'
  },
  context: {
    type: Object,
    default: {
      // Location context
      detectedCity: String,
      detectedCountry: String,
      expectedCity: String,
      expectedCountry: String,
      timezone: String,
      language: String,

      // Booking context
      bookingNumber: String,
      travelers: [{
        name: String,
        selected: Boolean
      }],
      itinerary: {
        startDate: Date,
        endDate: Date,
        legs: [{
          from: String,
          to: String,
          date: Date,
          status: String
        }]
      },

      // Verification context
      verificationId: String,
      verificationType: String,
      verificationAttempts: Number,

      // Emergency context
      emergencyType: String,
      agentId: String,
      lastEmergencyCheck: Date,

      // Tap-In/Out context
      lastTapIn: Date,
      nextTapInDue: Date,
      tapInDelay: Number,
      tapOutStage: Number,

      // Work queue context
      queueId: String,
      queuePriority: Number,
      escalationLevel: Number,

      // Cancellation context
      cancellationType: String,
      cancellationReason: String
    }
  },
  conversationHistory: [{
    role: {
      type: String,
      enum: ['user', 'assistant', 'system', 'agent'],
      required: true
    },
    content: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    metadata: {
      type: Object,
      default: {}
    }
  }],
  lastMessageTimestamp: {
    type: Date,
    default: Date.now,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  expiresAt: Date,
  status: {
    type: String,
    enum: ['ACTIVE', 'PAUSED', 'COMPLETED', 'CANCELLED', 'ESCALATED'],
    default: 'ACTIVE'
  },
  priority: {
    type: Number,
    default: 0
  },
  flags: {
    requiresAgentAttention: {
      type: Boolean,
      default: false
    },
    isEmergency: {
      type: Boolean,
      default: false
    },
    isVerified: {
      type: Boolean,
      default: false
    },
    isLocationVerified: {
      type: Boolean,
      default: false
    }
  }
}, {
  timestamps: true,
});

// Create indexes
sessionSchema.index({ userId: 1, expiresAt: 1 });
sessionSchema.index({ whatsappId: 1, expiresAt: 1 });
sessionSchema.index({ sessionId: 1 });
sessionSchema.index({ status: 1, priority: -1 });
sessionSchema.index({ 'flags.requiresAgentAttention': 1 });
sessionSchema.index({ 'flags.isEmergency': 1 });
sessionSchema.index({ 'context.queueId': 1 });

// Create the Session model
const Session = mongoose.model('Session', sessionSchema);

/**
 * Create a new session
 * @param {Object} sessionData - Session data
 * @returns {Promise<Object>} - Created session object
 */
Session.create = async function (sessionData) {
  try {
    const session = new Session({
      ...sessionData,
      lastMessageTimestamp: new Date(),
    });

    await session.save();
    return session.toObject();
  } catch (error) {
    logger.error(`Error creating session: ${error.message}`);
    throw error;
  }
};

/**
 * Get a session by ID
 * @param {string} sessionId - Session ID
 * @returns {Promise<Object>} - Session object
 */
Session.getById = async function (sessionId) {
  try {
    const session = await Session.findOne({ sessionId });
    return session ? session.toObject() : null;
  } catch (error) {
    logger.error(`Error getting session by ID: ${error.message}`);
    throw error;
  }
};

/**
 * Get active session for a user
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - Session object
 */
Session.getActiveByUserId = async function (userId) {
  try {
    const now = new Date();
    const session = await Session.findOne({
      userId,
      $or: [
        { expiresAt: { $gt: now } },
        { expiresAt: null }
      ]
    }).sort({ lastMessageTimestamp: -1 });

    return session ? session.toObject() : null;
  } catch (error) {
    logger.error(`Error getting active session for user: ${error.message}`);
    throw error;
  }
};

/**
 * Get active session by WhatsApp ID
 * @param {string} whatsappId - WhatsApp ID
 * @returns {Promise<Object>} - Session object
 */
Session.getActiveByWhatsAppId = async function (whatsappId) {
  try {
    const now = new Date();
    const session = await Session.findOne({
      whatsappId,
      $or: [
        { expiresAt: { $gt: now } },
        { expiresAt: null }
      ]
    }).sort({ lastMessageTimestamp: -1 });

    return session ? session.toObject() : null;
  } catch (error) {
    logger.error(`Error getting active session by WhatsApp ID: ${error.message}`);
    throw error;
  }
};

/**
 * Update a session
 * @param {string} sessionId - Session ID
 * @param {Object} updates - Fields to update
 * @returns {Promise<Object>} - Updated session object
 */
Session.update = async function (sessionId, updates) {
  try {
    // Don't allow updating certain fields
    const protectedFields = ['sessionId', 'createdAt'];
    const filteredUpdates = { ...updates };
    protectedFields.forEach(field => delete filteredUpdates[field]);

    // Always update lastMessageTimestamp
    filteredUpdates.lastMessageTimestamp = new Date();

    const session = await Session.findOneAndUpdate(
      { sessionId },
      { $set: filteredUpdates },
      { new: true }
    );

    if (!session) {
      throw new Error(`Session not found: ${sessionId}`);
    }

    return session.toObject();
  } catch (error) {
    logger.error(`Error updating session: ${error.message}`);
    throw error;
  }
};

/**
 * Add a message to the conversation history
 * @param {string} sessionId - Session ID
 * @param {Object} message - Message object
 * @returns {Promise<Object>} - Updated session
 */
Session.addMessage = async function (sessionId, message) {
  try {
    const session = await Session.findOneAndUpdate(
      { sessionId },
      {
        $push: { conversationHistory: message },
        $set: { lastMessageTimestamp: new Date() }
      },
      { new: true }
    );

    if (!session) {
      throw new Error(`Session not found: ${sessionId}`);
    }

    return session.toObject();
  } catch (error) {
    logger.error(`Error adding message to session: ${error.message}`);
    throw error;
  }
};

/**
 * Update the session state
 * @param {string} sessionId - Session ID
 * @param {string} state - New state
 * @param {Object} context - State context
 * @returns {Promise<Object>} - Updated session
 */
Session.updateState = async function (sessionId, state, context = {}) {
  try {
    const session = await Session.findOne({ sessionId });
    if (!session) {
      throw new Error(`Session not found: ${sessionId}`);
    }

    const updates = {
      state,
      context: {
        ...session.context,
        ...context
      }
    };

    return await Session.update(sessionId, updates);
  } catch (error) {
    logger.error(`Error updating session state: ${error.message}`);
    throw error;
  }
};

/**
 * End a session
 * @param {string} sessionId - Session ID
 * @returns {Promise<boolean>} - Success status
 */
Session.end = async function (sessionId) {
  try {
    const session = await Session.findOneAndUpdate(
      { sessionId },
      { $set: { expiresAt: new Date() } },
      { new: true }
    );

    if (!session) {
      throw new Error(`Session not found: ${sessionId}`);
    }

    return true;
  } catch (error) {
    logger.error(`Error ending session: ${error.message}`);
    throw error;
  }
};

/**
 * Get recent messages from a session
 * @param {string} sessionId - Session ID
 * @param {number} limit - Maximum number of messages to return
 * @returns {Promise<Array>} - Array of recent messages
 */
Session.getRecentMessages = async function (sessionId, limit = 5) {
  try {
    const session = await Session.findOne({ sessionId });
    if (!session) {
      throw new Error(`Session not found: ${sessionId}`);
    }

    // Get the most recent messages, limited by the specified number
    const messages = session.conversationHistory || [];
    return messages.slice(-limit);
  } catch (error) {
    logger.error(`Error getting recent messages: ${error.message}`);
    throw error;
  }
};

module.exports = Session; 
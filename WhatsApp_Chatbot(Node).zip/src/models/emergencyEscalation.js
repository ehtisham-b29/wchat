const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const emergencyEscalationSchema = new mongoose.Schema({
  escalationId: {
    type: String,
    default: () => uuidv4(),
    required: true,
    unique: true
  },
  userId: {
    type: String,
    required: true,
    ref: 'User'
  },
  status: {
    type: String,
    enum: ['PENDING', 'AGENT_ASSIGNED', 'LOCATED', 'VERIFIED', 'RESOLVED', 'FAILED'],
    default: 'PENDING'
  },
  workQueueStatus: {
    type: String,
    enum: ['PENDING', 'SEND_HELP', 'IN_PROGRESS', 'RESOLVED'],
    default: 'PENDING'
  },
  agentId: {
    type: String,
    required: false
  },
  agentPin: {
    type: String,
    required: false
  },
  verification: {
    userCode: {
      type: String,
      required: false
    },
    agentCode: {
      type: String,
      required: false
    },
    verifiedAt: {
      type: Date,
      required: false
    },
    status: {
      type: String,
      enum: ['PENDING', 'VERIFIED', 'FAILED'],
      default: 'PENDING'
    }
  },
  location: {
    lastKnown: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point'
      },
      coordinates: {
        type: [Number],
        required: false
      }
    },
    foundAt: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point'
      },
      coordinates: {
        type: [Number],
        required: false
      }
    }
  },
  timeline: [{
    action: {
      type: String,
      enum: ['ESCALATED', 'AGENT_ASSIGNED', 'LOCATED', 'VERIFIED', 'RESOLVED'],
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    details: {
      type: String,
      required: false
    }
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  resolvedAt: {
    type: Date,
    required: false
  }
});

// Update the updatedAt timestamp before saving
emergencyEscalationSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

// Add indexes for efficient querying
emergencyEscalationSchema.index({ userId: 1, status: 1 });
emergencyEscalationSchema.index({ workQueueStatus: 1 });
emergencyEscalationSchema.index({ 'location.lastKnown': '2dsphere' });
emergencyEscalationSchema.index({ 'location.foundAt': '2dsphere' });

const EmergencyEscalation = mongoose.model('EmergencyEscalation', emergencyEscalationSchema);

module.exports = EmergencyEscalation; 
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const { getNextCheckInTime } = require('../utils/checkinUtils');

// Define the User schema
const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true,
  },
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
  },
  whatsappId: {
    type: String,
    required: true,
    unique: true,
  },
  name: String,
  email: String,
  passcode: String,
  goodNightCode: String,
  dateOfBirth: Date,
  location: {
    type: {
      countryCode: String,
      cityCode: String,
      latitude: Number,
      longitude: Number,
      formattedAddress: String,
      timezone: String,
      language: String
    },
    default: null,
  },
  bookingNumber: String,
  itinerary: {
    type: {
      expectedCity: String,
      expectedCountry: String,
      startDate: Date,
      endDate: Date,
      legs: [{
        from: String,
        to: String,
        date: Date,
        flightNumber: String,
        status: String
      }],
      travelers: [{
        name: String,
        selected: Boolean
      }]
    },
    default: null
  },
  verified: {
    type: Boolean,
    default: false,
  },
  status: {
    type: String,
    enum: ['ONBOARDING', 'ACTIVE', 'INACTIVE', 'BLOCKED', 'COMPLETED', 'CANCELLED', 'FLAGGED'],
    default: 'ONBOARDING',
  },
  onboardingStep: {
    type: String,
    enum: ['AWAITING_NAME', 'AWAITING_BOOKING_NUMBER', 'AWAITING_DOB', 'AWAITING_PASSCODE_SETUP', 'AWAITING_VERIFICATION_CODE', 'COMPLETED'],
    default: 'AWAITING_NAME'
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  lastCheckIn: Date,
  nextCheckInDue: Date,
  lastTapIn: Date,
  lastTapOut: Date,
  checkInHistory: [{
    timestamp: Date,
    status: String,
    location: {
      latitude: Number,
      longitude: Number,
      formattedAddress: String
    }
  }],
  emergencyContacts: [{
    name: String,
    phoneNumber: String,
    relationship: String
  }],
  workQueueStatus: {
    type: String,
    enum: ['NONE', 'TAP_IN', 'SEND_HELP', 'VERIFICATION', 'ESCALATED'],
    default: 'NONE'
  },
  escalationTerminations: {
    count: {
      type: Number,
      default: 0
    },
    lastReset: {
      type: Date,
      default: Date.now
    }
  },
  cancellationInfo: {
    cancelled: Boolean,
    cancelledAt: Date,
    reason: String,
    cancelledBy: String
  }
}, {
  timestamps: true,
});

// Create indexes
userSchema.index({ phoneNumber: 1 });
userSchema.index({ whatsappId: 1 });
userSchema.index({ nextCheckInDue: 1 });
userSchema.index({ status: 1, nextCheckInDue: 1 });

// Create the User model
const User = mongoose.model('User', userSchema);

/**
 * Create a new user
 * @param {Object} userData - User data
 * @returns {Promise<Object>} - Created user object
 */
User.create = async function (userData) {
  try {
    const timestamp = new Date();

    // Generate a user ID if not provided
    const userId = userData.userId || uuidv4();

    // Hash passcode if provided
    let hashedPasscode = null;
    if (userData.passcode) {
      hashedPasscode = await bcrypt.hash(userData.passcode, 10);
    }

    // Hash goodNightCode if provided
    let hashedGoodNightCode = null;
    if (userData.goodNightCode) {
      hashedGoodNightCode = await bcrypt.hash(userData.goodNightCode, 10);
    }

    // Set initial check-in times
    const lastCheckIn = timestamp;
    const nextCheckInDue = getNextCheckInTime(timestamp);

    const user = new User({
      ...userData,
      userId, // Ensure userId is set
      passcode: hashedPasscode,
      goodNightCode: hashedGoodNightCode,
      createdAt: timestamp,
      updatedAt: timestamp,
      lastCheckIn,
      nextCheckInDue
    });

    await user.save();

    // Remove the hashed passcodes from the returned object
    const returnUser = user.toObject();
    delete returnUser.passcode;
    delete returnUser.goodNightCode;

    return returnUser;
  } catch (error) {
    logger.error(`Error creating user: ${error.message}`);
    throw error;
  }
};

/**
 * Get a user by ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - User object
 */
User.getById = async function (userId) {
  try {
    const user = await User.findOne({ userId });
    if (user) {
      const returnUser = user.toObject();
      delete returnUser.passcode;
      return returnUser;
    }
    return null;
  } catch (error) {
    logger.error(`Error getting user by ID: ${error.message}`);
    throw error;
  }
};

/**
 * Get a user by WhatsApp ID
 * @param {string} whatsappId - WhatsApp ID
 * @returns {Promise<Object>} - User object
 */
User.getByWhatsAppId = async function (whatsappId) {
  try {
    const user = await User.findOne({ whatsappId });
    if (user) {
      const returnUser = user.toObject();
      delete returnUser.passcode;
      return returnUser;
    }
    return null;
  } catch (error) {
    logger.error(`Error getting user by WhatsApp ID: ${error.message}`);
    throw error;
  }
};

/**
 * Get a user by phone number
 * @param {string} phoneNumber - Phone number
 * @returns {Promise<Object>} - User object
 */
User.getByPhoneNumber = async function (phoneNumber) {
  try {
    const user = await User.findOne({ phoneNumber });
    if (user) {
      const returnUser = user.toObject();
      delete returnUser.passcode;
      return returnUser;
    }
    return null;
  } catch (error) {
    logger.error(`Error getting user by phone number: ${error.message}`);
    throw error;
  }
};

/**
 * Update a user
 * @param {string} userId - User ID
 * @param {Object} updates - Fields to update
 * @returns {Promise<Object>} - Updated user object
 */
User.update = async function (userId, updates) {
  try {
    // Don't allow updating certain fields
    const protectedFields = ['userId', 'createdAt'];
    const filteredUpdates = { ...updates };
    protectedFields.forEach(field => delete filteredUpdates[field]);

    // Hash passcode if it's being updated
    if (filteredUpdates.passcode) {
      filteredUpdates.passcode = await bcrypt.hash(filteredUpdates.passcode, 10);
    }
    // Hash goodNightCode if it's being updated
    if (filteredUpdates.goodNightCode) {
      filteredUpdates.goodNightCode = await bcrypt.hash(filteredUpdates.goodNightCode, 10);
    }

    const user = await User.findOneAndUpdate(
      { userId },
      { $set: filteredUpdates },
      { new: true }
    );

    if (!user) {
      throw new Error('User not found');
    }

    // Remove the hashed passcodes from the returned object
    const returnUser = user.toObject();
    delete returnUser.passcode;
    delete returnUser.goodNightCode;

    return returnUser;
  } catch (error) {
    logger.error(`Error updating user: ${error.message}`);
    throw error;
  }
};

/**
 * Verify a user's passcode
 * @param {string} userId - User ID
 * @param {string} passcode - Passcode to verify
 * @returns {Promise<boolean>} - Whether the passcode is correct
 */
User.verifyPasscode = async function (userId, passcode) {
  try {
    const user = await User.findOne({ userId });
    if (!user || !user.passcode) {
      return false;
    }
    return await bcrypt.compare(passcode, user.passcode);
  } catch (error) {
    logger.error(`Error verifying passcode: ${error.message}`);
    throw error;
  }
};

/**
 * Update check-in schedule for a user
 * @param {string} userId - User ID
 * @param {Date} lastCheckIn - Last check-in time
 * @param {Date} nextCheckInDue - Next check-in due time
 * @returns {Promise<Object>} - Updated user object
 */
User.updateCheckInSchedule = async function (userId, lastCheckIn, nextCheckInDue) {
  try {
    const updates = {
      lastCheckIn: lastCheckIn,
      nextCheckInDue: nextCheckInDue,
    };
    return await User.update(userId, updates);
  } catch (error) {
    logger.error(`Error updating check-in schedule: ${error.message}`);
    throw error;
  }
};

module.exports = User;

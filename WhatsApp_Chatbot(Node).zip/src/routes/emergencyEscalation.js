const express = require('express');
const router = express.Router();
const emergencyEscalationService = require('../services/emergencyEscalationService');
const logger = require('../utils/logger');

/**
 * Create emergency escalation
 * POST /api/emergency-escalation
 */
router.post('/', async (req, res) => {
  try {
    const { userId, location } = req.body;
    
    if (!userId || !location) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const escalation = await emergencyEscalationService.createEscalation(
      userId,
      location
    );

    res.json(escalation);
  } catch (error) {
    logger.error('Error creating emergency escalation:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to create emergency escalation' });
  }
});

/**
 * Assign agent to escalation
 * POST /api/emergency-escalation/:escalationId/assign
 */
router.post('/:escalationId/assign', async (req, res) => {
  try {
    const { escalationId } = req.params;
    const { agentId, agentPin } = req.body;
    
    if (!agentId || !agentPin) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const escalation = await emergencyEscalationService.assignAgent(
      escalationId,
      agentId,
      agentPin
    );

    res.json(escalation);
  } catch (error) {
    logger.error('Error assigning agent:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to assign agent' });
  }
});

/**
 * Update user location
 * POST /api/emergency-escalation/:escalationId/location
 */
router.post('/:escalationId/location', async (req, res) => {
  try {
    const { escalationId } = req.params;
    const { location } = req.body;
    
    if (!location) {
      return res.status(400).json({ error: 'Missing location data' });
    }

    const escalation = await emergencyEscalationService.updateUserLocation(
      escalationId,
      location
    );

    res.json(escalation);
  } catch (error) {
    logger.error('Error updating user location:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to update user location' });
  }
});

/**
 * Verify user safety
 * POST /api/emergency-escalation/:escalationId/verify
 */
router.post('/:escalationId/verify', async (req, res) => {
  try {
    const { escalationId } = req.params;
    const { userCode, agentCode } = req.body;
    
    if (!userCode || !agentCode) {
      return res.status(400).json({ error: 'Missing verification codes' });
    }

    const escalation = await emergencyEscalationService.verifySafety(
      escalationId,
      userCode,
      agentCode
    );

    res.json(escalation);
  } catch (error) {
    logger.error('Error verifying user safety:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to verify user safety' });
  }
});

/**
 * Resolve escalation
 * POST /api/emergency-escalation/:escalationId/resolve
 */
router.post('/:escalationId/resolve', async (req, res) => {
  try {
    const { escalationId } = req.params;

    const escalation = await emergencyEscalationService.resolveEscalation(
      escalationId
    );

    res.json(escalation);
  } catch (error) {
    logger.error('Error resolving escalation:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to resolve escalation' });
  }
});

/**
 * Get escalation status
 * GET /api/emergency-escalation/:escalationId
 */
router.get('/:escalationId', async (req, res) => {
  try {
    const { escalationId } = req.params;
    
    const escalation = await EmergencyEscalation.findOne({ escalationId });

    if (!escalation) {
      return res.status(404).json({ error: 'Escalation not found' });
    }

    res.json(escalation);
  } catch (error) {
    logger.error('Error getting escalation status:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to get escalation status' });
  }
});

module.exports = router; 
const express = require('express');
const { asyncHandler } = require('../middleware/errorHandler');
const User = require('../models/user');
const Session = require('../models/session');
const Verification = require('../models/verification');
const twilioService = require('../services/twilio/twilioService');
const flightStatus = require('../services/amadeus/flightStatus');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * Get user information
 * GET /api/users/:userId
 */
router.get('/users/:userId', asyncHandler(async (req, res) => {
  const user = await User.getById(req.params.userId);

  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  res.json({ success: true, data: user });
}));

/**
 * TwiML for verification call
 * GET /api/twiml/verification/:verificationId
 */
router.get('/twiml/verification/:verificationId', asyncHandler(async (req, res) => {
  const verification = await Verification.getById(req.params.verificationId);

  if (!verification) {
    // Return a simple message if verification not found
    res.set('Content-Type', 'text/xml');
    return res.send(`
      <?xml version="1.0" encoding="UTF-8"?>
      <Response>
        <Say>Sorry, that verification code was not found or has expired.</Say>
      </Response>
    `);
  }

  // Generate TwiML for the verification code
  const twiml = twilioService.generateVerificationTwiML(verification.code);

  res.set('Content-Type', 'text/xml');
  res.send(twiml);
}));

/**
 * Get flight status
 * GET /api/flight-status/:flightNumber/:date
 */
router.get('/flight-status/:flightNumber/:date', asyncHandler(async (req, res) => {
  const { flightNumber, date } = req.params;

  // Get flight status from Amadeus
  const flightData = await flightStatus.getFlightStatus(flightNumber, date);

  // Format the response
  const formattedResponse = flightStatus.formatFlightStatusMessage(flightData);

  res.json({
    success: true,
    data: {
      raw: flightData,
      formatted: formattedResponse,
      isDelayed: flightStatus.isFlightDelayedOrCancelled(flightData)
    }
  });
}));

/**
 * Trigger a check-in for a user
 * POST /api/check-in/:userId
 */
router.post('/check-in/:userId', asyncHandler(async (req, res) => {
  const user = await User.getById(req.params.userId);

  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  // Get or create a session
  let session = await Session.getActiveByUserId(user.userId);

  if (!session) {
    session = await Session.create({
      userId: user.userId,
      phoneNumber: user.phoneNumber,
      whatsappId: user.whatsappId
    });
  }

  // Send check-in message
  const checkInMessage = "Tap-In";

  await twilioService.sendWhatsAppMessage(user.phoneNumber, checkInMessage);

  // Add to session history
  await Session.addMessage(session.sessionId, {
    role: 'assistant',
    content: checkInMessage,
    timestamp: new Date().toISOString()
  });

  // Update session state
  await Session.updateState(session.sessionId, 'AWAITING_CHECKIN_PASSCODE');

  res.json({ success: true, message: 'Check-in triggered' });
}));

/**
 * Initiate a voice verification call
 * POST /api/verification/call
 * Body: { phoneNumber, userId, purpose }
 */
router.post('/verification/call', asyncHandler(async (req, res) => {
  const { phoneNumber, userId, purpose } = req.body;

  if (!phoneNumber || !userId) {
    return res.status(400).json({ success: false, message: 'Phone number and user ID are required' });
  }

  // Create a verification record
  const verification = await Verification.create({
    userId,
    phoneNumber,
    purpose: purpose || 'VERIFICATION',
    type: 'VOICE'
  });

  // Generate the TwiML URL for the call
  const twimlUrl = `${req.protocol}://${req.get('host')}/api/twiml/verification/${verification.verificationId}`;

  // Initiate the call
  const call = await twilioService.initiateVoiceCall(phoneNumber, twimlUrl);

  res.json({
    success: true,
    data: {
      verificationId: verification.verificationId,
      callSid: call.sid,
      expiresAt: verification.expiresAt
    }
  });
}));

/**
 * Create an SMS verification code
 * POST /api/verification/sms
 * Body: { phoneNumber, userId, purpose }
 */
router.post('/verification/sms', asyncHandler(async (req, res) => {
  const { phoneNumber, userId, purpose } = req.body;

  if (!phoneNumber || !userId) {
    return res.status(400).json({ success: false, message: 'Phone number and user ID are required' });
  }

  // Create a verification record
  const verification = await Verification.create({
    userId,
    phoneNumber,
    purpose: purpose || 'VERIFICATION',
    type: 'SMS'
  });

  // Send the verification code via SMS
  await twilioService.sendSMS(
    phoneNumber,
    `Your verification code is: ${verification.code}. This code will expire in 10 minutes.`
  );

  res.json({
    success: true,
    data: {
      verificationId: verification.verificationId,
      expiresAt: verification.expiresAt
    }
  });
}));

module.exports = router; 
const express = require('express');
const router = express.Router();
const journeyCompletionService = require('../services/journeyCompletionService');
const logger = require('../utils/logger');

/**
 * Initialize journey completion
 * POST /api/journey-completion/initialize
 */
router.post('/initialize', async (req, res) => {
  try {
    const { userId, flightTime } = req.body;
    
    if (!userId || !flightTime) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const journeyCompletion = await journeyCompletionService.initializeJourneyCompletion(
      userId,
      new Date(flightTime)
    );

    res.json(journeyCompletion);
  } catch (error) {
    logger.error('Error initializing journey completion:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to initialize journey completion' });
  }
});

/**
 * Verify final codes
 * POST /api/journey-completion/verify
 */
router.post('/verify', async (req, res) => {
  try {
    const { userId, userCode, agentPin } = req.body;
    
    if (!userId || !userCode || !agentPin) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const journeyCompletion = await journeyCompletionService.verifyFinalCodes(
      userId,
      userCode,
      agentPin
    );

    res.json(journeyCompletion);
  } catch (error) {
    logger.error('Error verifying journey completion:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to verify journey completion' });
  }
});

/**
 * Get journey completion status
 * GET /api/journey-completion/:userId
 */
router.get('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const journeyCompletion = await JourneyCompletion.findOne({ 
      userId,
      journeyStatus: 'ACTIVE'
    });

    if (!journeyCompletion) {
      return res.status(404).json({ error: 'No active journey found' });
    }

    res.json(journeyCompletion);
  } catch (error) {
    logger.error('Error getting journey completion status:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to get journey completion status' });
  }
});

module.exports = router; 
const express = require("express");
const router = express.Router();
const {
  processWhatsAppWebhook,
  processVoiceCallWebhook,
} = require("../controllers/webhookController");
const twilioWebhookValidator = require("../middleware/twilioWebhookValidator");

// Configuration for Twilio webhook validation
const validationConfig = {
  // In development, you might want to disable validation
  validate: process.env.NODE_ENV === "production",
  // Override the auth token if needed
  // authToken: process.env.TWILIO_AUTH_TOKEN,
  // Add additional security options
  allowedIps: process.env.ALLOWED_TWILIO_IPS,
};

/**
 * WhatsApp webhook endpoint
 * POST /api/webhook/whatsapp
 */
router.post(
  "/whatsapp",
  twilioWebhookValidator(validationConfig),
  processWhatsAppWebhook
);

/**
 * Voice call webhook endpoint
 * POST /api/webhook/voice
 */
router.post(
  "/voice",
  twilioWebhookValidator(validationConfig),
  processVoiceCallWebhook
);

/**
 * Verify webhook URL (for Twilio setup)
 * GET /api/webhook/whatsapp
 */
router.get("/whatsapp", (req, res) => {
  // This endpoint is used by Twilio to verify the webhook URL
  res.status(200).send("Webhook verification successful");
});

/**
 * Verify voice webhook URL (for Twilio setup)
 * GET /api/webhook/voice
 */
router.get("/voice", (req, res) => {
  // This endpoint is used by Twilio to verify the webhook URL
  res.status(200).send("Voice webhook verification successful");
});

module.exports = router;

const express = require('express');
const router = express.Router();
const assistanceService = require('../services/assistanceService');
const tripCancellationService = require('../services/tripCancellationService');
const logger = require('../utils/logger');

/**
 * Handle assistance request
 * POST /api/assistance
 */
router.post('/', async (req, res) => {
  try {
    const { userId, query } = req.body;
    
    if (!userId || !query) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const result = await assistanceService.handleAssistanceRequest(userId, query);
    res.json(result);
  } catch (error) {
    logger.error('Error handling assistance request:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to process assistance request' });
  }
});

/**
 * Handle trip cancellation type selection
 * POST /api/assistance/cancel-trip/type
 */
router.post('/cancel-trip/type', async (req, res) => {
  try {
    const { userId, cancellationType } = req.body;
    
    if (!userId || !cancellationType) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const result = await tripCancellationService.processCancellationType(
      userId,
      cancellationType
    );
    res.json(result);
  } catch (error) {
    logger.error('Error processing cancellation type:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to process cancellation type' });
  }
});

/**
 * Verify and process trip cancellation
 * POST /api/assistance/cancel-trip/verify
 */
router.post('/cancel-trip/verify', async (req, res) => {
  try {
    const { userId, bookingRef, dob, cancellationType } = req.body;
    
    if (!userId || !bookingRef || !dob || !cancellationType) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const result = await tripCancellationService.verifyAndProcessCancellation(
      userId,
      bookingRef,
      dob,
      cancellationType
    );
    res.json(result);
  } catch (error) {
    logger.error('Error verifying and processing cancellation:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to process cancellation' });
  }
});

/**
 * Update contact information
 * POST /api/assistance/update-contact
 */
router.post('/update-contact', async (req, res) => {
  try {
    const { userId, phoneNumber, email } = req.body;
    
    if (!userId || (!phoneNumber && !email)) {
      return res.status(400).json({ error: 'Missing contact information' });
    }

    const result = await assistanceService.handleContactUpdate(userId, { phoneNumber, email });
    res.json(result);
  } catch (error) {
    logger.error('Error updating contact information:', {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({ error: 'Failed to update contact information' });
  }
});

module.exports = router; 
const emergencyEscalationService = require('../services/emergencyEscalationService');
const twilioService = require('../services/twilio/twilioService');
const logger = require('../utils/logger');
const User = require('../models/user');

class EmergencyHandler {
  constructor() {
    this.pendingCancellations = new Map(); // Store pending cancellation attempts
    this.verificationAttempts = new Map();
    this.MAX_VERIFICATION_ATTEMPTS = 3;
    this.AGENT_VERIFICATION_CODE = '1202';
    this.pendingAgentVerifications = new Map();
  }

  /**
   * Handle emergency cancellation request
   * @param {string} userId - User ID
   * @param {string} message - User's message
   */
  async handleEmergencyCancellation(userId, message) {
    try {
      // Check if user has a pending cancellation
      if (this.pendingCancellations.has(userId)) {
        const { attempts, dayCode } = this.pendingCancellations.get(userId);

        // If this is the second attempt with the same code
        if (attempts === 1 && message === dayCode) {
          // Cancel the escalation
          await emergencyEscalationService.cancelEscalationWithDayCode(userId, dayCode);

          // Clear pending cancellation
          this.pendingCancellations.delete(userId);

          return {
            success: true,
            message: "Emergency escalation has been cancelled successfully."
          };
        } else {
          // Invalid code on second attempt
          this.pendingCancellations.delete(userId);
          return {
            success: false,
            message: "Invalid day code. Emergency escalation remains active."
          };
        }
      }

      // First attempt - store the code
      this.pendingCancellations.set(userId, {
        attempts: 1,
        dayCode: message
      });

      // Ask for confirmation
      return {
        success: true,
        message: "Please enter the same day code again to confirm cancellation of the emergency escalation."
      };
    } catch (error) {
      logger.error('Error handling emergency cancellation:', {
        userId,
        error: error.message,
        stack: error.stack
      });

      // Clear pending cancellation on error
      this.pendingCancellations.delete(userId);

      return {
        success: false,
        message: "An error occurred while processing your cancellation request. Please try again."
      };
    }
  }

  /**
   * Handle verification code response
   * @param {string} userId - User ID
   * @param {string} code - Verification code
   */
  async handleVerificationCode(userId, code) {
    try {
      const attempts = this.verificationAttempts.get(userId) || 0;

      if (attempts >= this.MAX_VERIFICATION_ATTEMPTS) {
        // Escalate to agent dispatch
        await emergencyEscalationService.createEscalation(userId);
        this.verificationAttempts.delete(userId);
        return {
          success: false,
          message: "Maximum verification attempts reached. A safety agent will be dispatched."
        };
      }

      const isValid = await emergencyEscalationService.verifyUserCode(userId, code);

      if (isValid) {
        // Clear verification attempts
        this.verificationAttempts.delete(userId);

        // Reconfirm tap-in
        await emergencyEscalationService.reconfirmTapIn(userId);

        return {
          success: true,
          message: "Verification successful. Please complete a new tap-in to confirm you're safe."
        };
      } else {
        // Increment attempts
        this.verificationAttempts.set(userId, attempts + 1);

        // Generate new code if attempts remain
        if (attempts + 1 < this.MAX_VERIFICATION_ATTEMPTS) {
          await emergencyEscalationService.generateVerificationCode(userId);
          return {
            success: false,
            message: "Invalid code. A new verification code has been sent."
          };
        } else {
          // Escalate to agent dispatch
          await emergencyEscalationService.createEscalation(userId);
          return {
            success: false,
            message: "Maximum verification attempts reached. A safety agent will be dispatched."
          };
        }
      }
    } catch (error) {
      logger.error('Error handling verification code:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Handle tap-in confirmation
   * @param {string} userId - User ID
   * @param {string} message - User's message
   */
  async handleTapInConfirmation(userId, message) {
    try {
      if (message.toUpperCase() === 'TAP IN') {
        // Update user status
        await User.findOneAndUpdate(
          { userId },
          {
            $set: {
              workQueueStatus: 'NORMAL',
              status: 'ACTIVE',
              lastTapIn: new Date()
            }
          }
        );

        // Clear any pending verifications
        this.verificationAttempts.delete(userId);

        return {
          success: true,
          message: "Tap-in confirmed. You're all set!"
        };
      } else {
        return {
          success: false,
          message: "Please reply with 'TAP IN' to confirm you're safe."
        };
      }
    } catch (error) {
      logger.error('Error handling tap-in confirmation:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Handle agent verification
   * @param {string} userId - User ID
   * @param {string} agentId - Agent ID
   * @param {string} userCode - User's verification code
   * @param {string} agentCode - Agent's verification code
   */
  async handleAgentVerification(userId, agentId, userCode, agentCode) {
    try {
      // Verify agent code
      if (agentCode !== this.AGENT_VERIFICATION_CODE) {
        return {
          success: false,
          message: "Invalid agent verification code. Please try again."
        };
      }

      // Verify safety with agent
      await emergencyEscalationService.verifySafetyWithAgent(
        userId,
        agentId,
        userCode,
        agentCode
      );

      // Request tap-in confirmation
      await emergencyEscalationService.reconfirmTapIn(userId);

      return {
        success: true,
        message: "Safety verification successful. Please ask the user to complete a new tap-in."
      };
    } catch (error) {
      logger.error('Error handling agent verification:', {
        userId,
        agentId,
        error: error.message,
        stack: error.stack
      });

      return {
        success: false,
        message: "Verification failed. Please check the codes and try again."
      };
    }
  }

  /**
   * Handle emergency message
   * @param {string} userId - User ID
   * @param {string} message - User's message
   * @param {string} agentId - Optional agent ID for verification
   */
  async handleEmergencyMessage(userId, message, agentId = null) {
    try {
      // Check if message is the agent verification code
      if (message === this.AGENT_VERIFICATION_CODE) {
        // Clear any pending states
        this.clearAllStates(userId);

        // Update user status to active
        await User.findOneAndUpdate(
          { userId },
          {
            $set: {
              workQueueStatus: 'NORMAL',
              status: 'ACTIVE',
              lastVerifiedAt: new Date()
            }
          }
        );

        // Schedule next check-in
        const now = new Date();
        const checkInHours = Number(process.env.CHECK_IN_INTERVAL_HOURS) || 3;
        const nextCheckIn = new Date(now.getTime() + checkInHours * 60 * 60 * 1000);
        await User.updateCheckInSchedule(userId, now, nextCheckIn);

        return {
          success: true,
          message: "Escalation exited successfully. Regular check-ins have been reactivated."
        };
      }

      // Check if message is a cancellation request
      if (message.toLowerCase().includes('cancel') || message.toLowerCase().includes('stop')) {
        return this.handleEmergencyCancellation(userId, message);
      }

      // Check if message is a verification code
      if (/^\d{4}$/.test(message)) {
        // If this is a user verification code after agent code was sent
        if (this.pendingAgentVerifications.has(userId)) {
          const agentId = this.pendingAgentVerifications.get(userId);
          this.pendingAgentVerifications.delete(userId);
          return this.handleAgentVerification(userId, agentId, message, this.AGENT_VERIFICATION_CODE);
        }

        // If agentId is provided, this is an agent verification
        if (agentId) {
          return this.handleAgentVerification(userId, agentId, message, this.AGENT_VERIFICATION_CODE);
        }

        // Otherwise, it's a regular user verification
        return this.handleVerificationCode(userId, message);
      }

      // Check if message is a tap-in confirmation
      if (message.toUpperCase() === 'TAP IN') {
        return this.handleTapInConfirmation(userId, message);
      }

      // Handle other emergency messages
      return {
        success: false,
        message: "Please provide a valid verification code or command."
      };

    } catch (error) {
      logger.error('Error handling emergency message:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Start agent verification process
   * @param {string} userId - User ID
   * @param {string} agentId - Agent ID
   */
  async startAgentVerification(userId, agentId) {
    try {
      // Store the agent ID for the pending verification
      this.pendingAgentVerifications.set(userId, agentId);

      return {
        success: true,
        message: "Please enter the agent verification code (1202) to begin the safety check."
      };
    } catch (error) {
      logger.error('Error starting agent verification:', {
        userId,
        agentId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Clear pending cancellation
   * @param {string} userId - User ID
   */
  clearPendingCancellation(userId) {
    this.pendingCancellations.delete(userId);
  }

  /**
   * Clear all pending states
   * @param {string} userId - User ID
   */
  clearAllStates(userId) {
    this.pendingCancellations.delete(userId);
    this.verificationAttempts.delete(userId);
    this.pendingAgentVerifications.delete(userId);
  }
}

module.exports = new EmergencyHandler(); 
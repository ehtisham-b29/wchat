const crypto = require("crypto");
const logger = require("../utils/logger");
const { ApiError, unauthorized, forbidden } = require("../utils/errors");

/**
 * Middleware to validate Twilio webhook signatures
 * @param {Object} options - Configuration options
 * @param {string} options.authToken - Twilio auth token
 * @param {boolean} options.validate - Whether to validate the signature (useful for development)
 */
const twilioWebhookValidator = (options = {}) => {
  const authToken = options.authToken || process.env.TWILIO_AUTH_TOKEN;
  // Only validate in production by default, unless explicitly set
  const shouldValidate =
    options.validate !== undefined
      ? options.validate
      : process.env.NODE_ENV === "production";

  if (!authToken && shouldValidate) {
    logger.error("TWILIO_AUTH_TOKEN is missing but validation is enabled");
    throw new Error("TWILIO_AUTH_TOKEN is required for webhook validation");
  }

  return (req, res, next) => {
    // Skip validation if not required (e.g., in development)
    if (!shouldValidate) {
      logger.debug("Skipping Twilio webhook signature validation");
      return next();
    }

    try {
      const signature = req.headers["x-twilio-signature"];

      if (!signature) {
        logger.warn("Missing Twilio signature header");
        return next(unauthorized("Missing Twilio signature header"));
      }

      // Get the full URL of the request
      const url = `${req.protocol}://${req.get("host")}${req.originalUrl}`;

      // Create the validation string
      const data = Object.keys(req.body)
        .sort()
        .reduce((acc, key) => acc + key + req.body[key], url);

      // Generate the expected signature
      const hmac = crypto.createHmac("sha1", authToken);
      const expectedSignature = Buffer.from(
        hmac.update(data).digest("hex"),
        "hex"
      ).toString("base64");

      // Compare signatures
      if (signature !== expectedSignature) {
        logger.warn("Invalid Twilio webhook signature", {
          receivedSignature: signature,
          url,
          // Don't log the full body in production for security
          bodyKeys: Object.keys(req.body),
        });
        return next(forbidden("Invalid webhook signature"));
      }

      logger.debug("Twilio webhook signature validated successfully");
      next();
    } catch (error) {
      logger.error("Error validating Twilio webhook signature", {
        error: error.message,
        stack: error.stack,
      });
      next(
        error instanceof ApiError
          ? error
          : new ApiError("Webhook validation error", 500)
      );
    }
  };
};

module.exports = twilioWebhookValidator;

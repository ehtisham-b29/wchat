const cron = require('node-cron');
const endOfDayService = require('../services/endOfDayService');
const logger = require('../utils/logger');

class EndOfDayScheduler {
  constructor() {
    // Schedule end-of-day tasks to run at 23:55 every day
    this.schedule = cron.schedule('55 23 * * *', this.runEndOfDayTasks.bind(this));
  }

  /**
   * Run end-of-day tasks
   */
  async runEndOfDayTasks() {
    try {
      logger.info('Starting scheduled end-of-day tasks');
      
      const result = await endOfDayService.processEndOfDay();
      
      logger.info('End-of-day tasks completed successfully', {
        tapInReport: result.tapInReport,
        archivedUsers: result.archivedUsers,
        cancellationReport: result.cancellationReport
      });
    } catch (error) {
      logger.error('Error running end-of-day tasks:', {
        error: error.message,
        stack: error.stack
      });
    }
  }

  /**
   * Start the scheduler
   */
  start() {
    this.schedule.start();
    logger.info('End-of-day scheduler started');
  }

  /**
   * Stop the scheduler
   */
  stop() {
    this.schedule.stop();
    logger.info('End-of-day scheduler stopped');
  }
}

module.exports = new EndOfDayScheduler(); 
/**
 * Controller for user-related operations
 */
const dynamoDbService = require("../services/dynamoDbService");
const logger = require("../utils/logger");

class UserController {
  /**
   * Find a user by phone number
   * @param {string} phoneNumber - The phone number to search for
   * @returns {Promise<Object|null>} - The user object or null if not found
   */
  async findUserByPhoneNumber(phoneNumber) {
    try {
      // Explicitly provide the table name to ensure it's not null
      const result = await dynamoDbService.query({
        tableName: process.env.DYNAMODB_TABLE_NAME || "Users", // Explicitly set table name with fallback
        keyConditionExpression: "phoneNumber = :phoneNumber",
        expressionAttributeValues: {
          ":phoneNumber": phoneNumber,
        },
      });

      return result.Items.length > 0 ? result.Items[0] : null;
    } catch (error) {
      logger.error(`Error finding user by phone number: ${error.message}`);
      throw error;
    }
  }
}

module.exports = new UserController();

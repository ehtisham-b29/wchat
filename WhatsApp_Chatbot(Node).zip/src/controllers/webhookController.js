const User = require("../models/user");
const Session = require("../models/session");
const emergencyHandler = require('../handlers/emergencyHandler');
const Verification = require("../models/verification");
const twilioService = require("../services/twilio/twilioService");
const chatgpt = require("../services/ai/chatgpt");
const googleServices = require("../services/google/googleServices");
const flightStatus = require("../services/amadeus/flightStatus");
const logger = require("../utils/logger");
const { ApiError, asyncHandler } = require("../middleware/errorHandler");
const { getNextCheckInTime, getNextSevenAM } = require('../utils/checkinUtils');
const bcrypt = require('bcrypt');
const journeyCompletionService = require('../services/journeyCompletionService');

/**
 * Utility function to sleep for a specified number of milliseconds
 * @param {number} ms - Milliseconds to sleep
 * @returns {Promise<void>}
 */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Process incoming WhatsApp messages from Twilio
 */
const processWhatsAppWebhook = asyncHandler(async (req, res) => {
  // Extract information from the message
  const message = req.body.Body;
  const from = req.body.From; // Will be in format 'whatsapp:+1234567890'
  const whatsappId = from.replace("whatsapp:", "");
  const messageId = req.body.MessageSid;

  logger.info(`Received WhatsApp message from ${whatsappId}`, { messageId });

  // Handle the message
  try {
    const response = await handleIncomingMessage(whatsappId, message);

    // For Twilio webhooks, respond with TwiML
    res.set("Content-Type", "text/xml");
    res.send(`<?xml version="1.0" encoding="UTF-8"?><Response></Response>`);
  } catch (error) {
    logger.error(`Error handling WhatsApp message: ${error.message}`);

    // Still return 200 to Twilio so it doesn't retry
    res.set("Content-Type", "text/xml");
    res.send(`<?xml version="1.0" encoding="UTF-8"?><Response></Response>`);
  }
});

/**
 * Process Twilio voice call events
 */
const processVoiceCallWebhook = asyncHandler(async (req, res) => {
  const callSid = req.body.CallSid;
  const from = req.body.From;
  const to = req.body.To;
  const callStatus = req.body.CallStatus;

  logger.info(`Received voice call webhook: ${callStatus}`, {
    callSid,
    from,
    to,
  });

  // Handle different call statuses
  switch (callStatus) {
    case "initiated":
    case "ringing":
      // Call is being initiated or ringing
      break;
    case "in-progress":
      // Call is in progress
      break;
    case "completed":
      // Call has ended
      break;
    case "failed":
    case "busy":
    case "no-answer":
      // Call failed, was busy, or was not answered
      logger.warn(`Call failed with status: ${callStatus}`, { callSid });
      // Maybe trigger fallback to SMS
      break;
  }

  // For Twilio webhooks, respond with TwiML
  res.set("Content-Type", "text/xml");
  res.send(`<?xml version="1.0" encoding="UTF-8"?><Response></Response>`);
});

/**
 * Handle an incoming message
 * @param {string} whatsappId - Sender's WhatsApp ID
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleIncomingMessage = async (whatsappId, message) => {
  // Clean the phone number (remove 'whatsapp:' prefix if present)
  const phoneNumber = whatsappId.replace("whatsapp:", "");

  // Look up the user or create if not exists
  let user = await User.getByPhoneNumber(phoneNumber);
  let session = null;

  if (user) {
    // Get or create a session
    session =
      (await Session.getActiveByWhatsAppId(whatsappId)) ||
      (await Session.create({
        userId: user.userId,
        phoneNumber,
        whatsappId,
      }));
  } else {
    // New user - start onboarding
    user = await User.create({
      phoneNumber,
      whatsappId,
      status: "ONBOARDING",
    });

    // Create a new session
    session = await Session.create({
      userId: user.userId,
      phoneNumber,
      whatsappId,
      state: "ONBOARDING_START",
    });

    // Extract location from phone number
    const { countryCode, cityCode } =
      twilioService.extractLocationFromPhone(phoneNumber);
    const locationInfo = await googleServices.getLocationFromCodes(
      countryCode,
      cityCode
    );

    // Send welcome message for new users
    await onboardNewUser(user, session, locationInfo);
    return;
  }

  // Add the message to the session history
  await Session.addMessage(session.sessionId, {
    role: "user",
    content: message,
    timestamp: new Date().toISOString(),
  });

  // Process special codes first (emergency, etc.)
  if (await processSpecialCodes(user, message)) {
    return;
  }

  // Process Tap-Out codes (Day Code + Tap-Out Code)
  if (await handleTapOutAttempt(user, session, message)) {
    return;
  }

  // Handle different session states
  console.log("🐛🐛🐛🐛🐛🐛🐛🐛", session.state)
  switch (session.state) {
    case "AWAITING_NAME":
      await handleAwaitingName(user, session, message);
      break;
    case "ONBOARDING_START":
      await handleOnboardingStart(user, session, message);
      break;
    case "AWAITING_BOOKING_NUMBER":
      await handleAwaitingBookingNumber(user, session, message);
      break;
    case "AWAITING_DOB":
      await handleAwaitingDOB(user, session, message);
      break;
    case "AWAITING_PASSCODE_SETUP":
      await handleAwaitingPasscodeSetup(user, session, message);
      break;
    case "AWAITING_GOOD_NIGHT_CODE":
      await handleAwaitingGoodNightCode(user, session, message);
      break;
    case "AWAITING_VERIFICATION_CODE":
      await handleAwaitingVerificationCode(user, session, message);
      break;
    case "AWAITING_CHECKIN_PASSCODE":
      await handleAwaitingCheckinPasscode(user, session, message);
      break;
    default:
      // General conversation - use ChatGPT to handle
      await handleGeneralConversation(user, session, message);
      break;
  }
};

/**
 * Process special codes like SOS, MED, etc.
 * @param {Object} user - User object
 * @param {string} message - Message content
 * @returns {Promise<boolean>} - True if a special code was processed
 */
const processSpecialCodes = async (user, message) => {
  const upperMessage = message.trim();

  // Check for repeated codes to exit escalation
  const words = message.trim().split(/\s+/);
  if (user.status == "FLAGGED") {
    if (words.length === 2 && words[0] === words[1]) {
      const code = words[0];

      // Check if it matches either the passcode or good night code
      const isPasscode = await User.verifyPasscode(user.userId, code);
      const isGoodNightCode = user.goodNightCode && await bcrypt.compare(code, user.goodNightCode);

      if (isPasscode || isGoodNightCode) {
        // Check if we need to reset the daily count
        const now = new Date();
        const lastReset = user.escalationTerminations?.lastReset || new Date(0);
        const isNewDay = lastReset.toDateString() !== now.toDateString();

        // Reset count if it's a new day
        if (isNewDay) {
          await User.update(user.userId, {
            'escalationTerminations.count': 0,
            'escalationTerminations.lastReset': now
          });
        }

        // Check if user has reached the daily limit
        await sleep(1000);
        const currentCount = user.escalationTerminations?.count || 0;
        if (currentCount >= 3) {
          await twilioService.sendWhatsAppMessage(
            user.phoneNumber,
            "❌ You have reached the maximum number of escalation terminations for today. Please try again tomorrow."
          );
          return true;
        }

        // Exit escalation    
        await User.update(user.userId, {
          workQueueStatus: 'NONE',
          status: 'ACTIVE',
          'escalationTerminations.count': currentCount + 1,
          'escalationTerminations.lastReset': now
        });

        // Schedule next check-in
        const nextCheckIn = getNextCheckInTime(now);
        await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          `✅ Escalation exited successfully. Regular check-ins have been reactivated. (${currentCount + 1}/3 terminations used today)`
        );

        return true;
      }
    }
  }

  // Check for repeated goodnight code to exit sleep mode
  if (words.length === 2 && words[0] === words[1]) {
    const code = words[0];
    const isGoodNightCode = user.goodNightCode && await bcrypt.compare(code, user.goodNightCode);

    if (isGoodNightCode) {
      const now = new Date();
      const hour = now.getHours();
      const minute = now.getMinutes();

      // Check if it's within the allowed time window (9 PM to 4:59 AM)
      const isNightTime = (hour >= 21 || (hour < 5 && minute < 59));

      if (isNightTime) {
        // Schedule next check-in for 8 hours later
        const nextCheckIn = new Date(now.getTime() + 8 * 60 * 60 * 1000);
        await User.updateCheckInSchedule(user.userId, now, nextCheckIn);
        await User.update(user.userId, { workQueueStatus: 'NONE' });

        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          "Good night! We'll check in with you again in 8 hours."
        );

        return true;
      } else {
        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          "❌ Good Night mode can only be activated between 9:00 PM and 4:59 AM."
        );
        return true;
      }
    }
  }

  // Check for single goodnight code to enter sleep mode
  const isGoodNightCode = user.goodNightCode && await bcrypt.compare(message.trim(), user.goodNightCode);
  if (isGoodNightCode) {
    const now = new Date();
    const hour = now.getHours();
    const minute = now.getMinutes();

    // Check if it's within the allowed time window (9 PM to 4:59 AM)
    const isNightTime = (hour >= 21 || (hour < 5 && minute < 59));

    if (isNightTime) {
      // Schedule next check-in for 8 hours later
      const nextCheckIn = new Date(now.getTime() + 8 * 60 * 60 * 1000);
      await User.updateCheckInSchedule(user.userId, now, nextCheckIn);
      await User.update(user.userId, { workQueueStatus: 'NONE' });

      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "Good night! We'll check in with you again in 8 hours."
      );

      return true;
    } else {
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "❌ Good Night mode can only be activated between 9:00 PM and 4:59 AM."
      );
      return true;
    }
  }

  // Emergency SOS code
  if (upperMessage === "SOS") {
    logger.warn(`SOS received from user ${user.userId}`);

    // Send confirmation to user
    await twilioService.sendWhatsAppMessage(
      user.phoneNumber,
      "🚨 SOS RECEIVED. Emergency services have been notified. An agent will contact you immediately."
    );

    // In a real app, you would trigger an emergency dispatch here
    // For example, add to an emergency queue, notify human agents, etc.

    // You could also make a direct call to the user

    return true;
  }

  // Medical emergency code
  if (upperMessage === "MED") {
    logger.warn(`Medical emergency received from user ${user.userId}`);

    // Send confirmation to user
    await twilioService.sendWhatsAppMessage(
      user.phoneNumber,
      "🚑 MEDICAL ALERT RECEIVED. Medical assistance has been notified. Stay where you are if possible."
    );

    // In a real app, trigger medical dispatch

    return true;
  }


  // Delay check-in (ZZZ + passcode)
  if (upperMessage.startsWith("ZZZ ")) {
    const passcode = upperMessage.substring(4).trim();
    console.log("ZZZ passcode", passcode, upperMessage)
    const isValid = await User.verifyPasscode(user.userId, passcode);

    if (isValid) {
      // Delay next check-in by 5 hours
      const now = new Date();
      const nextCheckIn = new Date(now.getTime() + 5 * 60 * 60 * 1000); // +5 hours

      await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "✅ Your check-in has been delayed by 5 hours. Rest well."
      );

      return true;
    } else {
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "❌ Invalid passcode. Please try again."
      );
      return true;
    }
  }

  // Leave an escalation
  if (upperMessage.startsWith("SEC ")) {
    const escalation = upperMessage.substring(4).trim();

    // If the code is 1202, handle it through the emergency handler
    if (escalation === '1202') {
      const result = await emergencyHandler.handleEmergencyMessage(user.userId, escalation);

      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        result.message
      );
    } else {
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        `Escalation received: ${escalation}`
      );
    }

    return true;
  }

  return false;
};

/**
 * Handles Tap-Out attempts using Day Code + Tap-Out Code
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<boolean>} - True if the message was a Tap-Out attempt (valid or invalid), false otherwise.
 */
const handleTapOutAttempt = async (user, session, message) => {
  const messageParts = message.trim().split(' ');

  // Expecting exactly two parts: Day Code and Tap-Out Code
  if (messageParts.length !== 2) {
    return false; // Not a Tap-Out attempt message
  }

  const [dayCode, tapOutCode] = messageParts;

  // Verify the Day Code (user's passcode)
  const isDayCodeValid = await User.verifyPasscode(user.userId, dayCode);

  if (!isDayCodeValid && !isNaN(parseInt(tapOutCode))) {
    // Invalid Day Code
    const responseMessage = "❌ Invalid Day Code for Tap-Out. Please ensure you are using your correct Day Code followed by the Tap-Out code.";
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
    return true; // Message handled as an invalid Tap-Out attempt
  }
  if (isDayCodeValid) {
    // Day Code is valid, now look up the Tap-Out Code in the database
    // NOTE: This requires a TapOutCode model/service to be implemented
    // For now, we'll use a placeholder function call.
    // Assume TapOutCode.getDetailsByCode returns { success: boolean, details: { countryCode, cityCode, eventCode }, error: string }
    let tapOutDetails;
    try {
      // This is a placeholder - replace with actual database lookup
      // Example: tapOutDetails = await TapOutCode.getDetailsByCode(tapOutCode);

      // *** Placeholder Logic (Replace with actual DB lookup) ***
      // For demonstration, let's assume some valid tapOutCodes and their details
      const tapOutData = {
        '118': { country: 'Colombia', city: 'Medellin', eventCode: '08', description: 'Medellin Departure; Trip Complete' },
        '117': { country: 'Colombia', city: 'Medellin', eventCode: '07', description: 'Medellin Departure; Trip Continue' },
        '116': { country: 'Colombia', city: 'Medellin', eventCode: '06', description: 'Medellin Arrival; Trip Continued' },
        '119': { country: 'Colombia', city: 'Medellin', eventCode: '09', description: 'Medellin Local Handoff-Sending' },
        '1198': { country: 'Colombia', city: 'Medellin', eventCode: '98', description: 'Medellin Local Handoff-Received' },
        '1119': { country: 'Colombia', city: 'Guatape', eventCode: '09', description: 'Guatape Local Handoff-Sending' },
        '11198': { country: 'Colombia', city: 'Guatape', eventCode: '98', description: 'Guatape Local Handoff-Received' },
        '128': { country: 'Colombia', city: 'Cartagena', eventCode: '08', description: 'Cartagena Departure; Trip Complete' },
        '127': { country: 'Colombia', city: 'Cartagena', eventCode: '07', description: 'Cartagena Departure; Trip Continue' },
        '126': { country: 'Colombia', city: 'Cartagena', eventCode: '06', description: 'Cartagena Arrival; Trip Continued' },
        '138': { country: 'Colombia', city: 'Bogota', eventCode: '08', description: 'Bogota Departure; Trip Complete' },
        '137': { country: 'Colombia', city: 'Bogota', eventCode: '07', description: 'Bogota Departure; Trip Continue' },
        '136': { country: 'Colombia', city: 'Bogota', eventCode: '06', description: 'Bogota Arrival; Trip Continued' },
        '218': { country: 'Mexico', city: 'Cancun', eventCode: '08', description: 'Cancun Departure; Trip Complete' },
        '217': { country: 'Mexico', city: 'Cancun', eventCode: '07', description: 'Cancun Departure; Trip Continue' },
        '216': { country: 'Mexico', city: 'Cancun', eventCode: '06', description: 'Cancun Arrival; Trip Continued' },
        '219': { country: 'Mexico', city: 'Cancun', eventCode: '09', description: 'Cancun Local Handoff-Sending' },
        '2198': { country: 'Mexico', city: 'Cancun', eventCode: '98', description: 'Cancun Local Handoff-Received' },
        '2119': { country: 'Mexico', city: 'Chiten Itza', eventCode: '09', description: 'Chiten Itza Local Handoff-Sending' },
        '21198': { country: 'Mexico', city: 'Chiten Itza', eventCode: '98', description: 'Chiten Itza Local Handoff-Received' },
        '228': { country: 'Mexico', city: 'Tulum', eventCode: '08', description: 'Tulum Departure; Trip Complete' },
        '227': { country: 'Mexico', city: 'Tulum', eventCode: '07', description: 'Tulum Departure; Trip Continue' },
        '226': { country: 'Mexico', city: 'Tulum', eventCode: '06', description: 'Tulum Arrival; Trip Continued' },
        '229': { country: 'Mexico', city: 'Tulum', eventCode: '09', description: 'Tulum Local Handoff-Sending' },
        '2298': { country: 'Mexico', city: 'Tulum', eventCode: '98', description: 'Tulum Local Handoff-Received' },
        '238': { country: 'Mexico', city: 'MXCD', eventCode: '08', description: 'MXCD Departure; Trip Complete' },
        '237': { country: 'Mexico', city: 'MXCD', eventCode: '07', description: 'MXCD Departure; Trip Continue' },
        '236': { country: 'Mexico', city: 'MXCD', eventCode: '06', description: 'MXCD Arrival; Trip Continued' },

      };

      if (tapOutData[tapOutCode]) {
        tapOutDetails = { success: true, details: tapOutData[tapOutCode] };
      } else {
        tapOutDetails = { success: false, error: 'Tap-Out code not found' };
      }
      // *** End Placeholder Logic ***

    } catch (error) {
      logger.error(`Error looking up Tap-Out code ${tapOutCode}: ${error.message}`);
      const responseMessage = "Sorry, there was an error processing your Tap-Out code. Please try again later.";
      await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
      await Session.addMessage(session.sessionId, {
        role: "assistant",
        content: responseMessage,
        timestamp: new Date().toISOString(),
      });
      return true; // Message handled due to error
    }

    if (!tapOutDetails.success) {
      // Tap-Out Code not found or invalid
      const responseMessage = "❌ Invalid Tap-Out code. Please ensure you are using the correct Tap-Out code for your current location and event.";
      await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
      await Session.addMessage(session.sessionId, {
        role: "assistant",
        content: responseMessage,
        timestamp: new Date().toISOString(),
      });
      return true; // Message handled as an invalid Tap-Out attempt
    }

    // Both codes are valid, process the Tap-Out event
    const { countryCode, cityCode, eventCode, description } = tapOutDetails.details;
    logger.info(`Processing Tap-Out for user ${user.userId}: ${dayCode} ${tapOutCode}`, { countryCode, cityCode, eventCode });

    let responseMessage = `✅ Tap-Out successful: ${description}.`;

    // Implement logic based on eventCode
    switch (eventCode) {
      case '08': // Departure; Trip Complete
        responseMessage += " Your trip is now complete. Safe travels!";
        // Call the journey completion service
        await journeyCompletionService.completeJourneyWithTapOut(user.userId, tapOutDetails.details);
        break;
      case '07': // Departure; Trip Continues
        responseMessage += " Please check in when you arrive at your next destination.";
        await journeyCompletionService.handleTripContinuedTapOut(user.userId, tapOutDetails.details);
        break;
      case '06': // Arrival; Trip Continued
        responseMessage += " Welcome to your next destination! We will resume regular check-ins.";
        await journeyCompletionService.handleArrivalContinuedTapOut(user.userId, tapOutDetails.details);
        break;
      case '09': // Local Handoffs (Sending)
        responseMessage += " Please use the Local Handoff Success code upon arrival at your day-trip destination.";
        await journeyCompletionService.handleLocalHandoffSendingTapOut(user.userId, tapOutDetails.details);
        break;
      case '98': // Local Handoff completed (Received)
        responseMessage += " Welcome to your day-trip destination! Regular check-ins will resume.";
        await journeyCompletionService.handleLocalHandoffReceivedTapOut(user.userId, tapOutDetails.details);
        break;
      default:
        // Handle unknown event codes or log a warning
        logger.warn(`Unknown Tap-Out event code received: ${eventCode}`);
        responseMessage = "Successfully processed your Tap-Out, but the event code was not recognized.";
        // Decide if you want to return true or false here - returning true means the message was processed
        return true;
    }

    // Send confirmation message
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    return true;
  }

  // Message was successfully handled as a Tap-Out
};

/**
 * Onboard a new user
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {Object} locationInfo - Location information
 * @returns {Promise<void>} - Nothing
 */
const onboardNewUser = async (user, session, locationInfo) => {
  // Get localized greeting based on country code
  const getLocalizedGreeting = (countryCode) => {
    const greetings = {
      '1': "Hello Traveler, how are you? I'm Magellan, your travel companion here to help assure your safety during your journey. Who do I have the pleasure of speaking with today?", // US/Canada
      '44': "Hello Traveler, how are you? I'm Magellan, your travel companion here to help assure your safety during your journey. Who do I have the pleasure of speaking with today?", // UK
      '91': "नमस्ते यात्री, कैसे हैं आप? मैं मैगलन हूं, आपका यात्रा साथी जो आपकी यात्रा के दौरान आपकी सुरक्षा सुनिश्चित करने में मदद करने के लिए है। आज मुझे किससे बात करने का सौभाग्य मिला?", // India
      '86': "你好旅行者，你好吗？我是麦哲伦，你的旅行伙伴，在这里帮助确保你旅途的安全。今天我有幸和谁说话？", // China
      '81': "こんにちは旅行者、お元気ですか？マゼランです。あなたの旅の安全を確保するお手伝いをする旅の仲間です。今日は誰とお話しできるでしょうか？", // Japan
      '49': "Hallo Reisender, wie geht es Ihnen? Ich bin Magellan, Ihr Reisebegleiter, der hier ist, um Ihre Sicherheit während Ihrer Reise zu gewährleisten. Mit wem habe ich heute das Vergnügen zu sprechen?", // Germany
      '33': "Bonjour Voyageur, comment allez-vous ? Je suis Magellan, votre compagnon de voyage, ici pour assurer votre sécurité pendant votre voyage. Qui ai-je le plaisir de rencontrer aujourd'hui ?", // France
      '61': "Hello Traveler, how are you? I'm Magellan, your travel companion here to help assure your safety during your journey. Who do I have the pleasure of speaking with today?", // Australia
    };
    return greetings[countryCode] || "Hello Traveler, how are you? I'm Magellan, your travel companion here to help assure your safety during your journey. Who do I have the pleasure of speaking with today?";
  };

  // Send localized greeting
  const initialGreeting = getLocalizedGreeting(locationInfo.countryCode);
  await twilioService.sendWhatsAppMessage(user.phoneNumber, initialGreeting);

  // Add initial greeting to session history
  await Session.addMessage(session.sessionId, {
    role: "assistant",
    content: initialGreeting,
    timestamp: new Date().toISOString(),
  });

  // Update user with detected location in the correct format
  await User.update(user.userId, {
    location: {
      countryCode: locationInfo.countryCode,
      cityCode: locationInfo.cityCode,
      formattedAddress: `${locationInfo.city}, ${locationInfo.country}`,
      latitude: locationInfo.latitude || 0,
      longitude: locationInfo.longitude || 0,
      timezone: locationInfo.timezone || 'UTC',
      language: locationInfo.language || 'en'
    },
    status: 'ONBOARDING',
    onboardingStep: 'AWAITING_NAME'
  });

  // Update session state to await name
  await Session.updateState(session.sessionId, "AWAITING_NAME");
};

/**
 * Handle name collection state
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingName = async (user, session, message) => {
  // Store the name
  await User.update(user.userId, {
    name: message.trim(),
    onboardingStep: 'AWAITING_BOOKING_NUMBER'
  });

  // Ask for booking number
  const responseMessage = "Thank you! To get started, please share your booking number or journey continuation code. If you you don't have a code, please visit our website TapinGlobal.com to sign up. Once you have a reservation code, come back here and insert it. I'll keep an eye out for you!";

  await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

  // Add to session history
  await Session.addMessage(session.sessionId, {
    role: "assistant",
    content: responseMessage,
    timestamp: new Date().toISOString(),
  });

  // Update session state to next step
  await Session.updateState(session.sessionId, "AWAITING_BOOKING_NUMBER");
};

/**
 * Handle the initial onboarding state
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleOnboardingStart = async (user, session, message) => {
  // Ask for booking number
  const responseMessage = "To get started, please share your booking number.";

  await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

  // Add to session history
  await Session.addMessage(session.sessionId, {
    role: "assistant",
    content: responseMessage,
    timestamp: new Date().toISOString(),
  });

  // Update session state to next step
  await Session.updateState(session.sessionId, "AWAITING_BOOKING_NUMBER");
};

/**
 * Handle the booking number collection state
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingBookingNumber = async (user, session, message) => {
  // Check if user doesn't have a code
  if (message.toLowerCase().includes("no code") ||
    message.toLowerCase().includes("don't have") ||
    message.toLowerCase().includes("don't have a code") ||
    message.toLowerCase().includes("don't have code") ||
    message.toLowerCase().includes("no reservation") ||
    message.toLowerCase().includes("don't have reservation")) {

    const responseMessage = "Please visit our website at tapinglobal.com and sign up. After you signup, you will receive a reservation code. Once you have that, come back here and insert it to get started. I'll be here waiting for you!";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    return;
  }

  // Validate booking number (simple example, in a real app would check against a database)
  const bookingNumber = message.trim().toUpperCase();

  if (bookingNumber.match(/^[A-Z0-9]{6,10}$/)) {
    // Valid format
    await User.update(user.userId, { bookingNumber });

    // Ask for DOB
    const responseMessage =
      "Thanks! For security, please enter your date of birth (DD/MM/YYYY).";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    // Update session state to next step
    await Session.updateState(session.sessionId, "AWAITING_DOB");
  } else {
    // Invalid format
    const responseMessage =
      "I couldn't recognize that booking number. Please enter a valid booking number (6-10 alphanumeric characters).";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * Handle the DOB collection state
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingDOB = async (user, session, message) => {
  // Validate DOB format
  const dobRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = message.match(dobRegex);

  if (match) {
    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const year = parseInt(match[3], 10);

    // Basic validation
    if (
      day > 0 &&
      day <= 31 &&
      month > 0 &&
      month <= 12 &&
      year > 1900 &&
      year < 2023
    ) {
      const dob = `${day.toString().padStart(2, "0")}/${month
        .toString()
        .padStart(2, "0")}/${year}`;

      await User.update(user.userId, { dateOfBirth: dob });

      // Ask for passcode setup
      const responseMessage = `
Our set up process is simple, you'll create 2 codes:
1. A Tap-In code for all check-ins during the day
2. A Good Night code (we'll set this up next)

For your Tap-In code, choose something simple yet personal that you'll remember easily. Here are some examples:
• First name and last name of a family member (not on the trip)
• Favorite animal or color
• Your pet's name, type and color
• Favorite team and city
• Favorite Player's first and last name
• City or state you live in
• College name or year graduated

Please enter your Tap-In code now.
      `.trim();

      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        responseMessage
      );

      // Add to session history
      await Session.addMessage(session.sessionId, {
        role: "assistant",
        content: responseMessage,
        timestamp: new Date().toISOString(),
      });

      // Update session state to next step
      await Session.updateState(session.sessionId, "AWAITING_PASSCODE_SETUP");
    } else {
      // Invalid date values
      const responseMessage =
        "That doesn't seem to be a valid date. Please enter your date of birth in DD/MM/YYYY format.";

      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        responseMessage
      );

      // Add to session history
      await Session.addMessage(session.sessionId, {
        role: "assistant",
        content: responseMessage,
        timestamp: new Date().toISOString(),
      });
    }
  } else {
    // Invalid format
    const responseMessage =
      "I couldn't recognize that date format. Please enter your date of birth as DD/MM/YYYY, for example: 31/12/1990";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * Handle the passcode setup state
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingPasscodeSetup = async (user, session, message) => {
  const passcode = message.trim();

  // Validate passcode (simple validation, can be more complex)
  if (passcode.length >= 4) {
    // Update user with passcode
    await User.update(user.userId, {
      passcode,
      onboardingStep: 'AWAITING_GOOD_NIGHT_CODE',
    });

    // Ask for good night code
    const responseMessage = `\nThank you! Now, let's set up your Good Night code.\n\nThis code is used when you're safe, in your room and in for the night. It will pause check-ins for 8 hours.\n\nChoose something simple yet personal that you'll remember easily. Here are some examples:\n• First name and last name of a family member (not on the trip)\n• Favorite animal or color\n• Your pet's name, type and color\n• Favorite team and city\n• Favorite Player's first and last name\n• City or state you live in\n• College name or year graduated\n\nPlease enter your Good Night code now.`.trim();

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    // Update session state to next step
    await Session.updateState(session.sessionId, "AWAITING_GOOD_NIGHT_CODE");
  } else {
    // Invalid passcode
    const responseMessage =
      "Your passcode should be at least 4 characters long. Please try again.";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * New handler for good night code
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingGoodNightCode = async (user, session, message) => {
  const goodNightCode = message.trim();

  if (goodNightCode.length >= 4) {
    // Update user with good night code and complete onboarding
    await User.update(user.userId, {
      goodNightCode,
      onboardingStep: 'COMPLETED',
      status: 'ACTIVE',
      verified: true,
    });

    // Schedule first check-in
    const now = new Date();
    const checkInHours = Number(process.env.CHECK_IN_INTERVAL_HOURS) || 3;
    const nextCheckIn = new Date(now.getTime() + checkInHours * 60 * 60 * 1000);

    await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

    // Confirm setup
    const responseMessage = `\n✅ You're all set! Here's how we work:\n\nEvery few hours we'll text you "Tap-In". Respond to our message with your day code and that's it.\n\nIf you miss the code, we'll call you to verify that you're safe.\n\nLastly, if you miss our call, we'll send someone to your location no questions asked, to ensure you're safe.\n\nIf we are in route but you see we're on our way, just text us your day code twice to cancel the in person interaction and let us know you're ok. For example, if your day code is blue, simply text us "Blue Blue" and that will cancel the in person escalation.\n`.trim();

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    // Update session state to general conversation
    await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
  } else {
    // Invalid good night code
    const responseMessage =
      "Your Good Night code should be at least 4 characters long. Please try again.";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * Handle verification code entry
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingVerificationCode = async (user, session, message) => {
  const code = message.trim();

  const verification = await Verification.getActiveByUserId(user.userId);

  // Check if verification exists and is not empty
  if (!verification || verification.length === 0) {
    const responseMessage = "Sorry, we couldn't find your verification session. Please try again later.";
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
    await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
    return;
  }

  const verificationId = verification[0].verificationId;

  // Verify the code
  const isValid = await Verification.verifyCode(verificationId, code);

  if (isValid) {
    // Schedule next check-in
    const now = new Date();
    const checkInHours = Number(process.env.CHECK_IN_INTERVAL_HOURS) || 3;
    const nextCheckIn = new Date(now.getTime() + checkInHours * 60 * 60 * 1000);
    await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

    let responseMessage = `✅ Verification successful! Your next Tap-In will be in ${checkInHours} hours.`;
    // Handle different verification purposes
    const verificationDetails = await Verification.getById(verificationId);

    switch (verificationDetails.purpose) {
      case "PASSCODE_RESET":
        // Ask for new passcode
        responseMessage +=
          "\n\nPlease enter your new passcode (at least 4 characters).";
        await Session.updateState(session.sessionId, "AWAITING_PASSCODE_SETUP");
        break;
      case "LOGIN":
        // Mark user as verified
        await User.update(user.userId, { verified: true });
        await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
        break;
      default:
        await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
        await User.update(user.userId, { status: "ACTIVE", workQueueStatus: "NONE", lastVerifiedAt: new Date() });
    }

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  } else {
    // Invalid code
    const responseMessage =
      "❌ That verification code is incorrect or expired. Please try again.";

    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * Handle check-in passcode verification
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleAwaitingCheckinPasscode = async (user, session, message) => {
  const passcode = message.trim();

  // Check if this is the good night code
  const isGoodNightCode = await User.verifyPasscode(user.userId, passcode) === false && user.goodNightCode && await bcrypt.compare(passcode, user.goodNightCode);
  const now = new Date();
  const hour = now.getHours();

  if (isGoodNightCode && (hour >= 21 || hour < 6)) {
    // Good night code during night hours: set next check-in to 6am
    const nextMorning = getNextSevenAM(now);
    await User.updateCheckInSchedule(user.userId, now, nextMorning);
    await User.update(user.userId, { workQueueStatus: 'NONE' });
    const responseMessage = "Good night! We'll check in with you again at 6:00 AM.";
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
    await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
    return;
  }

  // Verify passcode
  const isValid = await User.verifyPasscode(user.userId, passcode);

  if (isValid) {
    // Passcode correct, update check-in time
    const nextCheckIn = getNextCheckInTime(now);
    await User.updateCheckInSchedule(user.userId, now, nextCheckIn);
    await User.update(user.userId, { workQueueStatus: 'NONE' });
    const checkInHours = ((nextCheckIn - now) / (60 * 60 * 1000)).toFixed(1);
    const responseMessage = `✅ Thank you for your Tap-In! Your next Tap-In will be in ${checkInHours} hours.`;
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });
    await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
    return;
  }

  // Wrong passcode
  const attempts = (session.context.attempts || 0) + 1;
  const maxAttempts = Number(process.env.MAX_FAILED_ATTEMPTS) || 3;

  if (attempts >= maxAttempts) {
    // Too many failed attempts, escalate
    const responseMessage = `⚠️ Multiple failed check-in attempts. For your safety, we're escalating this to an agent who will contact you shortly.`;

    await twilioService.sendWhatsAppMessage(
      user.phoneNumber,
      responseMessage
    );

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    // In a real app, you would add to an escalation queue here

    // Reset state
    await Session.updateState(session.sessionId, "GENERAL_CONVERSATION");
  } else {
    // Prompt to retry
    const responseMessage = `❌ Incorrect passcode. Please try again. (Attempt ${attempts}/${maxAttempts})`;

    await twilioService.sendWhatsAppMessage(
      user.phoneNumber,
      responseMessage
    );

    // Add to session history
    await Session.addMessage(session.sessionId, {
      role: "assistant",
      content: responseMessage,
      timestamp: new Date().toISOString(),
    });

    // Update attempts in context
    await Session.updateState(
      session.sessionId,
      "AWAITING_CHECKIN_PASSCODE",
      { attempts }
    );
  }
};

/**
 * Handle general conversation with ChatGPT
 * @param {Object} user - User object
 * @param {Object} session - Session object
 * @param {string} message - Message content
 * @returns {Promise<void>} - Nothing
 */
const handleGeneralConversation = async (user, session, message) => {
  // Get recent conversation history
  const recentHistory = await Session.getRecentMessages(session.sessionId, 5);

  // Check for emergency keywords
  const emergencyKeywords = ['help', 'emergency', 'sos', 'danger', 'urgent'];
  const hasEmergency = emergencyKeywords.some(keyword =>
    message.toLowerCase().includes(keyword)
  );

  if (hasEmergency) {
    const responseMessage = "I notice you might be in an emergency. Would you like to use the SOS command? Just type 'SOS' for immediate assistance.";
    await twilioService.sendWhatsAppMessage(user.phoneNumber, responseMessage);
    await Session.addMessage(session.sessionId, {
      role: 'assistant',
      content: responseMessage,
      timestamp: new Date().toISOString()
    });
    return;
  }

  // Check for API-specific queries
  const apiIntegrationService = require('../services/apiIntegrationService');
  let apiResponse = null;

  // Check for flight status query - more flexible pattern
  const flightMatch = message.match(/(?:flight|status)\s+(?:of\s+)?([A-Z0-9]{2}\d{1,4})\s+(?:on\s+)?(\d{4}-\d{2}-\d{2})/i) ||
    message.match(/([A-Z0-9]{2}\d{1,4})\s+(?:on\s+)?(\d{4}-\d{2}-\d{2})/i);
  if (flightMatch) {
    const [_, flightNumber, date] = flightMatch;
    try {
      console.log("✅✅✅", flightNumber, date)
      apiResponse = await apiIntegrationService.getFlightStatus(flightNumber, date);
      if (apiResponse.success) {
        // Use the formatted response from the service
        apiResponse.formatted = apiResponse.formatted || 'Flight information retrieved successfully.';
      } else {
        apiResponse.formatted = `Sorry, I couldn't find information for flight ${flightNumber} on ${date}. Please check the flight number and date.`;
      }
    } catch (error) {
      logger.error(`Error getting flight status: ${error.message}`);
      apiResponse = {
        success: false,
        formatted: 'Sorry, there was an error retrieving the flight information. Please try again.'
      };
    }
  }

  // Check for weather query
  const weatherMatch = message.match(/weather\s+(?:in\s+)?([A-Za-z\s,]+)/i);
  if (weatherMatch) {
    const location = weatherMatch[1].trim();
    apiResponse = await apiIntegrationService.getWeatherInfo(location);
  }

  // Check for location query
  const locationMatch = message.match(/where\s+(?:is\s+)?([A-Za-z\s,]+)/i);
  if (locationMatch) {
    const query = locationMatch[1].trim();
    apiResponse = await apiIntegrationService.getLocationInfo(query);
  }

  // Check for currency conversion query
  const currencyMatch = message.match(/(\d+)\s+([A-Z]{3})\s+(?:to\s+)?([A-Z]{3})/i);
  if (currencyMatch) {
    const [_, amount, fromCurrency, toCurrency] = currencyMatch;
    apiResponse = await apiIntegrationService.getExchangeRate(fromCurrency, toCurrency);
    if (apiResponse.success) {
      apiResponse.formatted = `${amount} ${fromCurrency} = ${(amount * apiResponse.data.rate).toFixed(2)} ${toCurrency}`;
    }
  }

  // If we have an API response, send it
  if (apiResponse) {
    if (apiResponse.success) {
      await twilioService.sendWhatsAppMessage(user.phoneNumber, apiResponse.formatted);
      await Session.addMessage(session.sessionId, {
        role: 'assistant',
        content: apiResponse.formatted,
        timestamp: new Date().toISOString()
      });
    } else {
      const errorMessage = `I'm sorry, I couldn't get that information. ${apiResponse.error}`;
      await twilioService.sendWhatsAppMessage(user.phoneNumber, errorMessage);
      await Session.addMessage(session.sessionId, {
        role: 'assistant',
        content: errorMessage,
        timestamp: new Date().toISOString()
      });
    }
    return;
  }

  // Convert session history to ChatGPT format
  const formattedHistory = recentHistory.map((msg) => ({
    role: msg.role,
    content: msg.content,
  }));

  // Prepare system prompt
  const systemPrompt = `
You are Magellan, a helpful travel assistant chatbot named after Ferdinand Magellan, the Portuguese explorer who is credited as being the first person to circumvent the world.

You are currently operating from Medellin, Colombia.

Company Information:
- Website: tapinglobal.com
- Corporate Address: 1910 Pacific Ave, Suite 2000 Dallas, Tx 75201
- Email: Sales@tapinglobal.com & Escalations@tapinglobal.com

The user's name is ${user.name || "Traveler"}.
They are currently in ${user.location || "an unknown location"}.
Their booking number is ${user.bookingNumber || "unknown"}.

Help with their questions about travel, their itinerary, or safety check-ins.
Keep responses concise and helpful.

You can help with:
- Flight status (e.g., "What's the status of flight BA123 on 2024-03-20?")
- Weather information (e.g., "What's the weather in London?")
- Location information (e.g., "Where is the Eiffel Tower?")
- Currency conversion (e.g., "Convert 100 USD to EUR")

If they ask about flight status, you can check it using their booking details.
If they ask to reset their passcode, guide them through verification.
If they mention an emergency or seem in distress, ask if they need to use the SOS command.

Do not make up information you don't have. Ask for clarification if needed.
  `.trim();

  // Prepare messages for ChatGPT
  const messages = [
    { role: "system", content: systemPrompt },
    ...formattedHistory,
  ];

  // Generate response with ChatGPT
  const responseText = await chatgpt.generateResponse(messages);

  // Send the response
  await twilioService.sendWhatsAppMessage(user.phoneNumber, responseText);

  // Add to session history
  await Session.addMessage(session.sessionId, {
    role: "assistant",
    content: responseText,
    timestamp: new Date().toISOString(),
  });
};

module.exports = {
  processWhatsAppWebhook,
  processVoiceCallWebhook,
};

const textToSpeech = require('@google-cloud/text-to-speech');
const { Client } = require('@googlemaps/google-maps-services-js');
const fs = require('fs');
const util = require('util');
const logger = require('../../utils/logger');

// Create TTS client
const ttsClient = new textToSpeech.TextToSpeechClient({
  keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
});

// Create Maps client
const mapsClient = new Client({});

/**
 * Convert text to speech and save as audio file
 * @param {string} text - Text to convert to speech
 * @param {string} outputFile - Path to save the audio file
 * @param {Object} options - TTS options
 * @returns {Promise<string>} - Path to the saved audio file
 */
const textToSpeechAndSave = async (text, outputFile, options = {}) => {
  try {
    // Configure request
    const request = {
      input: { text },
      voice: {
        languageCode: options.languageCode || 'en-US',
        ssmlGender: options.gender || 'NEUTRAL',
        name: options.voiceName || 'en-US-Neural2-F',
      },
      audioConfig: { audioEncoding: 'MP3' },
    };

    // Perform the TTS request
    const [response] = await ttsClient.synthesizeSpeech(request);
    
    // Write the binary audio content to file
    const writeFile = util.promisify(fs.writeFile);
    await writeFile(outputFile, response.audioContent, 'binary');

    logger.info(`Text-to-speech audio saved to: ${outputFile}`);
    return outputFile;
  } catch (error) {
    logger.error(`Text-to-speech error: ${error.message}`);
    throw new Error(`Text-to-speech failed: ${error.message}`);
  }
};

/**
 * Get location information from phone number's country and city code
 * @param {string} countryCode - Country code from phone number
 * @param {string} cityCode - City/area code from phone number
 * @returns {Promise<Object>} - Location information
 */
const getLocationFromCodes = async (countryCode, cityCode) => {
  try {
    // This is a simplified approach. In a production app, you would:
    // 1. Have a database mapping country/city codes to locations
    // 2. Or use a specialized API for phone number geolocation
    
    // Convert country code to country name (simplified)
    const countryCodes = {
      '1': 'United States',
      '44': 'United Kingdom',
      '33': 'France',
      '49': 'Germany',
      '61': 'Australia',
      '81': 'Japan',
      '86': 'China',
      '91': 'India',
      // Add more as needed
    };
    
    const country = countryCodes[countryCode] || 'Unknown';
    
    if (country === 'Unknown') {
      logger.warn(`Unknown country code: ${countryCode}`);
      return {
        country: 'Unknown',
        city: 'Unknown',
        timezone: 'UTC',
      };
    }
    
    // For a real app, you'd need a more comprehensive database of area codes
    // This is just a simple example for a few US codes
    let city = 'Unknown';
    if (country === 'United States') {
      const areaCodes = {
        '212': 'New York',
        '213': 'Los Angeles',
        '312': 'Chicago',
        '415': 'San Francisco',
        '305': 'Miami',
        // Add more as needed
      };
      city = areaCodes[cityCode] || 'Unknown City';
    }
    
    // Get timezone (in a real app, you'd use a database or API for this)
    // For this example, we'll use a simplified approach
    let timezone = 'UTC';
    if (country === 'United States') {
      timezone = 'America/New_York'; // Simplified
    }
    
    return {
      country,
      city,
      timezone,
    };
  } catch (error) {
    logger.error(`Error getting location from codes: ${error.message}`);
    return {
      country: 'Unknown',
      city: 'Unknown',
      timezone: 'UTC',
    };
  }
};

/**
 * Validate if a location matches the expected location for a user
 * @param {string} userLocation - User's claimed location
 * @param {string} detectedLocation - Location detected from phone number
 * @returns {boolean} - Whether the locations match
 */
const validateLocation = (userLocation, detectedLocation) => {
  // Normalize locations (lowercase, trim)
  const normalizedUserLocation = userLocation.toLowerCase().trim();
  const normalizedDetectedLocation = detectedLocation.toLowerCase().trim();
  
  // Direct match
  if (normalizedUserLocation === normalizedDetectedLocation) {
    return true;
  }
  
  // Check if one contains the other
  if (normalizedUserLocation.includes(normalizedDetectedLocation) || 
      normalizedDetectedLocation.includes(normalizedUserLocation)) {
    return true;
  }
  
  // If a more robust check is needed, you could:
  // 1. Use a geocoding API to convert both to coordinates
  // 2. Check if they're within a certain distance threshold
  // 3. Use a database of city aliases/synonyms
  
  return false;
};

module.exports = {
  textToSpeechAndSave,
  getLocationFromCodes,
  validateLocation
}; 
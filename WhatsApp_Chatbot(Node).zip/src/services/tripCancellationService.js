const User = require('../models/user');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

class TripCancellationService {
  /**
   * Handle initial cancellation request
   * @param {string} userId - The user's ID
   */
  async handleCancellationRequest(userId) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      const message = 'Please specify if you want to cancel:\n' +
        '1. Full journey\n' +
        '2. Single leg\n\n' +
        'Reply with "FULL" or "SINGLE" to proceed.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Cancellation type request sent' };
    } catch (error) {
      logger.error('Error handling cancellation request:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Process cancellation type selection
   * @param {string} userId - The user's ID
   * @param {string} cancellationType - The type of cancellation (FULL/SINGLE)
   */
  async processCancellationType(userId, cancellationType) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      if (!['FULL', 'SINGLE'].includes(cancellationType)) {
        throw new Error('Invalid cancellation type');
      }

      const message = 'To proceed with cancellation, please provide:\n' +
        '1. Booking reference number\n' +
        '2. Date of birth (DD/MM/YYYY)\n\n' +
        'Send in format: BOOKING:123456 DOB:01/01/1990';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { 
        success: true, 
        message: 'Verification request sent',
        cancellationType
      };
    } catch (error) {
      logger.error('Error processing cancellation type:', {
        userId,
        cancellationType,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Verify booking details and process cancellation
   * @param {string} userId - The user's ID
   * @param {string} bookingRef - The booking reference number
   * @param {string} dob - The date of birth
   * @param {string} cancellationType - The type of cancellation
   */
  async verifyAndProcessCancellation(userId, bookingRef, dob, cancellationType) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Verify booking details
      const isValid = await this.verifyBookingDetails(bookingRef, dob, user);
      if (!isValid) {
        const message = 'Invalid booking details. Please check and try again.';
        await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
        return { success: false, message: 'Invalid booking details' };
      }

      // Check if user is mid-trip
      const isMidTrip = await this.checkMidTripStatus(user);
      
      // Process cancellation
      const cancellationResult = await this.processCancellation(
        user,
        bookingRef,
        cancellationType,
        isMidTrip
      );

      // Send confirmation
      const message = this.generateConfirmationMessage(cancellationResult, isMidTrip);
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);

      // Send survey if cancellation successful
      if (cancellationResult.success) {
        await this.sendCancellationSurvey(user);
      }

      return cancellationResult;
    } catch (error) {
      logger.error('Error verifying and processing cancellation:', {
        userId,
        bookingRef,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Verify booking details
   * @private
   */
  async verifyBookingDetails(bookingRef, dob, user) {
    try {
      // Implement your booking verification logic here
      // This is a placeholder implementation
      const booking = await this.findBooking(bookingRef);
      if (!booking) return false;

      const bookingDob = new Date(booking.passengerDob);
      const providedDob = new Date(dob);
      
      return bookingDob.getTime() === providedDob.getTime();
    } catch (error) {
      logger.error('Error verifying booking details:', {
        bookingRef,
        error: error.message
      });
      return false;
    }
  }

  /**
   * Check if user is mid-trip
   * @private
   */
  async checkMidTripStatus(user) {
    try {
      // Implement your mid-trip check logic here
      // This is a placeholder implementation
      return user.workQueueStatus === 'IN_PROGRESS';
    } catch (error) {
      logger.error('Error checking mid-trip status:', {
        userId: user.userId,
        error: error.message
      });
      return false;
    }
  }

  /**
   * Process the cancellation
   * @private
   */
  async processCancellation(user, bookingRef, cancellationType, isMidTrip) {
    try {
      // If mid-trip, notify agent
      if (isMidTrip) {
        await this.notifyAgent(user, bookingRef, cancellationType);
      }

      // Remove from work queue
      await User.findOneAndUpdate(
        { userId: user.userId },
        { 
          $set: { 
            workQueueStatus: 'CANCELLED',
            status: 'INACTIVE'
          }
        }
      );

      // Process cancellation in booking system
      const cancellationId = await this.cancelBooking(bookingRef, cancellationType);

      return {
        success: true,
        message: 'Cancellation processed successfully',
        cancellationId,
        isMidTrip
      };
    } catch (error) {
      logger.error('Error processing cancellation:', {
        userId: user.userId,
        bookingRef,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Notify agent about mid-trip cancellation
   * @private
   */
  async notifyAgent(user, bookingRef, cancellationType) {
    try {
      const message = `URGENT: Trip Cancellation\n` +
        `User: ${user.userId}\n` +
        `Booking: ${bookingRef}\n` +
        `Type: ${cancellationType}\n` +
        `Status: Mid-trip cancellation`;
      
      // Implement your agent notification logic here
      // This could be email, SMS, or internal system notification
      logger.info('Agent notification sent:', { message });
    } catch (error) {
      logger.error('Error notifying agent:', {
        userId: user.userId,
        error: error.message
      });
    }
  }

  /**
   * Send cancellation survey
   * @private
   */
  async sendCancellationSurvey(user) {
    try {
      const message = 'We\'re sorry to see you go. ' +
        'Please take a moment to tell us why you cancelled:\n\n' +
        '1. Change of plans\n' +
        '2. Found better price\n' +
        '3. Service issues\n' +
        '4. Other\n\n' +
        'Reply with the number of your reason.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
    } catch (error) {
      logger.error('Error sending cancellation survey:', {
        userId: user.userId,
        error: error.message
      });
    }
  }

  /**
   * Generate confirmation message
   * @private
   */
  generateConfirmationMessage(cancellationResult, isMidTrip) {
    let message = 'Your cancellation has been processed successfully.\n\n';
    
    if (isMidTrip) {
      message += 'Since you were mid-trip, an agent has been notified.\n';
    }
    
    message += `Cancellation ID: ${cancellationResult.cancellationId}\n` +
      'A confirmation email has been sent to your registered email address.\n\n' +
      'Thank you for using our service.';
    
    return message;
  }

  /**
   * Find booking details
   * @private
   */
  async findBooking(bookingRef) {
    // Implement your booking lookup logic here
    // This is a placeholder
    return null;
  }

  /**
   * Cancel booking in system
   * @private
   */
  async cancelBooking(bookingRef, cancellationType) {
    // Implement your booking cancellation logic here
    // This is a placeholder
    return uuidv4();
  }
}

module.exports = new TripCancellationService(); 
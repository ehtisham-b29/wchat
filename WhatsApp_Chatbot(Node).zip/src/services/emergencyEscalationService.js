const EmergencyEscalation = require('../models/emergencyEscalation');
const User = require('../models/user');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');
const axios = require('axios');
const assistanceService = require('./assistanceService');
const tripCancellationService = require('./tripCancellationService');
const endOfDayService = require('./endOfDayService');
const endOfDayScheduler = require('./schedulers/endOfDayScheduler');
const ArchiveCollection = require('../models/archiveCollection');
const workQueueService = require('./workQueueService');
const WorkQueue = require('../models/workQueue');
const mongoose = require('mongoose');
const crypto = require('crypto');
const emergencyHandler = require('../handlers/emergencyHandler');

const status = {
  PENDING: 'PENDING',
  PROCESSING: 'PROCESSING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  ESCALATED: 'ESCALATED'
};

class EmergencyEscalationService {
  constructor() {
    this.AGENT_VERIFICATION_CODE = '1202';
    this.MAX_VERIFICATION_ATTEMPTS = 3;
  }

  /**
   * Create a new emergency escalation
   * @param {string} userId - The user's ID
   * @param {Object} location - The user's last known location
   */
  async createEscalation(userId, location) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Check for existing active escalation
      const existingEscalation = await EmergencyEscalation.findOne({
        userId,
        status: { $in: ['PENDING', 'AGENT_ASSIGNED', 'LOCATED'] }
      });

      if (existingEscalation) {
        throw new Error('Active escalation already exists for this user');
      }

      // Create new escalation
      const escalation = new EmergencyEscalation({
        userId,
        workQueueStatus: 'SEND_HELP',
        location: {
          lastKnown: location
        },
        timeline: [{
          action: 'ESCALATED',
          details: 'Emergency escalation initiated'
        }],
        escalationPath: [{
          from: String,
          to: String,
          reason: String,
          timestamp: Date
        }]
      });

      await escalation.save();

      // Update user status
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            workQueueStatus: 'SEND_HELP',
            status: 'FLAGGED'
          }
        }
      );

      logger.info(`Created emergency escalation for user ${userId}`, {
        escalationId: escalation.escalationId
      });

      return escalation;
    } catch (error) {
      logger.error('Error creating emergency escalation:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Assign an agent to the escalation
   * @param {string} escalationId - The escalation ID
   * @param {string} agentId - The agent's ID
   * @param {string} agentPin - The agent's PIN
   */
  async assignAgent(escalationId, agentId, agentPin) {
    try {
      const escalation = await EmergencyEscalation.findOne({
        escalationId,
        status: 'PENDING'
      });

      if (!escalation) {
        throw new Error('Escalation not found or not in pending status');
      }

      escalation.agentId = agentId;
      escalation.agentPin = agentPin;
      escalation.status = 'AGENT_ASSIGNED';
      escalation.workQueueStatus = 'IN_PROGRESS';
      escalation.timeline.push({
        action: 'AGENT_ASSIGNED',
        details: `Agent ${agentId} assigned to escalation`
      });

      await escalation.save();

      // Notify user about agent assignment
      const user = await User.findOne({ userId: escalation.userId });
      if (user) {
        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          "A safety agent has been assigned to assist you. They will contact you shortly."
        );
      }

      logger.info(`Assigned agent ${agentId} to escalation ${escalationId}`);
      return escalation;
    } catch (error) {
      logger.error('Error assigning agent:', {
        escalationId,
        agentId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Update user location when found by agent
   * @param {string} escalationId - The escalation ID
   * @param {Object} location - The location where the user was found
   */
  async updateUserLocation(escalationId, location) {
    try {
      const escalation = await EmergencyEscalation.findOne({
        escalationId,
        status: 'AGENT_ASSIGNED'
      });

      if (!escalation) {
        throw new Error('Escalation not found or agent not assigned');
      }

      escalation.status = 'LOCATED';
      escalation.location.foundAt = location;
      escalation.timeline.push({
        action: 'LOCATED',
        details: 'User located by agent'
      });

      await escalation.save();

      logger.info(`Updated user location for escalation ${escalationId}`);
      return escalation;
    } catch (error) {
      logger.error('Error updating user location:', {
        escalationId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Verify user safety with agent and user codes
   * @param {string} escalationId - The escalation ID
   * @param {string} userCode - The user's verification code
   * @param {string} agentCode - The agent's verification code
   */
  async verifySafety(escalationId, userCode, agentCode) {
    try {
      const escalation = await EmergencyEscalation.findOne({
        escalationId,
        status: 'LOCATED'
      });

      if (!escalation) {
        throw new Error('Escalation not found or user not located');
      }

      // Verify codes (implement your validation logic)
      const isValid = await this.validateCodes(userCode, agentCode, escalation.agentPin);

      if (!isValid) {
        throw new Error('Invalid verification codes');
      }

      escalation.status = 'VERIFIED';
      escalation.verification = {
        userCode,
        agentCode,
        verifiedAt: new Date(),
        status: 'VERIFIED'
      };
      escalation.timeline.push({
        action: 'VERIFIED',
        details: 'User safety verified'
      });

      await escalation.save();

      // Update user status and trigger new check-in
      const user = await User.findOne({ userId: escalation.userId });
      if (user) {
        await User.findOneAndUpdate(
          { userId: user.userId },
          {
            $set: {
              workQueueStatus: 'RESOLVED',
              status: 'ACTIVE'
            }
          }
        );

        // Send new check-in request
        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          "Verification successful. Please complete a new tap-in to confirm you're safe."
        );
      }

      logger.info(`Verified user safety for escalation ${escalationId}`);
      return escalation;
    } catch (error) {
      logger.error('Error verifying user safety:', {
        escalationId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Resolve the escalation
   * @param {string} escalationId - The escalation ID
   */
  async resolveEscalation(escalationId) {
    try {
      const escalation = await EmergencyEscalation.findOne({
        escalationId,
        status: 'VERIFIED'
      });

      if (!escalation) {
        throw new Error('Escalation not found or not verified');
      }

      escalation.status = 'RESOLVED';
      escalation.workQueueStatus = 'RESOLVED';
      escalation.resolvedAt = new Date();
      escalation.timeline.push({
        action: 'RESOLVED',
        details: 'Escalation resolved successfully'
      });

      await escalation.save();

      logger.info(`Resolved escalation ${escalationId}`);
      return escalation;
    } catch (error) {
      logger.error('Error resolving escalation:', {
        escalationId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Validate verification codes
   * @private
   */
  async validateCodes(userCode, agentCode, agentPin) {
    // Verify agent code matches the fixed code
    if (agentCode !== this.AGENT_VERIFICATION_CODE) {
      return false;
    }

    // Verify user code
    try {
      const user = await User.findOne({ verificationCode: userCode });
      return !!user;
    } catch (error) {
      logger.error('Error validating codes:', error);
      return false;
    }
  }

  async processEscalations() {
    // Implementation of processEscalations method
  }

  async storeArchiveRecord(archiveRecord) {
    // Implement your storage logic
    // Example: MongoDB archive collection
    await ArchiveCollection.create(archiveRecord);
  }

  async addToQueues(userId, message, reason, escalationReason, priority) {
    try {
      // Add items to queues
      await workQueueService.addToMessageQueue(userId, message, priority);
      await workQueueService.addToCallQueue(userId, reason, priority);
      await workQueueService.addToAgentQueue(userId, escalationReason, priority);

      // Clear queues
      await workQueueService.clearUserQueues(userId);

      logger.info(`Added items to queues and cleared queues for user ${userId}`);
    } catch (error) {
      logger.error('Error adding items to queues:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Cancel emergency escalation using day code
   * @param {string} userId - The user's ID
   * @param {string} dayCode - The day code entered by the user
   */
  async cancelEscalationWithDayCode(userId, dayCode) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Find active escalation
      const escalation = await EmergencyEscalation.findOne({
        userId,
        status: { $in: ['PENDING', 'AGENT_ASSIGNED', 'LOCATED'] }
      });

      if (!escalation) {
        throw new Error('No active escalation found for this user');
      }

      // Verify day code
      const isValidDayCode = await this.verifyDayCode(user, dayCode);
      if (!isValidDayCode) {
        throw new Error('Invalid day code');
      }

      // Cancel escalation
      escalation.status = 'CANCELLED';
      escalation.workQueueStatus = 'CANCELLED';
      escalation.timeline.push({
        action: 'CANCELLED',
        details: 'Emergency escalation cancelled by user with day code verification'
      });

      await escalation.save();

      // Clear all pending queues
      await workQueueService.clearUserQueues(userId);

      // Update user status
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            workQueueStatus: 'NORMAL',
            status: 'ACTIVE'
          }
        }
      );

      // Send confirmation message
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "Emergency escalation has been cancelled. You're all set!"
      );

      logger.info(`Cancelled emergency escalation for user ${userId} using day code`);
      return escalation;
    } catch (error) {
      logger.error('Error cancelling emergency escalation:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Verify day code
   * @private
   */
  async verifyDayCode(user, dayCode) {
    try {
      // Get today's date in YYYYMMDD format
      const today = new Date();
      const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');

      // Generate day code (you can implement your own logic here)
      const expectedDayCode = this.generateDayCode(user.userId, dateStr);

      // Compare codes
      return dayCode === expectedDayCode;
    } catch (error) {
      logger.error('Error verifying day code:', {
        userId: user.userId,
        error: error.message
      });
      return false;
    }
  }

  /**
   * Generate day code
   * @private
   */
  generateDayCode(userId, dateStr) {
    // Add your own logic here
    // Example: Use a more secure hashing method
    return crypto
      .createHash('sha256')
      .update(userId + dateStr + process.env.SECRET_KEY)
      .digest('hex')
      .slice(0, 6);
  }

  /**
   * Generate a verification code for user
   * @param {string} userId - The user's ID
   */
  async generateVerificationCode(userId) {
    try {
      const code = crypto.randomInt(1000, 9999).toString();
      const user = await User.findOne({ userId });

      if (!user) {
        throw new Error('User not found');
      }

      // Store verification code with expiration
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            verificationCode: code,
            verificationCodeExpires: new Date(Date.now() + 15 * 60 * 1000) // 15 minutes
          }
        }
      );

      // Send code via WhatsApp
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        `Your verification code is: ${code}. This code will expire in 15 minutes.`
      );

      return code;
    } catch (error) {
      logger.error('Error generating verification code:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Verify user with code
   * @param {string} userId - The user's ID
   * @param {string} code - The verification code
   */
  async verifyUserCode(userId, code) {
    try {
      const user = await User.findOne({ userId });

      if (!user) {
        throw new Error('User not found');
      }

      if (!user.verificationCode || !user.verificationCodeExpires) {
        throw new Error('No verification code found');
      }

      if (new Date() > user.verificationCodeExpires) {
        throw new Error('Verification code expired');
      }

      if (user.verificationCode !== code) {
        throw new Error('Invalid verification code');
      }

      // Clear verification code
      await User.findOneAndUpdate(
        { userId },
        {
          $unset: {
            verificationCode: 1,
            verificationCodeExpires: 1
          }
        }
      );

      return true;
    } catch (error) {
      logger.error('Error verifying user code:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle no response from user
   * @param {string} userId - The user's ID
   */
  async handleNoResponse(userId) {
    try {
      const user = await User.findOne({ userId });

      if (!user) {
        throw new Error('User not found');
      }

      // Generate and send verification code
      await this.generateVerificationCode(userId);

      // Add to call queue for voice verification
      await workQueueService.addToCallQueue(userId, 'NO_RESPONSE', 'high');

      // Update user status
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            workQueueStatus: 'VERIFICATION_NEEDED',
            status: 'FLAGGED'
          }
        }
      );

      logger.info(`Handled no response for user ${userId}`);
    } catch (error) {
      logger.error('Error handling no response:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Verify safety with agent and user codes
   * @param {string} userId - The user's ID
   * @param {string} agentId - The agent's ID
   * @param {string} userCode - The user's verification code
   * @param {string} agentCode - The agent's verification code
   */
  async verifySafetyWithAgent(userId, agentId, userCode, agentCode) {
    try {
      const user = await User.findOne({ userId });
      const agent = await User.findOne({ userId: agentId, role: 'AGENT' });

      if (!user || !agent) {
        throw new Error('User or agent not found');
      }

      // Verify agent code
      if (agentCode !== this.AGENT_VERIFICATION_CODE) {
        throw new Error('Invalid agent verification code');
      }

      // Verify user code
      const isUserCodeValid = await this.verifyUserCode(userId, userCode);
      if (!isUserCodeValid) {
        throw new Error('Invalid user verification code');
      }

      // Update user status
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            workQueueStatus: 'NORMAL',
            status: 'ACTIVE',
            lastVerifiedBy: agentId,
            lastVerifiedAt: new Date()
          }
        }
      );

      // Send confirmation to user
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "Your safety has been verified. Please complete a new tap-in to confirm you're safe."
      );

      logger.info(`Verified safety for user ${userId} with agent ${agentId}`);
      return true;
    } catch (error) {
      logger.error('Error verifying safety with agent:', {
        userId,
        agentId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Reconfirm tap-in after verification
   * @param {string} userId - The user's ID
   */
  async reconfirmTapIn(userId) {
    try {
      const user = await User.findOne({ userId });

      if (!user) {
        throw new Error('User not found');
      }

      // Send tap-in request
      await twilioService.sendWhatsAppMessage(
        user.phoneNumber,
        "Please tap in to confirm you're safe. Reply with 'TAP IN' to confirm."
      );

      // Add to message queue for response
      await workQueueService.addToMessageQueue(userId, 'TAP_IN_CONFIRMATION', 'high');

      logger.info(`Requested tap-in reconfirmation for user ${userId}`);
    } catch (error) {
      logger.error('Error reconfirming tap-in:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }
}

// Initialize the service
async function initializeService() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    // Find all pending jobs
    const pendingJobs = await WorkQueue.find({
      status: 'PENDING'
    }).sort({ priority: 1, createdAt: 1 });

    // Start processing queues
    if (pendingJobs.length > 0) {
      logger.info(`Found ${pendingJobs.length} pending jobs to process`);
      // Process pending jobs
      for (const job of pendingJobs) {
        await processNextJob();
      }
    }

    // Start the scheduler
    endOfDayScheduler.start();

    logger.info('Emergency escalation service initialized successfully');
  } catch (error) {
    logger.error('Error initializing emergency escalation service:', error);
    throw error;
  }
}

// Initialize the service
initializeService().catch(error => {
  logger.error('Failed to initialize emergency escalation service:', error);
  process.exit(1);
});

module.exports = new EmergencyEscalationService();

// Helper functions
async function handleUserResponse(userId) {
  await workQueueService.clearUserQueues(userId);
}

async function processNextJob() {
  const job = await WorkQueue.findNextJob('MESSAGE', 'high');
  if (job) {
    await processMessage(job);
  }
}

async function updateJobStatus(job, status) {
  job.status = status;
  await job.save();
}

async function completeJob(job) {
  await job.complete();
}

async function failJob(job, error) {
  await job.fail(error);
}

async function escalateJob(job, escalationReason) {
  await job.escalate('CALL', escalationReason);
}

async function clearUserJobs(userId) {
  await WorkQueue.clearUserJobs(userId);
}

// Example usage functions (these should be called from appropriate handlers)
async function handleMessageProcessing(userId, message, attempts) {
  if (message.toLowerCase().includes('cancel') || message.toLowerCase().includes('stop')) {
    const result = await emergencyHandler.handleEmergencyCancellation(userId, message);
    return result;
  }

  if (attempts >= this.MAX_VERIFICATION_ATTEMPTS) {
    await emergencyEscalationService.createEscalation(userId);
  }

  if (/^\d{4}$/.test(message)) {
    const result = await emergencyHandler.handleVerificationCode(userId, message);
    return result;
  }

  if (message.toUpperCase() === 'TAP IN') {
    const result = await emergencyHandler.handleTapInConfirmation(userId, message);
    return result;
  }
}

async function handleAgentVerification(userId, agentId, userCode, agentCode) {
  return await emergencyEscalationService.verifySafetyWithAgent(userId, agentId, userCode, agentCode);
} 
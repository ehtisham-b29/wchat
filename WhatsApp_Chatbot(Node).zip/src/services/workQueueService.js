const User = require('../models/user');
const EmergencyEscalation = require('../models/emergencyEscalation');
const WorkQueue = require('../models/workQueue');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

class WorkQueueService {
  constructor() {
    // Set up queue processors
    this.setupQueueProcessors();
  }

  /**
   * Set up queue processors
   * @private
   */
  setupQueueProcessors() {
    // Start processing queues
    this.startMessageQueueProcessor();
    this.startCallQueueProcessor();
    this.startAgentQueueProcessor();
  }

  /**
   * Start message queue processor
   * @private
   */
  async startMessageQueueProcessor() {
    setInterval(async () => {
      try {
        const job = await WorkQueue.findNextJob('MESSAGE', 'high');
        if (job) {
          await this.processMessage(job);
        }
      } catch (error) {
        logger.error('Error in message queue processor:', {
          error: error.message,
          stack: error.stack
        });
      }
    }, 1000); // Check every second
  }

  /**
   * Start call queue processor
   * @private
   */
  async startCallQueueProcessor() {
    setInterval(async () => {
      try {
        const job = await WorkQueue.findNextJob('CALL', 'high');
        if (job) {
          await this.processCall(job);
        }
      } catch (error) {
        logger.error('Error in call queue processor:', {
          error: error.message,
          stack: error.stack
        });
      }
    }, 2000); // Check every 2 seconds
  }

  /**
   * Start agent queue processor
   * @private
   */
  async startAgentQueueProcessor() {
    setInterval(async () => {
      try {
        const job = await WorkQueue.findNextJob('AGENT', 'high');
        if (job) {
          await this.processAgentEscalation(job);
        }
      } catch (error) {
        logger.error('Error in agent queue processor:', {
          error: error.message,
          stack: error.stack
        });
      }
    }, 5000); // Check every 5 seconds
  }

  /**
   * Add message to queue
   * @param {string} userId - User ID
   * @param {string} message - Message content
   * @param {string} priority - Message priority
   */
  async addToMessageQueue(userId, message, priority = 'normal') {
    try {
      const job = await WorkQueue.create({
        queueId: uuidv4(),
        userId,
        type: 'MESSAGE',
        priority,
        data: { message },
        status: 'PENDING',
        nextAttempt: new Date()
      });

      logger.info('Added message to queue:', {
        userId,
        queueId: job.queueId,
        priority
      });

      return job;
    } catch (error) {
      logger.error('Error adding to message queue:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Add call to queue
   * @param {string} userId - User ID
   * @param {string} reason - Call reason
   * @param {string} priority - Call priority
   */
  async addToCallQueue(userId, reason, priority = 'normal') {
    try {
      const job = await WorkQueue.create({
        queueId: uuidv4(),
        userId,
        type: 'CALL',
        priority,
        data: { reason },
        status: 'PENDING',
        nextAttempt: new Date()
      });

      logger.info('Added call to queue:', {
        userId,
        queueId: job.queueId,
        priority
      });

      return job;
    } catch (error) {
      logger.error('Error adding to call queue:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Add agent escalation to queue
   * @param {string} userId - User ID
   * @param {string} escalationReason - Reason for escalation
   * @param {string} priority - Escalation priority
   */
  async addToAgentQueue(userId, escalationReason, priority = 'high') {
    try {
      const job = await WorkQueue.create({
        queueId: uuidv4(),
        userId,
        type: 'AGENT',
        priority,
        data: { escalationReason },
        status: 'PENDING',
        nextAttempt: new Date()
      });

      logger.info('Added agent escalation to queue:', {
        userId,
        queueId: job.queueId,
        priority
      });

      return job;
    } catch (error) {
      logger.error('Error adding to agent queue:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Process message from queue
   * @private
   */
  async processMessage(job) {
    try {
      const user = await User.findOne({ userId: job.userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Update job status
      job.status = 'PROCESSING';
      await job.save();

      // Send message via WhatsApp
      await twilioService.sendWhatsAppMessage(user.phoneNumber, job.data.message);

      // Check if escalation is needed
      if (this.shouldEscalateToCall(user, job.priority)) {
        await this.addToCallQueue(job.userId, 'No response to message', 'high');
        await job.escalate('CALL', 'No response to message');
      } else {
        await job.complete();
      }

      logger.info('Processed message from queue:', {
        userId: job.userId,
        queueId: job.queueId,
        priority: job.priority
      });
    } catch (error) {
      logger.error('Error processing message:', {
        userId: job.userId,
        queueId: job.queueId,
        error: error.message
      });
      await job.fail(error);
      throw error;
    }
  }

  /**
   * Process call from queue
   * @private
   */
  async processCall(job) {
    try {
      const user = await User.findOne({ userId: job.userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Update job status
      job.status = 'PROCESSING';
      await job.save();

      // Make call via Twilio
      const callResult = await twilioService.makeCall(user.phoneNumber, job.data.reason);

      // Check if escalation is needed
      if (this.shouldEscalateToAgent(user, job.priority, callResult)) {
        await this.addToAgentQueue(job.userId, 'No response to call', 'high');
        await job.escalate('AGENT', 'No response to call');
      } else {
        await job.complete();
      }

      logger.info('Processed call from queue:', {
        userId: job.userId,
        queueId: job.queueId,
        priority: job.priority,
        callResult
      });
    } catch (error) {
      logger.error('Error processing call:', {
        userId: job.userId,
        queueId: job.queueId,
        error: error.message
      });
      await job.fail(error);
      throw error;
    }
  }

  /**
   * Process agent escalation from queue
   * @private
   */
  async processAgentEscalation(job) {
    try {
      const user = await User.findOne({ userId: job.userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Update job status
      job.status = 'PROCESSING';
      await job.save();

      // Create emergency escalation
      const escalation = await EmergencyEscalation.create({
        userId: job.userId,
        reason: job.data.escalationReason,
        priority: job.priority,
        status: 'PENDING'
      });

      // Notify available agents
      await this.notifyAvailableAgents(escalation);

      await job.complete();

      logger.info('Processed agent escalation:', {
        userId: job.userId,
        queueId: job.queueId,
        escalationId: escalation.escalationId,
        priority: job.priority
      });
    } catch (error) {
      logger.error('Error processing agent escalation:', {
        userId: job.userId,
        queueId: job.queueId,
        error: error.message
      });
      await job.fail(error);
      throw error;
    }
  }

  /**
   * Clear user's queues
   * @param {string} userId - User ID
   */
  async clearUserQueues(userId) {
    try {
      await WorkQueue.clearUserJobs(userId);
      logger.info('Cleared user queues:', { userId });
    } catch (error) {
      logger.error('Error clearing user queues:', {
        userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Check if message should escalate to call
   * @private
   */
  shouldEscalateToCall(user, priority) {
    return priority === 'high' || 
           (user.lastMessageSent && 
            Date.now() - user.lastMessageSent > 5 * 60 * 1000); // 5 minutes
  }

  /**
   * Check if call should escalate to agent
   * @private
   */
  shouldEscalateToAgent(user, priority, callResult) {
    return priority === 'high' || 
           callResult.status === 'failed' ||
           (user.lastCallAttempt && 
            Date.now() - user.lastCallAttempt > 10 * 60 * 1000); // 10 minutes
  }

  /**
   * Notify available agents
   * @private
   */
  async notifyAvailableAgents(escalation) {
    // Implement your agent notification logic here
    logger.info('Notifying available agents:', {
      escalationId: escalation.escalationId
    });
  }
}

module.exports = new WorkQueueService(); 
const twilio = require('twilio');
const logger = require('../../utils/logger');

// Initialize Twilio client
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

/**
 * Send a WhatsApp message
 * @param {string} to - Recipient phone number (with country code)
 * @param {string} message - Message content
 * @returns {Promise<Object>} - Message information object
 */
const sendWhatsAppMessage = async (to, message) => {
  try {
    const response = await client.messages.create({
      from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
      to: `whatsapp:${to}`,
      body: message,
    });

    logger.info(`WhatsApp message sent to ${to}`, { messageId: response.sid });
    return response;
  } catch (error) {
    logger.error(`Failed to send WhatsApp message: ${error.message}`, {
      to,
      errorCode: error.code,
    });
    throw new Error(`WhatsApp message failed: ${error.message}`);
  }
};

/**
 * Send an SMS message
 * @param {string} to - Recipient phone number (with country code)
 * @param {string} message - Message content
 * @returns {Promise<Object>} - Message information object
 */
const sendSMS = async (to, message) => {
  try {
    const response = await client.messages.create({
      from: process.env.TWILIO_PHONE_NUMBER,
      to,
      body: message,
    });

    logger.info(`SMS sent to ${to}`, { messageId: response.sid });
    return response;
  } catch (error) {
    logger.error(`Failed to send SMS: ${error.message}`, {
      to,
      errorCode: error.code,
    });
    throw new Error(`SMS failed: ${error.message}`);
  }
};

/**
 * Initiate a voice call with TwiML instructions
 * @param {string} to - Recipient phone number (with country code)
 * @param {string} twimlUrl - URL to TwiML instructions for the call
 * @returns {Promise<Object>} - Call information object
 */
const initiateVoiceCall = async (to, twimlUrl) => {
  try {
    const call = await client.calls.create({
      to,
      from: process.env.TWILIO_PHONE_NUMBER,
      url: twimlUrl,
    });

    logger.info(`Voice call initiated to ${to}`, { callId: call.sid });
    return call;
  } catch (error) {
    logger.error(`Failed to initiate voice call: ${error.message}`, {
      to,
      errorCode: error.code,
    });
    throw new Error(`Voice call failed: ${error.message}`);
  }
};

/**
 * Initiate a voice call with TwiML instructions
 * @param {string} to - Recipient phone number (with country code)
 * @param {string} twimlUrl - URL to TwiML instructions for the call
 * @returns {Promise<Object>} - Call information object
 */

const makeCall = async (to, verificationCode) => {
  console.log("🤙🤙🤙🤙🤙🤙🤙🤙🤙", to, process.env.TWILIO_CALL_NUMBER);  
  const call = await client.calls.create({
    from: process.env.TWILIO_CALL_NUMBER,
    to : to,
    url: 'https://handler.twilio.com/twiml/EH7a812900b42fb49851bc1262be6d2542?verificationCode=' + verificationCode,
  });

  console.log(call.sid);
};

/**
 * Generate TwiML for a verification code call
 * @param {string} verificationCode - The code to be read to the user
 * @returns {string} - TwiML XML string
 */
const generateVerificationTwiML = (verificationCode) => {
  const spacedCode = verificationCode.split('').join(' ');
  
  return `
    <?xml version="1.0" encoding="UTF-8"?>
    <Response>
      <Say>Hello. This is your verification call from your travel assistant.</Say>
      <Pause length="1"/>
      <Say>Your verification code is: ${spacedCode}</Say>
      <Pause length="1"/>
      <Say>I repeat, your verification code is: ${spacedCode}</Say>
      <Pause length="1"/>
      <Say>Please enter this code in your chat. Thank you.</Say>
    </Response>
  `;
};

/**
 * Extract the country and city code from a phone number
 * @param {string} phoneNumber - Full phone number with country code
 * @returns {Object} - Object containing country and city code
 */
const extractLocationFromPhone = (phoneNumber) => {
  // Remove any non-digit characters
  const cleanNumber = phoneNumber.replace(/\D/g, '');
  
  // Handle special cases for common country codes
  let countryCode;
  let cityCode;
  
  // Check for common country code patterns
  if (cleanNumber.startsWith('1')) {
    // North America (US/Canada)
    countryCode = '1';
    cityCode = cleanNumber.substring(1, 4);
  } else if (cleanNumber.startsWith('44')) {
    // UK
    countryCode = '44';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('91')) {
    // India
    countryCode = '91';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('86')) {
    // China
    countryCode = '86';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('81')) {
    // Japan
    countryCode = '81';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('49')) {
    // Germany
    countryCode = '49';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('33')) {
    // France
    countryCode = '33';
    cityCode = cleanNumber.substring(2, 5);
  } else if (cleanNumber.startsWith('61')) {
    // Australia
    countryCode = '61';
    cityCode = cleanNumber.substring(2, 5);
  } else {
    // Default case - try to extract first 2-3 digits as country code
    countryCode = cleanNumber.substring(0, 2);
    cityCode = cleanNumber.substring(2, 5);
  }
  
  logger.info(`Extracted location from phone number: ${phoneNumber}`, {
    countryCode,
    cityCode
  });
  
  return {
    countryCode,
    cityCode
  };
};

/**
 * Validate a WhatsApp webhook request using Twilio's validation
 * @param {string} signature - X-Twilio-Signature header
 * @param {string} url - Full URL of the webhook
 * @param {object} params - Request body/params
 * @returns {boolean} - Whether the request is valid
 */
const validateWebhook = (signature, url, params) => {
  return twilio.validateRequest(
    process.env.TWILIO_AUTH_TOKEN,
    signature,
    url,
    params
  );
};

module.exports = {
  client,
  sendWhatsAppMessage,
  sendSMS,
  initiateVoiceCall,
  generateVerificationTwiML,
  extractLocationFromPhone,
  validateWebhook,
  makeCall
}; 
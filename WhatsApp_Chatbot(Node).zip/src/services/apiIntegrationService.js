const Amadeus = require('amadeus');
const { Client } = require('@googlemaps/google-maps-services-js');
const axios = require('axios');
const logger = require('../utils/logger');

// Initialize API clients
const amadeus = new Amadeus({
  clientId: process.env.AMADEUS_CLIENT_ID,
  clientSecret: process.env.AMADEUS_CLIENT_SECRET
});

const googleMapsClient = new Client({});

/**
 * Get flight status from Amadeus API
 * @param {string} flightNumber - Flight number (e.g., "BA123")
 * @param {string} date - Departure date in YYYY-MM-DD format
 * @returns {Promise<Object>} - Flight status information
 */
const getFlightStatus = async (flightNumber, date) => {
  try {
    const carrierCode = flightNumber.substring(0, 2);
    const flightNumberOnly = flightNumber.substring(2);
    
    console.log("++++++", carrierCode, flightNumber)

    const response = await amadeus.schedule.flights.get({
      carrierCode,
      flightNumber: flightNumberOnly,
      scheduledDepartureDate: date
    });
    console.log("💨💨💨", response)

    return {
      success: true,
      data: response.data,
      formatted: formatFlightStatus(response.data)
    };
  } catch (error) {
    logger.error('Flight status lookup failed:', error.message);
    return {
      success: false,
      error: 'Unable to fetch flight status'
    };
  }
};

/**
 * Get weather information for a location
 * @param {string} location - City name or coordinates
 * @returns {Promise<Object>} - Weather information
 */
const getWeatherInfo = async (location) => {
  try {
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather`, {
      params: {
        q: location,
        appid: process.env.OPENWEATHER_API_KEY,
        units: 'metric'
      }
    });

    return {
      success: true,
      data: response.data,
      formatted: formatWeatherInfo(response.data)
    };
  } catch (error) {
    logger.error('Weather lookup failed:', error.message);
    return {
      success: false,
      error: 'Unable to fetch weather information'
    };
  }
};

/**
 * Get location information from Google Maps API
 * @param {string} query - Location query
 * @returns {Promise<Object>} - Location information
 */
const getLocationInfo = async (query) => {
  try {
    const response = await googleMapsClient.geocode({
      params: {
        address: query,
        key: process.env.GOOGLE_MAPS_API_KEY
      }
    });

    if (response.data.results.length === 0) {
      return {
        success: false,
        error: 'Location not found'
      };
    }

    const location = response.data.results[0];
    return {
      success: true,
      data: location,
      formatted: formatLocationInfo(location)
    };
  } catch (error) {
    logger.error('Location lookup failed:', error.message);
    return {
      success: false,
      error: 'Unable to fetch location information'
    };
  }
};

/**
 * Get currency exchange rates
 * @param {string} baseCurrency - Base currency code (e.g., "USD")
 * @param {string} targetCurrency - Target currency code (e.g., "EUR")
 * @returns {Promise<Object>} - Exchange rate information
 */
const getExchangeRate = async (baseCurrency, targetCurrency) => {
  try {
    const response = await axios.get(`https://api.exchangerate-api.com/v4/latest/${baseCurrency}`);
    
    if (!response.data.rates[targetCurrency]) {
      return {
        success: false,
        error: 'Invalid currency code'
      };
    }

    return {
      success: true,
      data: {
        base: baseCurrency,
        target: targetCurrency,
        rate: response.data.rates[targetCurrency]
      },
      formatted: formatExchangeRate(baseCurrency, targetCurrency, response.data.rates[targetCurrency])
    };
  } catch (error) {
    logger.error('Exchange rate lookup failed:', error.message);
    return {
      success: false,
      error: 'Unable to fetch exchange rate'
    };
  }
};

// Helper functions to format API responses
const formatFlightStatus = (data) => {
  if (!data || !data.data || data.data.length === 0) {
    return 'No flight information available';
  }

  const flight = data.data[0];
  const segments = flight.flightPoints || [];
  const departure = segments.find(point => point.typeCode === 'DEPARTURE');
  const arrival = segments.find(point => point.typeCode === 'ARRIVAL');

  // Format times
  const departureTime = departure ? new Date(departure.scheduledTime.dateTime).toLocaleString() : 'TBD';
  const arrivalTime = arrival ? new Date(arrival.scheduledTime.dateTime).toLocaleString() : 'TBD';

  // Get flight status
  let status = 'Unknown';
  if (flight.status) {
    switch (flight.status.statusCode) {
      case 'SCHEDULED':
        status = 'Scheduled';
        break;
      case 'ACTIVE':
        status = 'In Flight';
        break;
      case 'LANDED':
        status = 'Landed';
        break;
      case 'CANCELLED':
        status = 'Cancelled';
        break;
      case 'DIVERTED':
        status = 'Diverted';
        break;
      default:
        status = flight.status.statusCode;
    }
  }

  // Check for delays
  const departureDelay = departure?.delayMinutes ? `(Delayed by ${departure.delayMinutes} minutes)` : '';
  const arrivalDelay = arrival?.delayMinutes ? `(Delayed by ${arrival.delayMinutes} minutes)` : '';

  return `
✈️ Flight Status: ${status}
Flight: ${flight.carrierCode}${flight.number}

Departure:
${departure?.iataCode || 'TBD'} at ${departureTime} ${departureDelay}
Terminal: ${departure?.terminal || 'TBD'}

Arrival:
${arrival?.iataCode || 'TBD'} at ${arrivalTime} ${arrivalDelay}
Terminal: ${arrival?.terminal || 'TBD'}
  `.trim();
};

const formatWeatherInfo = (data) => {
  return `
Location: ${data.name}
Temperature: ${data.main.temp}°C
Conditions: ${data.weather[0].description}
Humidity: ${data.main.humidity}%
Wind: ${data.wind.speed} m/s
  `.trim();
};

const formatLocationInfo = (location) => {
  return `
Address: ${location.formatted_address}
Coordinates: ${location.geometry.location.lat}, ${location.geometry.location.lng}
  `.trim();
};

const formatExchangeRate = (base, target, rate) => {
  return `
1 ${base} = ${rate} ${target}
  `.trim();
};

module.exports = {
  getFlightStatus,
  getWeatherInfo,
  getLocationInfo,
  getExchangeRate
}; 
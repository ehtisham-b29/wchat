const twilio = require("twilio");
const logger = require("../utils/logger");
const userModel = require("../models/user");
const openaiService = require("./openaiService");

// Initialize Twilio client
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

/**
 * Process an incoming WhatsApp message
 * @param {Object} message - The message object
 * @param {string} message.text - The message text
 * @param {string} message.from - The sender's phone number
 * @param {string} message.to - The recipient's phone number
 * @returns {Promise<void>}
 */
const processIncomingMessage = async (message) => {
  try {
    logger.info(`Received WhatsApp message from ${message.from}`, {
      messageId: message.messageId || "unknown",
    });

    // Extract phone number from WhatsApp format (whatsapp:+1234567890)
    const phoneNumber = message.from.replace("whatsapp:", "");

    // Get or create user
    let user = await userModel.getUserByPhoneNumber(phoneNumber);

    if (!user) {
      logger.info(`Creating new user for ${phoneNumber}`);
      user = await userModel.createUser({
        phoneNumber,
        name: "New User",
        conversationState: "INITIAL",
        lastInteraction: new Date().toISOString(),
      });
    }

    // Update user's last interaction time
    await userModel.updateUser(phoneNumber, {
      lastInteraction: new Date().toISOString(),
    });

    // Process message based on user's conversation state
    const response = await processMessageBasedOnState(user, message.text);

    // Send response back to user
    await sendWhatsAppMessage(phoneNumber, response);
  } catch (error) {
    logger.error("Error handling WhatsApp message:", error.message, {
      error: error.stack,
    });
    throw new Error(`Error handling WhatsApp message: ${error.message}`);
  }
};

/**
 * Process message based on user's conversation state
 * @param {Object} user - The user object
 * @param {string} messageText - The message text
 * @returns {Promise<string>} - The response message
 */
const processMessageBasedOnState = async (user, messageText) => {
  try {
    const state = user.conversationState || "INITIAL";

    switch (state) {
      case "INITIAL":
        return await handleInitialState(user, messageText);

      case "AWAITING_NAME":
        return await handleNameCollection(user, messageText);

      case "CHAT":
        return await handleChatState(user, messageText);

      default:
        // Default to chat state if unknown
        return await handleChatState(user, messageText);
    }
  } catch (error) {
    logger.error("Error processing message based on state:", error.message);
    return "I'm sorry, I encountered an error processing your message. Please try again later.";
  }
};

/**
 * Handle initial conversation state
 * @param {Object} user - The user object
 * @param {string} messageText - The message text
 * @returns {Promise<string>} - The response message
 */
const handleInitialState = async (user, messageText) => {
  // Update user state to awaiting name
  await userModel.updateUser(user.phoneNumber, {
    conversationState: "AWAITING_NAME",
  });

  return "Welcome to our WhatsApp chatbot! What's your name?";
};

/**
 * Handle name collection state
 * @param {Object} user - The user object
 * @param {string} messageText - The message text
 * @returns {Promise<string>} - The response message
 */
const handleNameCollection = async (user, messageText) => {
  // Update user with provided name and change state to chat
  await userModel.updateUser(user.phoneNumber, {
    name: messageText,
    conversationState: "CHAT",
  });

  return `Nice to meet you, ${messageText}! How can I help you today?`;
};

/**
 * Handle chat state
 * @param {Object} user - The user object
 * @param {string} messageText - The message text
 * @returns {Promise<string>} - The response message
 */
const handleChatState = async (user, messageText) => {
  try {
    // Use OpenAI to generate a response
    const response = await openaiService.generateResponse(messageText, user);
    return response;
  } catch (error) {
    logger.error("Error generating AI response:", error.message);
    return "I'm sorry, I couldn't generate a response right now. Please try again later.";
  }
};

/**
 * Send a WhatsApp message
 * @param {string} to - The recipient's phone number
 * @param {string} body - The message body
 * @returns {Promise<Object>} - The message object
 */
const sendWhatsAppMessage = async (to, body) => {
  try {
    // Format the 'to' number if it doesn't have the WhatsApp prefix
    const formattedTo = to.startsWith("whatsapp:") ? to : `whatsapp:${to}`;

    const message = await twilioClient.messages.create({
      body,
      from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
      to: formattedTo,
    });

    logger.debug("WhatsApp message sent", {
      messageId: message.sid,
      to: formattedTo,
    });

    return message;
  } catch (error) {
    logger.error("Error sending WhatsApp message:", error.message, {
      to,
      errorCode: error.code,
      errorDetails: error.details,
    });
    throw new Error(`Error sending WhatsApp message: ${error.message}`);
  }
};

module.exports = {
  processIncomingMessage,
  sendWhatsAppMessage,
};

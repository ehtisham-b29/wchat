const User = require('../models/user');
const EmergencyEscalation = require('../models/emergencyEscalation');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

class EndOfDayService {
  /**
   * Process end-of-day tasks
   */
  async processEndOfDay() {
    try {
      logger.info('Starting end-of-day processing');
      
      // Process all tasks in parallel
      const [
        tapInReport,
        archivedUsers,
        cancellationReport
      ] = await Promise.all([
        this.generateTapInReport(),
        this.archiveCompletedUsers(),
        this.analyzeCancellations()
      ]);

      // Send reports to relevant stakeholders
      await this.sendReports(tapInReport, archivedUsers, cancellationReport);

      logger.info('End-of-day processing completed successfully');
      return {
        success: true,
        tapInReport,
        archivedUsers,
        cancellationReport
      };
    } catch (error) {
      logger.error('Error in end-of-day processing:', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Generate tap-in report
   * @private
   */
  async generateTapInReport() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Get all successful tap-ins for today
      const successfulTapIns = await User.find({
        lastTapIn: { $gte: today },
        tapInStatus: 'SUCCESSFUL'
      });

      // Group by location
      const locationStats = this.groupByLocation(successfulTapIns);

      // Calculate success rates
      const totalAttempts = await User.countDocuments({
        lastTapIn: { $gte: today }
      });
      const successRate = (successfulTapIns.length / totalAttempts) * 100;

      return {
        date: today,
        totalSuccessful: successfulTapIns.length,
        totalAttempts,
        successRate: successRate.toFixed(2) + '%',
        locationStats,
        timestamp: new Date()
      };
    } catch (error) {
      logger.error('Error generating tap-in report:', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Archive completed users
   * @private
   */
  async archiveCompletedUsers() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Find users to archive
      const usersToArchive = await User.find({
        $or: [
          { workQueueStatus: 'COMPLETED' },
          { workQueueStatus: 'CANCELLED' }
        ],
        lastActivity: { $lt: today }
      });

      const archivedUsers = [];

      // Archive each user
      for (const user of usersToArchive) {
        const archivedUser = await this.archiveUser(user);
        archivedUsers.push(archivedUser);
      }

      return {
        totalArchived: archivedUsers.length,
        users: archivedUsers.map(user => ({
          userId: user.userId,
          status: user.workQueueStatus,
          archivedAt: user.archivedAt
        }))
      };
    } catch (error) {
      logger.error('Error archiving users:', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Analyze cancellations
   * @private
   */
  async analyzeCancellations() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Get all cancellations for today
      const cancellations = await User.find({
        workQueueStatus: 'CANCELLED',
        status: 'INACTIVE',
        lastActivity: { $gte: today }
      });

      // Group by reason
      const reasonStats = this.groupByCancellationReason(cancellations);

      // Identify patterns
      const patterns = this.identifyCancellationPatterns(cancellations);

      return {
        date: today,
        totalCancellations: cancellations.length,
        reasonStats,
        patterns,
        timestamp: new Date()
      };
    } catch (error) {
      logger.error('Error analyzing cancellations:', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Send reports to stakeholders
   * @private
   */
  async sendReports(tapInReport, archivedUsers, cancellationReport) {
    try {
      // Send tap-in report to operations team
      await this.sendTapInReport(tapInReport);

      // Send archiving report to admin team
      await this.sendArchivingReport(archivedUsers);

      // Send cancellation analysis to management
      await this.sendCancellationReport(cancellationReport);

      logger.info('All reports sent successfully');
    } catch (error) {
      logger.error('Error sending reports:', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Archive a single user
   * @private
   */
  async archiveUser(user) {
    try {
      // Create archive record
      const archiveRecord = {
        userId: user.userId,
        originalData: user.toObject(),
        archivedAt: new Date(),
        archiveId: uuidv4()
      };

      // Store in archive collection
      await this.storeArchiveRecord(archiveRecord);

      // Update user status
      await User.findOneAndUpdate(
        { userId: user.userId },
        { 
          $set: { 
            status: 'ARCHIVED',
            archivedAt: new Date()
          }
        }
      );

      return archiveRecord;
    } catch (error) {
      logger.error('Error archiving user:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Group users by location
   * @private
   */
  groupByLocation(users) {
    const stats = {};
    
    users.forEach(user => {
      const location = user.lastKnownLocation || 'UNKNOWN';
      stats[location] = (stats[location] || 0) + 1;
    });

    return stats;
  }

  /**
   * Group cancellations by reason
   * @private
   */
  groupByCancellationReason(cancellations) {
    const stats = {};
    
    cancellations.forEach(user => {
      const reason = user.cancellationReason || 'UNKNOWN';
      stats[reason] = (stats[reason] || 0) + 1;
    });

    return stats;
  }

  /**
   * Identify cancellation patterns
   * @private
   */
  identifyCancellationPatterns(cancellations) {
    const patterns = {
      timeOfDay: {},
      locationBased: {},
      commonReasons: []
    };

    // Analyze time patterns
    cancellations.forEach(user => {
      const hour = new Date(user.lastActivity).getHours();
      patterns.timeOfDay[hour] = (patterns.timeOfDay[hour] || 0) + 1;
    });

    // Analyze location patterns
    cancellations.forEach(user => {
      const location = user.lastKnownLocation || 'UNKNOWN';
      patterns.locationBased[location] = (patterns.locationBased[location] || 0) + 1;
    });

    // Identify common reasons
    const reasonCounts = this.groupByCancellationReason(cancellations);
    patterns.commonReasons = Object.entries(reasonCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([reason]) => reason);

    return patterns;
  }

  /**
   * Send tap-in report
   * @private
   */
  async sendTapInReport(report) {
    try {
      const message = `Daily Tap-In Report (${report.date.toLocaleDateString()})\n\n` +
        `Total Successful: ${report.totalSuccessful}\n` +
        `Total Attempts: ${report.totalAttempts}\n` +
        `Success Rate: ${report.successRate}\n\n` +
        'Location Statistics:\n' +
        Object.entries(report.locationStats)
          .map(([location, count]) => `${location}: ${count}`)
          .join('\n');

      // Send to operations team
      await this.sendToOperationsTeam(message);
    } catch (error) {
      logger.error('Error sending tap-in report:', {
        error: error.message
      });
    }
  }

  /**
   * Send archiving report
   * @private
   */
  async sendArchivingReport(report) {
    try {
      const message = `Daily Archiving Report (${new Date().toLocaleDateString()})\n\n` +
        `Total Users Archived: ${report.totalArchived}\n\n` +
        'Archived Users:\n' +
        report.users
          .map(user => `${user.userId} (${user.status}) - ${user.archivedAt.toLocaleString()}`)
          .join('\n');

      // Send to admin team
      await this.sendToAdminTeam(message);
    } catch (error) {
      logger.error('Error sending archiving report:', {
        error: error.message
      });
    }
  }

  /**
   * Send cancellation report
   * @private
   */
  async sendCancellationReport(report) {
    try {
      const message = `Daily Cancellation Analysis (${report.date.toLocaleDateString()})\n\n` +
        `Total Cancellations: ${report.totalCancellations}\n\n` +
        'Reason Statistics:\n' +
        Object.entries(report.reasonStats)
          .map(([reason, count]) => `${reason}: ${count}`)
          .join('\n') + '\n\n' +
        'Patterns Identified:\n' +
        `- Peak cancellation hours: ${this.formatTimePatterns(report.patterns.timeOfDay)}\n` +
        `- Common locations: ${this.formatLocationPatterns(report.patterns.locationBased)}\n` +
        `- Top reasons: ${report.patterns.commonReasons.join(', ')}`;

      // Send to management
      await this.sendToManagement(message);
    } catch (error) {
      logger.error('Error sending cancellation report:', {
        error: error.message
      });
    }
  }

  /**
   * Format time patterns for report
   * @private
   */
  formatTimePatterns(timePatterns) {
    const peakHours = Object.entries(timePatterns)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([hour]) => `${hour}:00`);
    return peakHours.join(', ');
  }

  /**
   * Format location patterns for report
   * @private
   */
  formatLocationPatterns(locationPatterns) {
    const topLocations = Object.entries(locationPatterns)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([location]) => location);
    return topLocations.join(', ');
  }

  /**
   * Store archive record
   * @private
   */
  async storeArchiveRecord(archiveRecord) {
    // Implement your archive storage logic here
    // This could be a separate collection or external storage
    logger.info('Archive record stored:', { archiveId: archiveRecord.archiveId });
  }

  /**
   * Send to operations team
   * @private
   */
  async sendToOperationsTeam(message) {
    // Implement your operations team notification logic here
    // This could be email, Slack, or other communication channel
    logger.info('Sent to operations team:', { message });
  }

  /**
   * Send to admin team
   * @private
   */
  async sendToAdminTeam(message) {
    // Implement your admin team notification logic here
    logger.info('Sent to admin team:', { message });
  }

  /**
   * Send to management
   * @private
   */
  async sendToManagement(message) {
    // Implement your management notification logic here
    logger.info('Sent to management:', { message });
  }
}

module.exports = new EndOfDayService(); 
const JourneyCompletion = require('../models/journeyCompletion');
const User = require('../models/user');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');

class JourneyCompletionService {
  /**
   * Initialize journey completion for a user
   * @param {string} userId - The user's ID
   * @param {Date} flightTime - The scheduled flight time
   */
  async initializeJourneyCompletion(userId, flightTime) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Create journey completion record
      const journeyCompletion = new JourneyCompletion({
        userId,
        flightTime,
        departureMessages: [
          { type: '24H', sentAt: new Date(flightTime.getTime() - 24 * 60 * 60 * 1000), status: 'PENDING' },
          { type: '12H', sentAt: new Date(flightTime.getTime() - 12 * 60 * 60 * 1000), status: 'PENDING' },
          { type: '4H', sentAt: new Date(flightTime.getTime() - 4 * 60 * 60 * 1000), status: 'PENDING' }
        ]
      });

      await journeyCompletion.save();
      logger.info(`Initialized journey completion for user ${userId}`, {
        journeyCompletionId: journeyCompletion.journeyCompletionId,
        flightTime
      });

      return journeyCompletion;
    } catch (error) {
      logger.error('Error initializing journey completion:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Send pre-departure messages
   */
  async sendPreDepartureMessages() {
    try {
      const now = new Date();
      const oneHourFromNow = new Date(now.getTime() + 60 * 60 * 1000);

      // Find pending messages that should be sent in the next hour
      const pendingMessages = await JourneyCompletion.find({
        'departureMessages': {
          $elemMatch: {
            status: 'PENDING',
            sentAt: { $lte: oneHourFromNow }
          }
        },
        journeyStatus: 'ACTIVE'
      }).populate('userId');

      for (const journey of pendingMessages) {
        const user = await User.findOne({ userId: journey.userId });
        if (!user) continue;

        for (const message of journey.departureMessages) {
          if (message.status === 'PENDING' && message.sentAt <= oneHourFromNow) {
            try {
              let messageText;
              switch (message.type) {
                case '24H':
                  messageText = "Your journey is ending in 24 hours. Please prepare for your departure and ensure you have all necessary documents.";
                  break;
                case '12H':
                  messageText = "Your journey is ending in 12 hours. Please confirm your travel arrangements and prepare for airport check-in.";
                  break;
                case '4H':
                  messageText = "Your journey is ending in 4 hours. Please proceed to the airport and prepare for the final verification.";
                  break;
              }

              await twilioService.sendWhatsAppMessage(user.phoneNumber, messageText);

              // Update message status
              await JourneyCompletion.updateOne(
                {
                  _id: journey._id,
                  'departureMessages.type': message.type
                },
                {
                  $set: {
                    'departureMessages.$.status': 'SENT',
                    'departureMessages.$.sentAt': now
                  }
                }
              );

              logger.info(`Sent ${message.type} pre-departure message to user ${user.userId}`);
            } catch (error) {
              logger.error(`Failed to send ${message.type} pre-departure message:`, {
                userId: user.userId,
                error: error.message
              });

              // Mark message as failed
              await JourneyCompletion.updateOne(
                {
                  _id: journey._id,
                  'departureMessages.type': message.type
                },
                {
                  $set: {
                    'departureMessages.$.status': 'FAILED'
                  }
                }
              );
            }
          }
        }
      }
    } catch (error) {
      logger.error('Error sending pre-departure messages:', {
        error: error.message,
        stack: error.stack
      });
    }
  }

  /**
   * Verify final code and agent PIN
   * @param {string} userId - The user's ID
   * @param {string} userCode - The user's verification code
   * @param {string} agentPin - The airport agent's PIN
   */
  async verifyFinalCodes(userId, userCode, agentPin) {
    try {
      const journey = await JourneyCompletion.findOne({
        userId,
        journeyStatus: 'ACTIVE'
      });

      if (!journey) {
        throw new Error('No active journey found for user');
      }

      // Verify codes (you should implement proper validation logic here)
      const isValid = await this.validateCodes(userCode, agentPin);

      if (!isValid) {
        throw new Error('Invalid verification codes');
      }

      // Update journey completion
      journey.finalVerification = {
        userCode,
        agentPin,
        verifiedAt: new Date(),
        status: 'VERIFIED'
      };
      journey.journeyStatus = 'COMPLETED';
      journey.completedAt = new Date();

      await journey.save();

      // Send farewell message
      const user = await User.findOne({ userId });
      if (user) {
        await twilioService.sendWhatsAppMessage(
          user.phoneNumber,
          "Thank you for using our service! Your journey has been completed successfully. Safe travels!"
        );
      }

      logger.info(`Journey completed for user ${userId}`);
      return journey;
    } catch (error) {
      logger.error('Error verifying final codes:', {
        userId,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Complete journey based on a Tap-Out event
   * @param {string} userId - The user's ID
   * @param {Object} tapOutDetails - Details from the Tap-Out code lookup
   */
  async completeJourneyWithTapOut(userId, tapOutDetails) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Update user status and record completion date
      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            status: 'COMPLETED',
            workQueueStatus: 'NONE',
            tripCompletionDate: new Date(),
            // Optionally store tapOutDetails or a reference to the tap-out event
            // tapOutEvent: { ...tapOutDetails, timestamp: new Date() }
          }
        }
      );

      // Find and update active journey completion record (if any)
      const journey = await JourneyCompletion.findOne({
        userId,
        journeyStatus: 'ACTIVE'
      });

      if (journey) {
        journey.journeyStatus = 'COMPLETED';
        journey.completedAt = new Date();
        // Optionally record tap-out details in the journey completion record
        // journey.completionMethod = 'Tap-Out';
        // journey.tapOutDetails = tapOutDetails;
        await journey.save();
        logger.info(`Updated active journey completion record for user ${userId} based on Tap-Out`);
      }


      logger.info(`Journey completed for user ${userId} via Tap-Out`, { tapOutDetails });

    } catch (error) {
      logger.error('Error completing journey with Tap-Out:', {
        userId,
        tapOutDetails,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Handle 'Departure; Trip Continues' Tap-Out (Event Code 07)
   * @param {string} userId - The user's ID
   * @param {Object} tapOutDetails - Details from the Tap-Out code lookup
   */
  async handleTripContinuedTapOut(userId, tapOutDetails) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            status: 'ACTIVE',
            workQueueStatus: 'NONE',
            lastDepartureDate: new Date(),
            lastDepartureLocation: { countryCode: tapOutDetails.countryCode, cityCode: tapOutDetails.cityCode }
          }
        }
      );
      logger.info(`User ${userId} handled as Departure; Trip Continues via Tap-Out`, { tapOutDetails });
    } catch (error) {
      logger.error('Error handling Departure; Trip Continues Tap-Out:', { userId, tapOutDetails, error: error.message, stack: error.stack });
      throw error;
    }
  }

  /**
   * Handle 'Arrival; Trip Continued' Tap-Out (Event Code 06)
   * @param {string} userId - The user's ID
   * @param {Object} tapOutDetails - Details from the Tap-Out code lookup
   */
  async handleArrivalContinuedTapOut(userId, tapOutDetails) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            status: 'ACTIVE',
            workQueueStatus: 'NONE',
            currentLocation: { countryCode: tapOutDetails.countryCode, cityCode: tapOutDetails.cityCode },
            lastArrivalDate: new Date()
          }
        }
      );

      // Schedule next regular check-in
      const now = new Date();
      const checkInHours = Number(process.env.CHECK_IN_INTERVAL_HOURS) || 3;
      const nextCheckIn = new Date(now.getTime() + checkInHours * 60 * 60 * 1000);
      await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

      logger.info(`User ${userId} handled as Arrival; Trip Continued via Tap-Out`, { tapOutDetails });

    } catch (error) {
      logger.error('Error handling Arrival; Trip Continued Tap-Out:', { userId, tapOutDetails, error: error.message, stack: error.stack });
      throw error;
    }
  }

  /**
  * Handle 'Local Handoff-Sending' Tap-Out (Event Code 09)
  * @param {string} userId - The user's ID
  * @param {Object} tapOutDetails - Details from the Tap-Out code lookup
  */
  async handleLocalHandoffSendingTapOut(userId, tapOutDetails) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            status: 'ACTIVE',
            workQueueStatus: 'NONE',
            isDayTrip: true,
            dayTripDeparture: { countryCode: tapOutDetails.countryCode, cityCode: tapOutDetails.cityCode, timestamp: new Date() }
          }
        }
      );
      logger.info(`User ${userId} handled as Local Handoff-Sending via Tap-Out`, { tapOutDetails });

    } catch (error) {
      logger.error('Error handling Local Handoff-Sending Tap-Out:', { userId, tapOutDetails, error: error.message, stack: error.stack });
      throw error;
    }
  }

  /**
 * Handle 'Local Handoff completed' Tap-Out (Event Code 98)
 * @param {string} userId - The user's ID
 * @param {Object} tapOutDetails - Details from the Tap-Out code lookup
 */
  async handleLocalHandoffReceivedTapOut(userId, tapOutDetails) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      await User.findOneAndUpdate(
        { userId },
        {
          $set: {
            status: 'ACTIVE',
            workQueueStatus: 'NONE',
            isDayTrip: false,
            dayTripArrival: { countryCode: tapOutDetails.countryCode, cityCode: tapOutDetails.cityCode, timestamp: new Date() }
          }
        }
      );

      // Schedule next regular check-in
      const now = new Date();
      const checkInHours = Number(process.env.CHECK_IN_INTERVAL_HOURS) || 3;
      const nextCheckIn = new Date(now.getTime() + checkInHours * 60 * 60 * 1000);
      await User.updateCheckInSchedule(user.userId, now, nextCheckIn);

      logger.info(`User ${userId} handled as Local Handoff completed via Tap-Out`, { tapOutDetails });

    } catch (error) {
      logger.error('Error handling Local Handoff completed Tap-Out:', { userId, tapOutDetails, error: error.message, stack: error.stack });
      throw error;
    }
  }

  /**
   * Validate the user code and agent PIN
   * @private
   */
  async validateCodes(userCode, agentPin) {
    // Implement your validation logic here
    // This is a placeholder - you should implement proper validation
    return true;
  }
}

module.exports = new JourneyCompletionService(); 
/**
 * Service for handling MongoDB operations
 */
const mongoose = require('mongoose');
const logger = require('../utils/logger');

class MongoDbService {
  constructor() {
    this.connection = null;
  }

  /**
   * Connect to MongoDB
   * @returns {Promise<void>}
   */
  async connect() {
    if (this.connection) {
      return;
    }

    try {
      const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/whatsapp-chatbot';
      this.connection = await mongoose.connect(mongoUri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });

      logger.info('Connected to MongoDB successfully');
    } catch (error) {
      logger.error(`MongoDB connection error: ${error.message}`);
      throw error;
    }
  }

  /**
   * Disconnect from MongoDB
   * @returns {Promise<void>}
   */
  async disconnect() {
    if (this.connection) {
      await mongoose.disconnect();
      this.connection = null;
      logger.info('Disconnected from MongoDB');
    }
  }

  /**
   * Get the mongoose connection
   * @returns {mongoose.Connection}
   */
  getConnection() {
    return this.connection;
  }
}

// Export a singleton instance
module.exports = new MongoDbService(); 
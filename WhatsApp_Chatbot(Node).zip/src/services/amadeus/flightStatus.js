const Amadeus = require('amadeus');
const logger = require('../../utils/logger');
const { date } = require('joi');

// Initialize Amadeus API client
const amadeus = new Amadeus({
  clientId: process.env.AMADEUS_CLIENT_ID,
  clientSecret: process.env.AMADEUS_CLIENT_SECRET
});

/**
 * Get flight status information from Amadeus API
 * @param {string} flightNumber - The flight number (e.g., "BA123")
 * @param {string} departureDate - Departure date in YYYY-MM-DD format
 * @returns {Promise<Object>} - Flight status information
 */
const getFlightStatus = async (flightNumber, departureDate) => {
  try {
    // Extract carrier code and flight number
    console.log("✔✔✔",flightNumber, departureDate)
    const carrierCode = flightNumber.substring(0, 2);
    const flightNumberOnly = flightNumber.substring(2);

    // Call Amadeus API
    const response = await amadeus.schedule.flights.get({
      carrierCode,
      flightNumber: flightNumberOnly,
      scheduledDepartureDate: departureDate
    });

    logger.info(`Retrieved flight status for ${flightNumber} on ${departureDate}`);
    return response.data;
  } catch (error) {
    logger.error(`Failed to get flight status: ${error.message}`, {
      flightNumber,
      departureDate,
      errorResponse: error.response?.result
    });
    throw new Error(`Flight status lookup failed: ${error.message}`);
  }
};

/**
 * Format flight status data into a user-friendly message
 * @param {Object} flightData - Flight data from Amadeus API
 * @returns {string} - Formatted message
 */
const formatFlightStatusMessage = (flightData) => {
  try {
    if (!flightData || !flightData.data || flightData.data.length === 0) {
      return "Sorry, we couldn't find information for this flight.";
    }

    const flight = flightData.data[0];
    const segments = flight.flightPoints;

    if (!segments || segments.length < 2) {
      return "Flight information is incomplete.";
    }

    // Get departure and arrival points
    const departure = segments.find(point => point.typeCode === 'DEPARTURE');
    const arrival = segments.find(point => point.typeCode === 'ARRIVAL');

    if (!departure || !arrival) {
      return "Flight information is incomplete.";
    }

    // Format times
    const departureTime = new Date(departure.scheduledTime.dateTime).toLocaleString();
    const arrivalTime = new Date(arrival.scheduledTime.dateTime).toLocaleString();

    // Check for delays
    const departureDelay = departure.delayMinutes ? `Delayed by ${departure.delayMinutes} minutes` : 'On time';
    const arrivalDelay = arrival.delayMinutes ? `Delayed by ${arrival.delayMinutes} minutes` : 'On time';

    // Get flight status
    let status = "Unknown";
    if (flight.status) {
      switch (flight.status.statusCode) {
        case 'SCHEDULED':
          status = 'Scheduled';
          break;
        case 'ACTIVE':
          status = 'In Flight';
          break;
        case 'LANDED':
          status = 'Landed';
          break;
        case 'CANCELLED':
          status = 'Cancelled';
          break;
        case 'DIVERTED':
          status = 'Diverted';
          break;
        default:
          status = flight.status.statusCode;
      }
    }

    // Build message
    return `
Flight Status: ${status}
Flight: ${flight.carrierCode}${flight.number}

Departure:
${departure.iataCode} at ${departureTime}
Status: ${departureDelay}

Arrival:
${arrival.iataCode} at ${arrivalTime}
Status: ${arrivalDelay}
    `.trim();
  } catch (error) {
    logger.error(`Error formatting flight status message: ${error.message}`);
    return "Sorry, there was an error formatting the flight information.";
  }
};

/**
 * Check if a flight is delayed or cancelled
 * @param {Object} flightData - Flight data from Amadeus API
 * @returns {boolean} - Whether the flight is delayed or cancelled
 */
const isFlightDelayedOrCancelled = (flightData) => {
  try {
    if (!flightData || !flightData.data || flightData.data.length === 0) {
      return false;
    }

    const flight = flightData.data[0];
    
    // Check if flight is cancelled
    if (flight.status && flight.status.statusCode === 'CANCELLED') {
      return true;
    }

    // Check if there are significant delays
    const segments = flight.flightPoints;
    if (segments) {
      for (const segment of segments) {
        // Consider a delay significant if it's over 30 minutes
        if (segment.delayMinutes && segment.delayMinutes > 30) {
          return true;
        }
      }
    }

    return false;
  } catch (error) {
    logger.error(`Error checking flight delay status: ${error.message}`);
    return false;
  }
};

module.exports = {
  getFlightStatus,
  formatFlightStatusMessage,
  isFlightDelayedOrCancelled
}; 
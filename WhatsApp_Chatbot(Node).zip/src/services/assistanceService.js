const User = require('../models/user');
const twilioService = require('./twilio/twilioService');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

class AssistanceService {
  /**
   * Handle general assistance request
   * @param {string} userId - The user's ID
   * @param {string} query - The user's query
   */
  async handleAssistanceRequest(userId, query) {
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        throw new Error('User not found');
      }

      // Normalize query to lowercase for easier matching
      const normalizedQuery = query.toLowerCase();

      // Handle different types of queries
      if (normalizedQuery.includes('where') || normalizedQuery.includes('next')) {
        return await this.handleLocationQuery(user);
      } else if (normalizedQuery.includes('lost') || normalizedQuery.includes('code')) {
        return await this.handleLostCodeQuery(user);
      } else if (normalizedQuery.includes('itinerary')) {
        return await this.handleItineraryQuery(user);
      } else if (normalizedQuery.includes('emergency') || normalizedQuery.includes('help')) {
        return await this.handleEmergencyQuery(user);
      } else if (normalizedQuery.includes('issue') || normalizedQuery.includes('report')) {
        return await this.handleIssueReport(user);
      } else if (normalizedQuery.includes('cancel') || normalizedQuery.includes('trip')) {
        return await this.handleTripCancellation(user);
      } else if (normalizedQuery.includes('contact') || normalizedQuery.includes('info')) {
        return await this.handleContactUpdate(user);
      } else if (normalizedQuery.includes('human') || normalizedQuery.includes('speak')) {
        return await this.handleHumanRequest(user);
      } else {
        return await this.handleGeneralQuery(user);
      }
    } catch (error) {
      logger.error('Error handling assistance request:', {
        userId,
        query,
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Handle location/next steps query
   * @private
   */
  async handleLocationQuery(user) {
    try {
      const nextLocation = user.nextLocation || 'No next location scheduled';
      const message = `Your next scheduled location is: ${nextLocation}. ` +
        'Please ensure you arrive on time for your check-in.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Location information sent' };
    } catch (error) {
      logger.error('Error handling location query:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle lost code query
   * @private
   */
  async handleLostCodeQuery(user) {
    try {
      // Generate new verification code
      const newCode = Math.floor(100000 + Math.random() * 900000).toString();
      
      // Update user's verification code
      await User.findOneAndUpdate(
        { userId: user.userId },
        { $set: { verificationCode: newCode } }
      );

      const message = `Your new verification code is: ${newCode}. ` +
        'Please keep this code safe and use it for your next check-in.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'New code sent' };
    } catch (error) {
      logger.error('Error handling lost code query:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle itinerary query
   * @private
   */
  async handleItineraryQuery(user) {
    try {
      const itinerary = user.itinerary || [];
      if (itinerary.length === 0) {
        const message = 'No itinerary found for your account. Please contact support for assistance.';
        await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
        return { success: true, message: 'No itinerary found' };
      }

      // Format itinerary details
      const itineraryDetails = itinerary.map(item => 
        `- ${item.location} (${new Date(item.time).toLocaleString()})`
      ).join('\n');

      const message = `Your itinerary:\n${itineraryDetails}`;
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Itinerary sent' };
    } catch (error) {
      logger.error('Error handling itinerary query:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle emergency help request
   * @private
   */
  async handleEmergencyQuery(user) {
    try {
      // Create emergency escalation
      const escalation = await this.createEmergencyEscalation(user);
      
      const message = 'Emergency assistance has been requested. ' +
        'A safety agent will be assigned to your case shortly. ' +
        'Please stay where you are and wait for further instructions.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { 
        success: true, 
        message: 'Emergency assistance initiated',
        escalationId: escalation.escalationId
      };
    } catch (error) {
      logger.error('Error handling emergency query:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle issue report
   * @private
   */
  async handleIssueReport(user) {
    try {
      const issueId = uuidv4();
      
      // Create issue report
      await this.createIssueReport(user, issueId);
      
      const message = `Thank you for reporting an issue. Your report ID is: ${issueId}. ` +
        'A support agent will review your report and contact you shortly.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Issue report created', issueId };
    } catch (error) {
      logger.error('Error handling issue report:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle trip cancellation
   * @private
   */
  async handleTripCancellation(user) {
    try {
      const message = 'To cancel your trip, please confirm by replying "CONFIRM CANCEL". ' +
        'Note: Cancellation may be subject to terms and conditions.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Cancellation instructions sent' };
    } catch (error) {
      logger.error('Error handling trip cancellation:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle contact information update
   * @private
   */
  async handleContactUpdate(user) {
    try {
      const message = 'To update your contact information, please provide:\n' +
        '1. New phone number (if changing)\n' +
        '2. New email address (if changing)\n' +
        'Please send your updates in this format.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Contact update instructions sent' };
    } catch (error) {
      logger.error('Error handling contact update:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle request to speak with human
   * @private
   */
  async handleHumanRequest(user) {
    try {
      // Create support ticket
      const ticketId = await this.createSupportTicket(user);
      
      const message = `A support agent will contact you shortly. Your ticket ID is: ${ticketId}. ` +
        'Please keep this number for reference.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'Support ticket created', ticketId };
    } catch (error) {
      logger.error('Error handling human request:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle general query
   * @private
   */
  async handleGeneralQuery(user) {
    try {
      const message = 'I can help you with:\n' +
        '- Finding your next location\n' +
        '- Lost verification codes\n' +
        '- Itinerary information\n' +
        '- Emergency assistance\n' +
        '- Reporting issues\n' +
        '- Trip cancellation\n' +
        '- Updating contact information\n' +
        '- Speaking with a human\n\n' +
        'Please specify what you need help with.';
      
      await twilioService.sendWhatsAppMessage(user.phoneNumber, message);
      return { success: true, message: 'General help menu sent' };
    } catch (error) {
      logger.error('Error handling general query:', {
        userId: user.userId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Create emergency escalation
   * @private
   */
  async createEmergencyEscalation(user) {
    // Implementation depends on your emergency escalation service
    // This is a placeholder
    return { escalationId: uuidv4() };
  }

  /**
   * Create issue report
   * @private
   */
  async createIssueReport(user, issueId) {
    // Implementation depends on your issue tracking system
    // This is a placeholder
    return { issueId };
  }

  /**
   * Create support ticket
   * @private
   */
  async createSupportTicket(user) {
    // Implementation depends on your support ticket system
    // This is a placeholder
    return uuidv4();
  }
}

module.exports = new AssistanceService(); 
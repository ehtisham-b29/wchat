const OpenAI = require('openai');
const logger = require('../../utils/logger');

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generate a response using ChatGPT
 * @param {Array} messages - Array of message objects in the format {role: 'user'|'assistant'|'system', content: string}
 * @param {Object} options - Configuration options
 * @returns {Promise<string>} - The generated response text
 */
const generateResponse = async (messages, options = {}) => {
  const defaultOptions = {
    model: process.env.OPENAI_MODEL || 'gpt-4',
    temperature: 0.7,
    max_tokens: 500,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0,
  };

  // Merge default options with provided options
  const requestOptions = { ...defaultOptions, ...options };

  try {
    const response = await openai.chat.completions.create({
      model: requestOptions.model,
      messages,
      temperature: requestOptions.temperature,
      max_tokens: requestOptions.max_tokens,
      top_p: requestOptions.top_p,
      frequency_penalty: requestOptions.frequency_penalty,
      presence_penalty: requestOptions.presence_penalty,
    });

    const responseText = response.choices[0].message.content.trim();
    
    // Log token usage for monitoring
    if (response.usage) {
      logger.debug('ChatGPT token usage:', response.usage);
    }

    return responseText;
  } catch (error) {
    logger.error(`ChatGPT API error: ${error.message}`, { 
      status: error.status,
      statusText: error.statusText,
    });
    throw new Error(`Failed to generate response: ${error.message}`);
  }
};

/**
 * Analyze sentiment and user intent from a message
 * @param {string} message - User message to analyze
 * @returns {Promise<Object>} - Analysis results including sentiment and intent
 */
const analyzeMessage = async (message) => {
  const systemPrompt = `Analyze the following message for:
1. Emotional tone (positive, negative, neutral)
2. User intent (question, complaint, request, emergency)
3. Frustration level (0-10 scale)
4. Does this require human escalation? (true/false)

Respond with a JSON object only.`;

  try {
    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      temperature: 0.3,
      max_tokens: 200,
    });

    const analysisText = response.choices[0].message.content.trim();
    let analysis;
    
    try {
      analysis = JSON.parse(analysisText);
    } catch (parseError) {
      logger.error('Error parsing sentiment analysis JSON', { analysisText });
      // Fallback to default values
      analysis = {
        emotionalTone: 'neutral',
        intent: 'unknown',
        frustrationLevel: 0,
        requiresEscalation: false
      };
    }

    return analysis;
  } catch (error) {
    logger.error(`ChatGPT analysis error: ${error.message}`);
    // Return default values in case of API error
    return {
      emotionalTone: 'neutral',
      intent: 'unknown',
      frustrationLevel: 0,
      requiresEscalation: false
    };
  }
};

/**
 * Generate a personalized onboarding message
 * @param {string} username - User's name
 * @param {string} location - User's detected location
 * @returns {Promise<string>} - Personalized onboarding message
 */
const generateOnboardingMessage = async (username, location) => {
  const systemPrompt = `You are a helpful travel assistant chatbot. 
Generate a friendly, welcoming onboarding message for a new user.
The message should:
1. Welcome them by name
2. Briefly explain your ability to help with their journey
3. Explain the passcode system for safety check-ins
4. Ask if they need help with anything

Keep the tone friendly but professional, and the message concise.`;

  const userPrompt = `Generate an onboarding message for ${username} who is in ${location}.`;

  try {
    return await generateResponse([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ], { 
      temperature: 0.7, 
      max_tokens: 300 
    });
  } catch (error) {
    logger.error(`Failed to generate onboarding message: ${error.message}`);
    // Fallback message in case of API error
    return `Welcome ${username}! I'm your travel assistant, here to help with your journey. For security, I'll ask you to set up a passcode for check-ins. How can I assist you today?`;
  }
};

module.exports = {
  generateResponse,
  analyzeMessage,
  generateOnboardingMessage
}; 
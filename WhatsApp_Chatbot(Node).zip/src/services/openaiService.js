const { OpenAI } = require("openai");
const logger = require("../utils/logger");

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generate a response using OpenAI
 * @param {string} message - The user's message
 * @param {Object} user - The user object
 * @returns {Promise<string>} - The generated response
 */
const generateResponse = async (message, user) => {
  try {
    logger.debug("Generating OpenAI response", {
      userName: user.name,
      messageLength: message.length,
    });

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a helpful WhatsApp assistant. The user's name is ${user.name}.`,
        },
        {
          role: "user",
          content: message,
        },
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    const response = completion.choices[0].message.content;

    logger.debug("OpenAI response generated", {
      responseLength: response.length,
      tokens: completion.usage.total_tokens,
    });

    return response;
  } catch (error) {
    logger.error("Error generating OpenAI response:", error.message, {
      errorDetails: error,
    });
    throw new Error(`Error generating OpenAI response: ${error.message}`);
  }
};

module.exports = {
  generateResponse,
};

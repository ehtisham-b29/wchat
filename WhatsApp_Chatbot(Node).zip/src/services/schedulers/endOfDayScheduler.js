const logger = require('../../utils/logger');
const endOfDayService = require('../endOfDayService');

class EndOfDayScheduler {
    constructor() {
        this.scheduler = null;
        this.isRunning = false;
    }

    /**
     * Start the end of day scheduler
     */
    start() {
        if (this.isRunning) {
            logger.warn('End of day scheduler is already running');
            return;
        }

        // Schedule to run at 6 AM every day
        this.scheduler = setInterval(async () => {
            try {
                const now = new Date();
                if (now.getHours() === 6 && now.getMinutes() === 0) {
                    logger.info('Running end of day check');
                    await endOfDayService.processEndOfDay();
                }
            } catch (error) {
                logger.error('Error in end of day scheduler:', error);
            }
        }, 60000); // Check every minute

        this.isRunning = true;
        logger.info('End of day scheduler started');
    }

    /**
     * Stop the end of day scheduler
     */
    stop() {
        if (!this.isRunning) {
            logger.warn('End of day scheduler is not running');
            return;
        }

        clearInterval(this.scheduler);
        this.scheduler = null;
        this.isRunning = false;
        logger.info('End of day scheduler stopped');
    }

    /**
     * Check if the scheduler is running
     * @returns {boolean} True if the scheduler is running
     */
    isActive() {
        return this.isRunning;
    }
}

module.exports = new EndOfDayScheduler(); 
# WhatsApp Chatbot with ChatGPT Integration

A comprehensive WhatsApp chatbot solution leveraging ChatGPT for natural language processing, with verification, voice call integration, SMS capabilities, and password management.

## Technology Stack

- **Backend**: Node.js
- **Database**: AWS DynamoDB
- **Hosting/Deployment**: AWS (EC2, Lambda)
- **Scheduler**: AWS Lambda with CloudWatch Events
- **Messaging**: Twilio (WhatsApp Business API, SMS, Voice Call)
- **AI/NLP**: OpenAI GPT-4 API
- **Text-to-Speech**: Google Cloud TTS API
- **Location Services**: Google Cloud Location API
- **Flight Status**: Amadeus Flight Status API

## Core Features

1. **Onboarding & Identity Verification**

   - Location-aware greetings and setup
   - Identity verification via Twilio
   - Passcode setup and management

2. **Conversational AI**

   - Natural language understanding with ChatGPT
   - Context-aware responses
   - Sentiment analysis and escalation detection

3. **Tap-In Workflow**

   - Scheduled check-in messages
   - Passcode verification
   - Emergency code handling (SOS, MED)

4. **Voice and SMS Integration**

   - Voice call verification with DTMF
   - SMS fallback

5. **Flight Status Tracking**
   - Integration with Amadeus Flight API
   - Pre-departure notifications

## Setup Instructions

1. Clone this repository
2. Install dependencies: `npm install`
3. Configure environment variables (see `.env.example`)
4. Set up AWS services (DynamoDB, Lambda)
5. Configure Twilio for WhatsApp Business API
6. Set up OpenAI API access
7. Set up Google Cloud services (TTS, Location)
8. Configure Amadeus Flight Status API
9. Run the development server: `npm run dev`

## Project Structure

```
/
├── config/               # Configuration files
├── src/
│   ├── controllers/      # Request handlers
│   ├── middleware/       # Express middleware
│   ├── models/           # Data models
│   ├── routes/           # API routes
│   ├── services/         # Business logic
│   │   ├── ai/           # ChatGPT integration
│   │   ├── twilio/       # Twilio services
│   │   ├── amadeus/      # Flight API integration
│   │   └── google/       # Google Cloud services
│   ├── utils/            # Helper functions
│   └── app.js            # Express application
├── scripts/              # Deployment scripts
└── tests/                # Test suite
```

## Environment Variables

Create a `.env` file with the following variables:

```
# Server
PORT=3000
NODE_ENV=development

# AWS
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key

# Twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_twilio_number
TWILIO_WHATSAPP_NUMBER=your_whatsapp_number

# OpenAI
OPENAI_API_KEY=your_openai_api_key

# Google Cloud
GOOGLE_APPLICATION_CREDENTIALS=path/to/credentials.json

# Amadeus
AMADEUS_API_KEY=your_amadeus_api_key
AMADEUS_API_SECRET=your_amadeus_api_secret
```

## License

MIT

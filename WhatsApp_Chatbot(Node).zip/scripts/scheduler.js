require('dotenv').config();
const axios = require('axios');
const mongoose = require('mongoose');
const Session = require("../src/models/session");
const User = require('../src/models/user');
const Verification = require('../src/models/verification');
const twilioService = require('../src/services/twilio/twilioService');
const logger = require('../src/utils/logger');
const journeyCompletionService = require('../src/services/journeyCompletionService');

// Base URL for API calls - set this to your deployed API URL
const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:3000/api';

// Connect to MongoDB with improved options
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  ssl: true,
  sslValidate: true,
  sslCA: process.env.MONGODB_CA_CERT,
  retryWrites: true,
  w: 'majority',
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000,
}).then(() => {
  logger.info('Connected to MongoDB successfully');
}).catch((error) => {
  logger.error('MongoDB connection error:', {
    message: error.message,
    stack: error.stack,
    code: error.code,
    name: error.name
  });
  process.exit(1);
});

// Handle MongoDB connection errors after initial connection
mongoose.connection.on('error', (error) => {
  logger.error('MongoDB connection error after initial connection:', {
    message: error.message,
    stack: error.stack,
    code: error.code,
    name: error.name
  });
});

mongoose.connection.on('disconnected', () => {
  logger.error('MongoDB disconnected - attempting to reconnect...');
});

/**
 * Process check-ins that are due
 */
async function processCheckIns() {
  try {
    const now = new Date();

    // Find users with check-ins due
    const dueCheckIns = await User.find({
      nextCheckInDue: { $lte: now },
      status: 'ACTIVE'
    }).lean();

    if (!dueCheckIns || dueCheckIns.length === 0) {
      logger.info('No check-ins due at this time');
      return;
    }

    logger.info(`Found ${dueCheckIns.length} users with check-ins due`);

    // Process each user with a due check-in
    for (const user of dueCheckIns) {
      try {
        // Call the check-in API for this user
        await axios.post(`${API_BASE_URL}/check-in/${user.userId}`);

        logger.info(`Triggered check-in for user ${user.userId}`);
      } catch (error) {
        logger.error(`Error triggering check-in for user ${user.userId}:`, {
          message: error.message,
          stack: error.stack,
          code: error.code,
          response: error.response?.data
        });

        // Fallback: try to send the message directly
        if (user.phoneNumber) {
          try {
            await twilioService.sendWhatsAppMessage(
              user.phoneNumber,
              "Tap-In"
            );

            logger.info(`Sent fallback check-in message to ${user.phoneNumber}`);
          } catch (smsError) {
            logger.error(`Failed to send fallback message to ${user.phoneNumber}:`, {
              message: smsError.message,
              stack: smsError.stack,
              code: smsError.code
            });
          }
        }
      }
    }
  } catch (error) {
    logger.error('Error processing check-ins:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
  }
}

/**
 * Process expired verification codes
 */
async function processExpiredVerifications() {
  try {
    const now = new Date();

    // Find expired but still PENDING verifications
    const expiredVerifications = await Verification.find({
      expiresAt: { $lt: now },
      status: 'PENDING'
    }).lean();

    if (!expiredVerifications || expiredVerifications.length === 0) {
      logger.info('No expired verifications to process');
      return;
    }

    logger.info(`Found ${expiredVerifications.length} expired verifications`);

    // Process each expired verification
    for (const verification of expiredVerifications) {
      try {
        // Update status to EXPIRED using findOneAndUpdate for atomicity
        await Verification.findOneAndUpdate(
          { _id: verification._id },
          { $set: { status: 'EXPIRED' } },
          { new: true }
        );

        logger.info(`Marked verification ${verification.verificationId} as expired`);

        // Optionally send notification to the user
        if (verification.phoneNumber) {
          await twilioService.sendWhatsAppMessage(
            verification.phoneNumber,
            "Your verification code has expired. If you still need to verify, please request a new code."
          );
        }
      } catch (error) {
        logger.error(`Error processing expired verification ${verification.verificationId}:`, {
          message: error.message,
          stack: error.stack,
          code: error.code,
          name: error.name
        });
      }
    }
  } catch (error) {
    logger.error('Error processing expired verifications:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
  }
}

/**
 * Process flagged users (e.g., missed check-ins)
 */
async function processFlaggedUsers() {
  try {
    console.log("🚩🚩🚩🚩🚩🚩🚩")
    const now = new Date();
    const checkInGracePeriod = 5 * 60 * 1000; // 5 minutes grace period
    const graceTime = new Date(now.getTime() - checkInGracePeriod);

    logger.info('Checking for missed check-ins:', {
      currentTime: now.toISOString(),
      graceTime: graceTime.toISOString()
    });

    // Find users who missed their check-in
    const missedCheckInUsers = await User.find({
      nextCheckInDue: { $lt: graceTime },
      status: 'ACTIVE'
    }).lean();

    logger.info('Query results:', {
      query: {
        nextCheckInDue: { $lt: graceTime },
        status: 'ACTIVE'
      },
      foundUsers: missedCheckInUsers?.length || 0
    });

    if (!missedCheckInUsers || missedCheckInUsers.length === 0) {
      logger.info('No users with missed check-ins');
      return;
    }

    logger.info(`Found ${missedCheckInUsers.length} users with missed check-ins`);

    // Process each user with a missed check-in
    for (const user of missedCheckInUsers) {
      try {
        logger.info(`Processing user ${user.userId}:`, {
          nextCheckInDue: user.nextCheckInDue,
          status: user.status,
          hasCheckInHistory: user.checkInHistory?.length > 0
        });

        // Calculate time since last check-in or next check-in due
        let timeSinceLastCheckIn;
        if (user.checkInHistory && user.checkInHistory.length > 0) {
          const lastCheckIn = user.checkInHistory[user.checkInHistory.length - 1];
          timeSinceLastCheckIn = now - new Date(lastCheckIn.timestamp);
        } else {
          // If no check-in history, use the nextCheckInDue time
          timeSinceLastCheckIn = now - new Date(user.nextCheckInDue);
        }

        logger.info(`Time calculations for user ${user.userId}:`, {
          timeSinceLastCheckIn: timeSinceLastCheckIn,
          threeMinutesThreshold: 3 * 60 * 1000,
          fiveMinutesThreshold: 5 * 60 * 1000
        });

        // Time thresholds in milliseconds
        const threeMinutesInMs = 3 * 60 * 1000;
        const fiveMinutesInMs = 5 * 60 * 1000;

        // Update user status to FLAGGED
        const updates = {
          status: 'FLAGGED',
          workQueueStatus: 'ESCALATED'
        };

        // Only update check-in history status if there are entries
        if (user.checkInHistory && user.checkInHistory.length > 0) {
          updates['checkInHistory.$[].status'] = 'MISSED';
        }

        await User.findOneAndUpdate(
          { userId: user.userId },
          { $set: updates },
          { new: true }
        );

        logger.warn(`User ${user.userId} missed check-in - initiating escalation protocol`);

        if (user.phoneNumber) {
          // First message - immediate
          logger.info(`Sending initial message to ${user.phoneNumber}`);
          await twilioService.sendWhatsAppMessage(
            user.phoneNumber,
            "Tap-In"
          );

          // Add to check-in history
          await User.findOneAndUpdate(
            { userId: user.userId },
            {
              $push: {
                checkInHistory: {
                  timestamp: now,
                  status: 'MISSED',
                  location: user.location || null,
                  messageSent: 'INITIAL'
                }
              }
            }
          );

          // After 3 minutes - reminder message
          if (timeSinceLastCheckIn >= threeMinutesInMs && timeSinceLastCheckIn < fiveMinutesInMs) {
            logger.info(`Sending 3-minute reminder to ${user.phoneNumber}`);
            await twilioService.sendWhatsAppMessage(
              user.phoneNumber,
              "We haven't received your scheduled check-in. This is a quick reminder to TAP-IN with your passcode"
            );

            await User.findOneAndUpdate(
              { userId: user.userId },
              {
                $push: {
                  checkInHistory: {
                    timestamp: now,
                    status: 'MISSED',
                    location: user.location || null,
                    messageSent: 'REMINDER'
                  }
                }
              }
            );
          }

          // After 5 minutes - verification code and calls
          if (timeSinceLastCheckIn >= fiveMinutesInMs) {
            logger.warn(`User ${user.userId} has not responded for 5+ minutes - initiating verification and calls`);

            // Generate and send verification code
            const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
            const verification = new Verification({
              userId: user.userId,
              phoneNumber: user.phoneNumber,
              code: verificationCode,
              type: 'SMS',
              purpose: 'LOGIN',
              expiresAt: new Date(now.getTime() + 30 * 60 * 1000) // 30 minutes expiry
            });
            await verification.save();

            logger.info(`Sending verification code ${verificationCode} to ${user.phoneNumber}`);
            // Send verification code via WhatsApp
            await twilioService.sendWhatsAppMessage(
              user.phoneNumber,
              `URGENT ESCALATION: Your safety verification code is ${verificationCode}. Please respond with this code immediately.`
            );

            // Get active session for user
            const activeSession = await Session.getActiveByUserId(user.userId);
            console.log("session 🍏🍏🍏🍏🍏", activeSession);
            if (activeSession) {
              await Session.updateState(activeSession.sessionId, "AWAITING_VERIFICATION_CODE");
            }

            // Make 3 Twilio calls within 4 minutes
            logger.info(`📞📞📞📞📞 Initiating 3 calls to ${user.phoneNumber}`);
            const callPromises = [];
            for (let i = 0; i < 3; i++) {
              // Check if verification has been completed before making the next call
              const verificationStatus = await Verification.findOne({
                userId: user.userId,
                status: 'VERIFIED',
                createdAt: { $gte: new Date(now.getTime() - 5 * 60 * 1000) } // Check last 5 minutes
              });

              if (verificationStatus) {
                logger.info(`Verification completed for user ${user.userId} - stopping escalation`);
                // Update user status back to active
                await User.findOneAndUpdate(
                  { userId: user.userId },
                  {
                    $set: {
                      status: 'ACTIVE',
                      workQueueStatus: 'NONE'
                    }
                  }
                );
                break; // Stop making calls
              }

              logger.info(`Making call ${i + 1} to ${user.phoneNumber}`);
              callPromises.push(
                twilioService.makeCall(
                  user.phoneNumber,
                  `${verificationCode}`
                ).catch(callError => {
                  logger.error(`Failed to make Twilio call ${i + 1} to ${user.phoneNumber}:`, {
                    message: callError.message,
                    stack: callError.stack,
                    code: callError.code
                  });
                })
              );
              // Wait 1.33 minutes between calls (4 minutes total for 3 calls)
              if (i < 2) {
                await new Promise(resolve => setTimeout(resolve, 80 * 1000));
              }
            }

            // Wait for all calls to complete
            await Promise.all(callPromises);
            logger.info(`Completed all calls to ${user.phoneNumber}`);

            // Check one final time if verification was completed
            const finalVerificationStatus = await Verification.findOne({
              userId: user.userId,
              status: 'VERIFIED',
              createdAt: { $gte: new Date(now.getTime() - 5 * 60 * 1000) } // Check last 5 minutes
            });

            if (!finalVerificationStatus) {
              // Only send final escalation message and update status if verification failed
              logger.info(`Sending final escalation message to ${user.phoneNumber}`);
              await twilioService.sendWhatsAppMessage(
                user.phoneNumber,
                "We still haven't heard from you. For your safety we are initiating our escalation protocol which may include alerting our local support personnel. If this is a mistake please TAP-IN with your code"
              );

              // Update user status to indicate final escalation
              await User.findOneAndUpdate(
                { userId: user.userId },
                {
                  $set: {
                    workQueueStatus: 'FINAL_ESCALATION',
                    lastEscalationTime: now
                  }
                }
              );
            }
          }
        }
      } catch (error) {
        logger.error(`Error processing missed check-in for user ${user.userId}:`, {
          message: error.message,
          stack: error.stack,
          code: error.code,
          name: error.name
        });
      }
    }
  } catch (error) {
    logger.error('Error processing flagged users:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
  }
}

/**
 * Main function to run all scheduled tasks
 */
async function runScheduledTasks() {
  logger.info('Starting scheduled tasks');

  try {
    // Process due check-ins
    await processCheckIns();

    // Process expired verifications
    await processExpiredVerifications();

    // Process flagged users
    await processFlaggedUsers();

    // Process journey completion messages
    await journeyCompletionService.sendPreDepartureMessages();

    logger.info('Completed scheduled tasks');
  } catch (error) {
    logger.error('Error running scheduled tasks:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
  }
}

// Run tasks every minute
setInterval(runScheduledTasks, 60 * 1000);

// Run tasks immediately on startup
runScheduledTasks().catch(error => {
  logger.error('Unhandled error in scheduler:', {
    message: error.message,
    stack: error.stack,
    code: error.code,
    name: error.name
  });
  process.exit(1);
}); 
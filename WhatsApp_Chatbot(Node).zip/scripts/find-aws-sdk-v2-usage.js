const fs = require("fs");
const path = require("path");

// Directories to search
const directories = ["src", "scripts"];

// Pattern to match
const pattern = /require\(['"]aws-sdk['"]\)/;

// Function to search files recursively
function searchFiles(dir) {
  const files = fs.readdirSync(dir);

  files.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      // Recursively search subdirectories
      searchFiles(filePath);
    } else if (stat.isFile() && file.endsWith(".js")) {
      // Check JavaScript files
      const content = fs.readFileSync(filePath, "utf8");
      if (pattern.test(content)) {
        console.log(`Found AWS SDK v2 usage in: ${filePath}`);
      }
    }
  });
}

// Start the search
console.log("Searching for AWS SDK v2 usage...");
directories.forEach((dir) => {
  if (fs.existsSync(dir)) {
    searchFiles(dir);
  }
});
console.log("Search complete.");
